package com.example.pro.service;

import com.example.pro.dto.OrderDTO;

public interface OrderService {
    void saveOrder(OrderDTO order);
}
