import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./page/SelectCategory.css"; // 스타일 분리

function SelectCategory({ title, category, onSelect, selected ,onDetailOpen}) {
    const itemsByCategory = {
        zodiac: [
            { name: "쥐띠", img: "/src/image/12신/쥐.jpg" },
            { name: "소띠", img: "/src/image/12신/소.jpg" },
            { name: "호랑이띠", img: "/src/image/12신/호랑이.jpg" },
            { name: "토끼띠", img: "/src/image/12신/토끼.jpg" },
            { name: "용띠", img: "/src/image/12신/용.jpg" },
            { name: "뱀띠", img: "/src/image/12신/뱀.jpg" },
            { name: "말띠", img: "/src/image/12신/말.jpg" },
            { name: "양띠", img: "/src/image/12신/양.jpg" },
            { name: "원숭이띠", img: "/src/image/12신/원숭이.jpg" },
            { name: "닭띠", img: "/src/image/12신/닭.jpg" },
            { name: "개띠", img: "/src/image/12신/개.jpg" },
            { name: "돼지띠", img: "/src/image/12신/돼지.jpg" },



            // ... 생략
        ],
        horoscope: [
            { name: "물병자리", img: "/src/image/별자리/물병자리.jpg" },
            { name: "물고기자리", img: "/src/image/별자리/물고기자리.jpg" },
            { name: "게자리", img: "/src/image/별자리/게자리.jpg" },
            { name: "사수자리", img: "/src/image/별자리/사수자리.jpg" },
            { name: "쌍둥이자리", img: "/src/image/별자리/쌍둥이자리.jpg" },
            { name: "양자리", img: "/src/image/별자리/양자리.jpg" },
            { name: "염소자리", img: "/src/image/별자리/염소자리.jpg" },
            { name: "전갈자리", img: "/src/image/별자리/전갈자리.jpg" },
            { name: "처녀자리", img: "/src/image/별자리/처녀자리.jpg" },
            { name: "천칭자리", img: "/src/image/별자리/천칭자리.jpg" },
            { name: "황소자리", img: "/src/image/별자리/황소자리.jpg" },
            { name: "사자자리", img: "/src/image/별자리/사자자리.jpg" },



            // ... 생략
        ],
        mbti: [

            { name: "ENFJ", img: "/src/image/mbti/ENFJ.png" },


            { name: "ENTP", img: "/src/image/mbti/ENTP.png" },
            { name: "ENTJ", img: "/src/image/mbti/ENTJ.png" },
            { name: "ESFJ", img: "/src/image/mbti/ESFJ.png" },
            { name: "ESTJ", img: "/src/image/mbti/ESTJ.png" },
            { name: "ENFP", img: "/src/image/mbti/ENFP.png" },
            { name: "ESTP", img: "/src/image/mbti/ESTP.png" },
            { name: "INFJ", img: "/src/image/mbti/INFJ.png" },
            { name: "INFP", img: "/src/image/mbti/INFP.png" },
            { name: "INTJ", img: "/src/image/mbti/INTJ.png" },
            { name: "INTP", img: "/src/image/mbti/INTP.png" },
            { name: "ISFJ", img: "/src/image/mbti/ISFJ.png" },
            { name: "ISFP", img: "/src/image/mbti/ISFP.png" },
            { name: "ISTJ", img: "/src/image/mbti/ISTJ.png" },
            { name: "ISTP", img: "/src/image/mbti/ISTP.png" },

            // ... 생략
        ],
    };

    const items = itemsByCategory[category] || [];

    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        arrows: true,
        centerMode: true,         // ⭐ 중앙 정렬 활성화
        centerPadding: "0px",     // 카드 바깥 여백 제거
    };


    const handleClick = (item) => {
        onSelect(item.name);
        //////////////
        if (onDetailOpen) {
            onDetailOpen({
                type: category,
                name: item.name,
                img: item.img,   // ★ 추가
            });
        }
        /////////////
    };

    return (
        <div className="select-category-wrapper">

            <Slider {...settings}>
                {items.map((item) => (
                    <div key={item.name} className="select-category-slide">
                        <div
                            onClick={() => handleClick(item)}
                            className={`select-category-card ${item.name === selected ? "selected" : ""}`}
                        >
                            <img
                                src={item.img}
                                alt={item.name}
                                className="select-category-image"
                            />
                            <div className="select-category-name">{item.name}</div>
                        </div>
                    </div>
                ))}
            </Slider>
        </div>
    );
}

export default SelectCategory;
