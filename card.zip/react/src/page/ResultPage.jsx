import React, { useEffect, useState } from 'react';
import './ResultPage.css';
import Swal from 'sweetalert2';

function ResultPage({ zodiac, mbti, horoscope }) {
    const [resultData, setResultData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [comments, setComments] = useState([]);
    const [newContent, setNewContent] = useState("");
    const [commentsLoading, setCommentsLoading] = useState(false);
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    const mbtiEmojis = {
        INTJ: "🧠",
        INTP: "🔍",
        ENTJ: "🚀",
        ENTP: "⚡",
        INFJ: "🌟",
        INFP: "🎨",
        ENFJ: "💡",
        ENFP: "🔥",
        ISTJ: "📚",
        ISFJ: "🤝",
        ESTJ: "🛡️",
        ESFJ: "🎁",
        ISTP: "🔧",
        ISFP: "🌿",
        ESTP: "🏎️",
        ESFP: "🎉",
    };

    const horoscopeEmojis = {
        물병자리: "♒️",
        물고기자리: "♓️",
        양자리: "♈️",
        황소자리: "♉️",
        쌍둥이자리: "♊️",
        게자리: "♋️",
        사자자리: "♌️",
        처녀자리: "♍️",
        천칭자리: "♎️",
        전갈자리: "♏️",
        사수자리: "♐️",
        염소자리: "♑️",
    };

    const zodiacEmojis = {
        쥐: "🐭",
        소: "🐮",
        호랑이: "🐯",
        토끼: "🐰",
        용: "🐲",
        뱀: "🐍",
        말: "🐴",
        양: "🐑",
        원숭이: "🐵",
        닭: "🐔",
        개: "🐶",
        돼지: "🐷",
    };

    useEffect(() => {
        fetch(`/api/result?zodiac=${encodeURIComponent(zodiac)}&mbti=${encodeURIComponent(mbti)}&horoscope=${encodeURIComponent(horoscope)}`)
            .then((res) => {
                if (!res.ok) throw new Error('네트워크 응답 에러');
                return res.json();
            })
            .then((data) => {
                setResultData(data);
                setLoading(false);
            })
            .catch((err) => {
                setError(err.message);
                setLoading(false);
            });
    }, [zodiac, mbti, horoscope]);

    // 댓글 목록 불러오기
    const fetchComments = () => {
        setCommentsLoading(true);
        fetch(`/api/list?zodiac=${encodeURIComponent(zodiac)}&mbti=${encodeURIComponent(mbti)}&horoscope=${encodeURIComponent(horoscope)}`)
            .then(res => {
                if (!res.ok) throw new Error("댓글 목록 불러오기 실패");
                return res.json();
            })
            .then(data => {
                setComments(data);
                setCommentsLoading(false);
            })
            .catch(() => {
                setCommentsLoading(false);
            });
    };

    useEffect(() => {
        fetchComments();
    }, [zodiac, mbti, horoscope]);

    // 댓글 작성 핸들러
    const handleAddComment = () => {
        if (!newContent.trim()) {
            Swal.fire({
                icon: 'warning',
                title: '빈 댓글',
                text: '댓글 내용을 입력하세요',
                confirmButtonColor: '#3085d6',
            });
            return;
        }
        const params = new URLSearchParams();
        params.append("zodiac", zodiac);
        params.append("mbti", mbti);
        params.append("horoscope", horoscope);
        params.append("content", newContent);

        fetch("/api/add", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: params.toString(),
        })
            .then(res => res.text())
            .then(text => {
                Swal.fire({
                    icon: 'success',
                    title: '댓글 작성 완료',
                    text,
                    timer: 1500,
                    showConfirmButton: false,
                });
                setNewContent("");
                fetchComments();
            })
            .catch(() => {
                Swal.fire({
                    icon: 'error',
                    title: '작성 실패',
                    text: '댓글 작성 중 오류가 발생했습니다',
                });
            });
    };

    // 댓글 삭제 핸들러
    const handleDeleteComment = (id) => {
        Swal.fire({
            title: '댓글 삭제',
            text: "댓글을 삭제하시겠습니까?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: '삭제',
            cancelButtonText: '취소'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`/api/delete/${id}`, { method: "DELETE" })
                    .then(res => res.text())
                    .then(text => {
                        Swal.fire({
                            icon: 'success',
                            title: '삭제 완료',
                            text,
                            timer: 1500,
                            showConfirmButton: false,
                        });
                        fetchComments();
                    })
                    .catch(() => {
                        Swal.fire({
                            icon: 'error',
                            title: '삭제 실패',
                            text: '댓글 삭제 중 오류가 발생했습니다',
                        });
                    });
            }
        });
    };

    // 댓글 수정 핸들러
    const handleUpdateComment = (id, oldContent) => {
        Swal.fire({
            title: '댓글 수정',
            input: 'textarea',
            inputLabel: '댓글을 수정하세요',
            inputValue: oldContent,
            showCancelButton: true,
            confirmButtonText: '수정',
            cancelButtonText: '취소',
            inputValidator: (value) => {
                if (!value.trim()) {
                    return '내용이 비어있을 수 없습니다!';
                }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const params = new URLSearchParams();
                params.append("content", result.value);

                fetch(`/api/update/${id}`, {
                    method: "PUT",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: params.toString(),
                })
                    .then(res => res.text())
                    .then(text => {
                        Swal.fire({
                            icon: 'success',
                            title: '수정 완료',
                            text,
                            timer: 1500,
                            showConfirmButton: false,
                        });
                        fetchComments();
                    })
                    .catch(() => {
                        Swal.fire({
                            icon: 'error',
                            title: '수정 실패',
                            text: '댓글 수정 중 오류가 발생했습니다',
                        });
                    });
            }
        });
    };

    if (loading) return <div className="loading">로딩중...</div>;
    if (error) return <div className="error">에러 발생: {error}</div>;
    if (!resultData) return <div className="no-result">결과가 없습니다.</div>;

    return (
        <div className="result-container">
            <div className="result-summary">
                <div className="summary-item">
                    <span role="img" aria-label="띠">
                        {zodiacEmojis[zodiac] || "❓"}
                    </span>
                    <strong>{zodiac}</strong>
                </div>
                <div className="summary-item">
                    <span role="img" aria-label="MBTI">
                        {mbtiEmojis[mbti] || "❓"}
                    </span>
                    <strong>{mbti}</strong>
                </div>
                <div className="summary-item">
                    <span role="img" aria-label="별자리">
                        {horoscopeEmojis[horoscope] || "❓"}
                    </span>
                    <strong>{horoscope}</strong>
                </div>
            </div>

            <div className="result-section">
                <h3>대인 관계</h3>
                <p>{resultData.interpersonalRelationship}</p>
            </div>

            <div className="result-section">
                <h3>최적 궁합</h3>
                <p>{resultData.bestMatchCombo}</p>
            </div>

            <div className="result-section">
                <h3>커뮤니케이션 스타일</h3>
                <p>{resultData.communicationStyle}</p>
            </div>

            <div className="result-section">
                <h3>의사결정 스타일</h3>
                <p>{resultData.decisionStyle}</p>
            </div>

            <div className="result-section">
                <h3>점술사의 한줄평</h3>
                <p>{resultData.advice}</p>
            </div>

            {/* 댓글영역 */}
            <div className="comments-section">
                <h3>코멘트 (Comment)</h3>
                <textarea
                    rows={3}
                    style={{ width: '100%', resize: 'vertical' }}
                    placeholder="댓글을 입력하세요"
                    value={newContent}
                    onChange={e => setNewContent(e.target.value)}
                />
                <button onClick={handleAddComment}>댓글 작성</button>

                <div className="comments-list-header">
                    <div className="header-author">작성자</div>
                    <div className="header-content">코멘트</div>
                    <div>수정 / 삭제</div>
                </div>

                {commentsLoading ? (
                    <p className="comments-loading">댓글 로딩중...</p>
                ) : comments.length === 0 ? (
                    <p className="comments-empty">댓글이 없습니다.</p>
                ) : (
                    <div className="comments-list">
                        {[...comments].sort((a, b) => {
                            const aIsMine = String(a.user?.id) === String(currentUser?.id);
                            const bIsMine = String(b.user?.id) === String(currentUser?.id);
                            if (aIsMine && !bIsMine) return -1;
                            if (!aIsMine && bIsMine) return 1;
                            return 0;
                        }).map(c => (
                            <div key={c.id} className="comment-item">

                                <div className="comment-author-box">
                                    <small className="comment-author">{c.user?.username || '알 수 없음'}</small>
                                </div>

                                <div className="comment-content-box">
                                    <p className="comment-content">{c.content}</p>
                                </div>

                                <div className="comment-buttons-box">
                                    {String(currentUser?.id) === String(c.user?.id) && (
                                        <>
                                            <button className="btn-edit" onClick={() => handleUpdateComment(c.id, c.content)}>수정</button>
                                            <button className="btn-delete" onClick={() => handleDeleteComment(c.id)}>삭제</button>
                                        </>
                                    )}
                                </div>

                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export default ResultPage;
