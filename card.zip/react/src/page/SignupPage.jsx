import React, { useState } from 'react';
import Swal from 'sweetalert2';
import {useNavigate} from "react-router-dom";

function SignupPage({ onBack }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [passwordConfirm, setPasswordConfirm] = useState('');
    const [error, setError] = useState('');



    const handleSignup = async (e) => {
        e.preventDefault();
        setError('');

        if (!username || !password || !passwordConfirm) {
            setError('모든 항목을 입력하세요.');
            return;
        }

        if (password !== passwordConfirm) {
            setError('비밀번호가 일치하지 않습니다.');
            return;
        }

        try {
            const response = await fetch("/api/signup", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password }),
            });

            if (response.ok) {
                await Swal.fire({
                    icon: 'success',
                    title: '회원가입 완료',
                    text: '회원가입이 성공적으로 완료되었습니다.',
                    timer: 1500,
                    showConfirmButton: false,
                });
                onBack();


            } else {
                const data = await response.json();
                setError(data.message || '회원가입 실패');
            }
        } catch {
            setError('서버와 통신 중 오류가 발생했습니다.');
        }
    };

    return (
        <div style={styles.container}>
            <h2 style={styles.title}>회원가입</h2>
            <form onSubmit={handleSignup} style={styles.form}>
                <div style={styles.formGroup}>
                    <label style={styles.label}>아이디</label>
                    <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        autoFocus
                        style={styles.input}
                        placeholder="아이디를 입력하세요"
                    />
                </div>

                <div style={styles.formGroup}>
                    <label style={styles.label}>비밀번호</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        style={styles.input}
                        placeholder="비밀번호를 입력하세요"
                    />
                </div>

                <div style={styles.formGroup}>
                    <label style={styles.label}>비밀번호 확인</label>
                    <input
                        type="password"
                        value={passwordConfirm}
                        onChange={(e) => setPasswordConfirm(e.target.value)}
                        style={styles.input}
                        placeholder="비밀번호를 다시 입력하세요"
                    />
                </div>

                {error && <div style={styles.error}>{error}</div>}

                <button type="submit" style={styles.submitBtn} >
                    회원가입
                </button>
            </form>

            <button onClick={onBack} style={styles.backBtn}>
                뒤로가기
            </button>
        </div>
    );
}

const styles = {
    container: {
        maxWidth: '400px',
        margin: '3rem auto',
        padding: '2rem',
        backgroundColor: '#1e1e2f',
        borderRadius: '10px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.5)',
        color: '#eee',
        fontFamily: "'Noto Sans KR', sans-serif",
        textAlign: 'center',
    },

    formGroup: {
        marginBottom: '1rem',
        textAlign: 'left',
    },

    label: {
        display: 'block',
        marginBottom: '0.4rem',
        fontWeight: '600',
        fontSize: '1rem',
        color: '#bbb',
    },

    input: {
        width: '100%',
        padding: '0.5rem 0.75rem',
        fontSize: '1rem',
        borderRadius: '6px',
        border: '1px solid #444',
        backgroundColor: '#2a2a40',
        color: '#eee',
        boxSizing: 'border-box',
        transition: 'border-color 0.25s ease',
        outline: 'none',
    },

    error: {
        marginBottom: '1rem',
        color: '#ff6b6b',
        fontWeight: '600',
        fontSize: '0.9rem',
    },

    submitBtn: {
        width: '100%',
        padding: '0.7rem',
        fontSize: '1rem',
        backgroundColor: '#8a79ff',
        color: '#fff',
        border: 'none',
        borderRadius: '8px',
        cursor: 'pointer',
        transition: 'background-color 0.3s ease',
    },

    backBtn: {
        marginTop: '0.5rem',
        width: '100%',
        padding: '0.5rem',
        fontSize: '0.95rem',
        backgroundColor: '#444666',
        color: '#ccc',
        border: 'none',
        borderRadius: '8px',
        cursor:'pointer'
    },
};

export default SignupPage;
