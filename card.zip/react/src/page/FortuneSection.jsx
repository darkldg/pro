import React, { useEffect, useState } from 'react';
import DigitalClock from './Clock.jsx';

import myClockImage from '/src/image/1.jpg';


const FortuneSection = () => {
    const messages = [
        "“세 가지 조각이 모이면, 당신을 비추는 하나의 거울이 됩니다”",
        "“당신 안의 조각들이 하나로 어우러질 때, 진짜 당신이 보입니다”",
        "“나를 이루는 조각들을 이해할 때, 삶은 더 깊어집니다”",
        "“조각난 마음도 맞춰 보면, 온전한 나를 만날 수 있습니다”",
        "“세 가지 시선이 겹쳐질 때, 나를 향한 진실이 드러납니다”"
    ];

    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex(prev => (prev + 1) % messages.length);
        }, 3000); // 3초마다 문구 변경
        return () => clearInterval(interval);
    }, []);

    return (
        <>
            <div className="fortune-message">
                {messages[index]}
            </div>
            <DigitalClock imageUrl={myClockImage} />
        </>
    );
};

export default FortuneSection;
