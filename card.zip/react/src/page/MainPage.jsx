import React, { useState } from 'react';
import './MainPage.css';

import SelectCategory from '../SelectCategory';
import ResultPage from './ResultPage';
import DetailPage from './DetailPage';
import FortuneSection from './FortuneSection';
import LoginPage from "./LoginPage.jsx";

import SignupPage from "./SignupPage.jsx";






function MainPage({ zodiac, setZodiac, mbti, setMbti, horoscope, setHoroscope,loggedIn,setLoggedIn,onLogin,username,currentUser }) {
    const allSelected = zodiac && mbti && horoscope;

    const [activePage, setActivePage] = useState(null);
    const [detailInfo, setDetailInfo] = useState(null);

    const [showSignupModal, setShowSignupModal] = useState(false);






    const handleClick = () => {
        setActivePage(null);
        setDetailInfo(null);
    };



    const goToResult = () => {
        if (allSelected) {
            setActivePage('result');
            setDetailInfo(null); // 디테일 닫기
        }
    };

    const handleSelect = (type) => {
        setActivePage(`select-${type}`);
        setDetailInfo(null); // 선택 페이지로 갈 때 디테일 닫기
    };

    // 상세 화면 닫기용
    const closeDetail = () => {
        setDetailInfo(null);
    };

    return (
        <div className='main-background'>
            <div className="main-container p-4">
                <LoginPage
                    loggedIn={loggedIn}
                    setLoggedIn={setLoggedIn}  // 필요 시 유지
                    onLogin={onLogin}
                    onLogout={() => setLoggedIn(false)}
                    onShowSignup={() => setShowSignupModal(true)}
                    username={username}
                />




                {/* 드롭박스 선택 (기존 그대로) */}
                {loggedIn &&(
                    <div className="d-flex gap-3 flex-wrap align-items-center justify-content-center">

                        <div className="select-wrapper">
                            <select className="custom-select" value={zodiac} onChange={(e) => setZodiac(e.target.value)}>
                                <option value="">띠 선택</option>
                                <option value="쥐">쥐</option>
                                <option value="소">소</option>
                                <option value="호랑이">호랑이</option>
                                <option value="토끼">토끼</option>
                                <option value="용">용</option>
                                <option value="뱀">뱀</option>
                                <option value="말">말</option>
                                <option value="양">양</option>
                                <option value="원숭이">원숭이</option>
                                <option value="닭">닭</option>
                                <option value="개">개</option>
                                <option value="돼지">돼지</option>
                            </select>
                        </div>

                        <div className="select-wrapper">
                            <select className="custom-select" value={mbti} onChange={(e) => setMbti(e.target.value)}>
                                <option value="">MBTI 선택</option>
                                <option value="INTJ">INTJ</option>
                                <option value="INTP">INTP</option>
                                <option value="ENTJ">ENTJ</option>
                                <option value="ENTP">ENTP</option>
                                <option value="INFJ">INFJ</option>
                                <option value="INFP">INFP</option>
                                <option value="ENFJ">ENFJ</option>
                                <option value="ENFP">ENFP</option>
                                <option value="ISTJ">ISTJ</option>
                                <option value="ISFJ">ISFJ</option>
                                <option value="ESTJ">ESTJ</option>
                                <option value="ESFJ">ESFJ</option>
                                <option value="ISTP">ISTP</option>
                                <option value="ISFP">ISFP</option>
                                <option value="ESTP">ESTP</option>
                                <option value="ESFP">ESFP</option>
                            </select>
                        </div>

                        <div className="select-wrapper">
                            <select className="custom-select" value={horoscope} onChange={(e) => setHoroscope(e.target.value)}>
                                <option value="">별자리 선택</option>
                                <option value="물병자리">물병자리</option>
                                <option value="물고기자리">물고기자리</option>
                                <option value="양자리">양자리</option>
                                <option value="황소자리">황소자리</option>
                                <option value="쌍둥이자리">쌍둥이자리</option>
                                <option value="게자리">게자리</option>
                                <option value="사자자리">사자자리</option>
                                <option value="처녀자리">처녀자리</option>
                                <option value="천칭자리">천칭자리</option>
                                <option value="전갈자리">전갈자리</option>
                                <option value="사수자리">사수자리</option>
                                <option value="염소자리">염소자리</option>
                            </select>
                        </div>


                        <button className="btn btn-light" onClick={goToResult} disabled={!allSelected}>
                            결과 보기
                        </button>
                    </div>
                )}
                {/* 카드 선택 */}
                <div className="d-flex justify-content-center gap-4 flex-wrap mt-4">
                    <div className="custom-card" onClick={() => handleSelect('zodiac')}>
                        <div className="card-overlay">
                            <h5 className="card-title">12간지</h5>
                            <p className="card-text">당신의 12간지 띠를 선택해 보세요</p>
                        </div>
                    </div>

                    <div className="custom-card" onClick={() => handleSelect('mbti')}>
                        <div className="card-overlay">
                            <h5 className="card-title">MBTI</h5>
                            <p className="card-text">당신의 MBTI를 선택해 보세요</p>
                        </div>
                    </div>

                    <div className="custom-card" onClick={() => handleSelect('horoscope')}>
                        <div className="card-overlay">
                            <h5 className="card-title">별자리</h5>
                            <p className="card-text">당신의 별자리를 선택해 보세요</p>
                        </div>
                    </div>
                </div>
                <br/>
                <br/>
                {/* 점술사 이미지 */}
                <div className="fortune-teller-container">

                    <img
                        src="/src/image/teller.jpg"
                        alt="점술사 이미지"
                        className="fortune-teller-image"
                        onClick={handleClick}
                        style={{ cursor: 'pointer' }}
                    />


                    <p className="fortune-caption">고요하고 신비로운 점술사의 공간</p>
                </div>


                {/* 하단 엘리멘털 렌더링 영역 */}
                <div style={{ marginTop: '2rem'}}>

                    {showSignupModal && (
                        <SignupPage onBack={() => setShowSignupModal(false)} />
                    )}


                    {/* 결과 페이지 */}
                    {activePage === 'result' && !detailInfo && (
                        <ResultPage zodiac={zodiac} mbti={mbti} horoscope={horoscope} />
                    )}

                    {/* 선택 페이지 + 상세보기 화면 구분 렌더링 */}

                    {/* 디테일이 없을 때 선택 리스트 보여줌 */}
                    {activePage === 'select-zodiac' && !detailInfo && (
                        <SelectCategory
                            title="띠"
                            category="zodiac"
                            onSelect={(name) => {
                                setZodiac(name);
                                setDetailInfo({ type: 'zodiac', name });
                            }}
                            selected={zodiac}
                            onDetailOpen={setDetailInfo}
                        />
                    )}

                    {activePage === 'select-mbti' && !detailInfo && (
                        <SelectCategory
                            title="MBTI"
                            category="mbti"
                            onSelect={(name) => {
                                setZodiac(name);           // 선택값 저장
                                setDetailInfo({ type: 'mbti', name });  // 상세 열기
                            }}
                            selected={mbti}
                            onDetailOpen={setDetailInfo}
                        />
                    )}

                    {activePage === 'select-horoscope' && !detailInfo && (
                        <SelectCategory
                            title="별자리"
                            category="horoscope"
                            onSelect={(name) => {
                                setZodiac(name);           // 선택값 저장
                                setDetailInfo({ type: 'horoscope', name });  // 상세 열기
                            }}
                            selected={horoscope}
                            onDetailOpen={setDetailInfo}
                        />
                    )}




                    {/* detailInfo가 있을 때는 DetailComponent 렌더링 */}
                    {detailInfo && (
                        <DetailPage
                            info={detailInfo}
                            onBack={closeDetail}
                        />
                    )}

                    {/* 아무 것도 렌더링 안 될 때 기본 문구 */}
                    {!activePage && !detailInfo && <FortuneSection />}


                </div>

            </div>
        </div>
    );
}

export default MainPage;
