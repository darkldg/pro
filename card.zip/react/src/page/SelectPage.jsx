import { useParams } from "react-router-dom";
import SelectCategory from "../SelectCategory";

function SelectPage({ zodiac, mbti, horoscope, setZodiac, setMbti, setHoroscope }) {
    const { category } = useParams();

    let title = "";
    let selected = "";
    let onSelect;

    switch (category) {
        case "zodiac":
            title = "띠";
            selected = zodiac;
            onSelect = setZodiac;
            break;
        case "mbti":
            title = "MBTI";
            selected = mbti;
            onSelect = setMbti;
            break;
        case "horoscope":
            title = "별자리";
            selected = horoscope;
            onSelect = setHoroscope;
            break;
        default:
            return <div>잘못된 카테고리입니다.</div>;
    }

    return (
        <SelectCategory
            title={title}
            selected={selected}
            onSelect={onSelect}
            category={category}
        />
    );
}

export default SelectPage;
