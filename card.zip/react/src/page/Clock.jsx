import React, { useEffect, useState } from 'react';
import { useSpring, animated } from '@react-spring/web';

const HAND_LENGTHS = {
    hour: 40,
    minute: 70,
    second: 75,
};

function Clock({ imageUrl }) {
    const [now, setNow] = useState(new Date());

    // 1초마다 실제 시간을 반영
    useEffect(() => {
        const interval = setInterval(() => {
            setNow(new Date());
        }, 1000); // 정확히 1초 간격으로 동기화
        return () => clearInterval(interval);
    }, []);

    // 시간 계산
    const seconds = now.getSeconds();
    const minutes = now.getMinutes() + seconds / 60;
    const hours = now.getHours() % 12 + minutes / 60;

    const secondAngle = seconds * 6;      // 360 / 60
    const minuteAngle = minutes * 6;      // 360 / 60
    const hourAngle = hours * 30;         // 360 / 12

    // 애니메이션: 반응성은 유지하되, 부드러움보다는 정확도 위주
    const secondHandProps = useSpring({ rotate: secondAngle });
    const minuteHandProps = useSpring({ rotate: minuteAngle });
    const hourHandProps = useSpring({ rotate: hourAngle });

    return (
        <div
            style={{
                width: 380,
                height: 380,
                margin: 'auto',
                borderRadius: '50%',
                backgroundImage: `url(${imageUrl})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                boxShadow: '0 0 20px rgba(0, 0, 0, 0.4)',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                position: 'relative',
                overflow: 'hidden',
            }}
        >
            <svg viewBox="0 0 200 200" width="90%" height="90%">
                {/* 시계 중심 점 */}
                <circle cx="100" cy="100" r="3" fill="rgba(255,255,255,0.7)" />

                {/* 시침 */}
                <animated.line
                    x1="100"
                    y1="100"
                    x2="100"
                    y2={100 - HAND_LENGTHS.hour}
                    stroke="#ffffff"
                    strokeWidth="4"
                    strokeLinecap="round"
                    style={{
                        transformOrigin: '100px 100px',
                        transform: hourHandProps.rotate.to(r => `rotate(${r}deg)`),
                    }}
                />

                {/* 분침 */}
                <animated.line
                    x1="100"
                    y1="100"
                    x2="100"
                    y2={100 - HAND_LENGTHS.minute}
                    stroke="#ffffff"
                    strokeWidth="3"
                    strokeLinecap="round"
                    style={{
                        transformOrigin: '100px 100px',
                        transform: minuteHandProps.rotate.to(r => `rotate(${r}deg)`),
                    }}
                />

                {/* 초침 */}
                <animated.line
                    x1="100"
                    y1="100"
                    x2="100"
                    y2={100 - HAND_LENGTHS.second}
                    stroke="#FF0000"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    style={{
                        transformOrigin: '100px 100px',
                        transform: secondHandProps.rotate.to(r => `rotate(${r}deg)`),
                    }}
                />
            </svg>
        </div>
    );
}

export default Clock;
