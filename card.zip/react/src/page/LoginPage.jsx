import React, { useState } from "react";
import "./LoginPage.css";

function LoginPage({ loggedIn, username, onLogin, onLogout, onShowSignup }) {
    const [inputUsername, setInputUsername] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (typeof onLogin === "function") {
            await onLogin(inputUsername, password);
        } else {
            console.error("onLogin is not a function");
        }
    };

    return (
        <header className="header">
            {loggedIn ? (
                <div className="welcome">
                    <span>🔮 안녕하세요, {username}님! 오늘도 특별한 하루가 되길 바랍니다. 점술가가 함께합니다.</span>


                    <button onClick={onLogout} className="button">로그아웃</button>
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="form">
                    <input
                        type="text"
                        placeholder="아이디"
                        value={inputUsername}
                        onChange={(e) => setInputUsername(e.target.value)}
                        className="input"
                    />
                    <input
                        type="password"
                        placeholder="비밀번호"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="input"
                    />
                    <button type="submit" className="button">로그인</button>
                    <button type="button" onClick={onShowSignup}>회원가입</button>
                </form>
            )}
        </header>
    );
}

export default LoginPage;
