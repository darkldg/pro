import React, { useEffect, useState } from "react";

export default function MainIntro({ onClick }) {
    const [fadeIn, setFadeIn] = useState(false);

    useEffect(() => {
        setTimeout(() => setFadeIn(true), 100);

        // ✨ 애니메이션 직접 정의 (처음에 1번만 실행됨)
        const style = document.createElement("style");
        style.innerHTML = `
            @keyframes glowPulse {
                0%, 100% {
                    text-shadow: 0 0 8px #fffcc0, 0 0 16px #ffe98a;
                }
                50% {
                    text-shadow: 0 0 20px #fffcc0, 0 0 40px #ffe98a;
                }
            }
            @keyframes float {
                0%, 100% {
                    transform: translateY(0);
                }
                50% {
                    transform: translateY(-8px);
                }
            }
        `;
        document.head.appendChild(style);
    }, []);

    return (
        <div style={{ ...styles.container }} onClick={onClick}>
            <div style={styles.overlay} />
            <div style={{ ...styles.textBox, ...(fadeIn ? styles.fadeIn : {}) }}>
                <h1 style={{ ...styles.title, ...styles.glow }}>
                    The Three Keys
                </h1>
                <p style={styles.subtitle}>3 가지의 열쇠로 나를 풀어보다.</p>
            </div>
        </div>
    );
}

const styles = {
    container: {
        position: "relative",
        width: "1100px",
        height: "700px",
        backgroundImage: `url('/src/image/mainimage.jpg')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        cursor: "pointer",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        animation: "float 6s ease-in-out infinite", // ✨
    },
    overlay: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.7))",
        zIndex: 1,
        backdropFilter: "blur(3px)",
    },
    textBox: {
        position: "relative",
        zIndex: 2,
        textAlign: "center",
        color: "#fffbea",
        padding: "2.5rem",
        backgroundColor: "rgba(0, 0, 0, 0.3)",
        borderRadius: "1.5rem",
        backdropFilter: "blur(5px)",
        maxWidth: "90%",
        opacity: 0,
        transform: "translateY(20px)",
        transition: "opacity 1.5s ease, transform 1.5s ease",
    },
    fadeIn: {
        opacity: 1,
        transform: "translateY(0)",
    },
    title: {
        fontSize: "clamp(2.5rem, 5vw, 4rem)",
        fontWeight: "bold",
        marginBottom: "1rem",
        textShadow: "0 0 20px rgba(255, 255, 200, 0.5), 0 0 40px rgba(255, 255, 255, 0.3)",
        lineHeight: 1.3,
    },
    subtitle: {
        fontSize: "clamp(1rem, 2vw, 1.5rem)",
        fontWeight: "300",
        color: "#fef9c3",
        textShadow: "0 2px 6px rgba(0, 0, 0, 0.6)",
    },
    glow: {
        animation: "glowPulse 2.5s ease-in-out infinite",
    },
};


