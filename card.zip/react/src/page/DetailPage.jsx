import { useEffect, useState } from "react";
import './DetailPage.css';

function DetailPage({ info, onBack }) {
    const { type, name,img } = info;
    const [detailData, setDetailData] = useState(null);

    useEffect(() => {
        if (!type || !name) return;
        console.log('url : ', `/api/info/${type}/${name}`)
        fetch(`/api/info/${type}/${name}`)

            .then(res => {
                if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
                return res.json();
            })
            .then(data => setDetailData(data))
            .catch(err => console.error(err));
    }, [type, name]);

    if (!detailData) return <div className="detail-loading">로딩 중...</div>;

    return (
        <div className="detail-container">


            {/* ★ img 있으면 그대로 사용, 없으면 API 응답에 이미지 필드가 있다면 거기로 대체 */}
            {(img || detailData.image) && (
                <img
                    className="detail-hero"
                    src={img || detailData.image}
                    alt={detailData.name}
                />
            )}

            <div className="detail-card">
                <h2 className="detail-title">{detailData.name}</h2>


                <div className="detail-section">
                    <h4>🌟 강점</h4>
                    <p>{detailData.strengths}</p>
                </div>

                <div className="detail-section">
                    <h4>⚠️ 약점</h4>
                    <p>{detailData.weaknesses}</p>
                </div>
                <div className="detail-section">
                    <h4>💡 직업</h4>
                    <p>{detailData.ideal_role}</p>
                </div>
                <div className="detail-section">
                    <h4>🌟 성격</h4>
                    <p>{detailData.personality}</p>
                </div>


            </div>
        </div>
    );
}

export default DetailPage;
