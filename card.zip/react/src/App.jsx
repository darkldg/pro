import './App.css';
import MainPage from "./page/MainPage.jsx";
import SelectPage from "./page/SelectPage.jsx";
import ResultPage from "./page/ResultPage.jsx";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useState } from "react";
import DetailPage from "./page/DetailPage.jsx";
import SignupPage from "./page/SignupPage.jsx";
import IntroPage from "./page/IntroPage.jsx";
import LoginPage from "./page/LoginPage.jsx";

function App() {
    const [loggedIn, setLoggedIn] = useState(false);  // 초기값 false로 변경 권장
    const [zodiac, setZodiac] = useState("");
    const [mbti, setMbti] = useState("");
    const [horoscope, setHoroscope] = useState("");
    const [showIntro, setShowIntro] = useState(true);
    const [username, setUsername] = useState("");
    const [currentUser, setCurrentUser] = useState(null);

    const handleLogin = async (username, password) => {
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ username, password }),
            });
            const data = await response.json();
            console.log('로그인 응답 user:', data.user);
            if (response.ok && data.message === '로그인 성공') {
                setLoggedIn(true);
                setUsername(username);
                if (data.user) {
                    setCurrentUser(data.user);
                    localStorage.setItem("currentUser", JSON.stringify(data.user));
                } else {
                    setCurrentUser({ username });
                    localStorage.setItem("currentUser", JSON.stringify({ username }));
                }
            } else {
                alert('로그인 실패: ' + (data.message || '알 수 없는 오류'));
                setLoggedIn(false);
                setCurrentUser(null); // 실패시 초기화
            }
        } catch (error) {
            alert('서버와 통신 중 오류가 발생했습니다.');
            console.error(error);
            setLoggedIn(false);
            setCurrentUser(null);
        }
    };

    const handleLogout = () => {
        setLoggedIn(false);
        setCurrentUser(null);
        localStorage.removeItem("currentUser"); // 로그아웃시 제거
    };

    if (showIntro) {
        return <IntroPage onClick={() => setShowIntro(false)} />;
    }

    return (
        <BrowserRouter>
            <Routes>
                {/* 메인 페이지에 선택 상태 값 전달 */}
                <Route
                    path="/"
                    element={
                        <MainPage
                            zodiac={zodiac}
                            setZodiac={setZodiac}
                            mbti={mbti}
                            setMbti={setMbti}
                            horoscope={horoscope}
                            setHoroscope={setHoroscope}
                            loggedIn={loggedIn}
                            setLoggedIn={setLoggedIn}
                            onLogin={handleLogin}
                            username={username}
                            currentUser={currentUser}
                        />
                    }
                />

                {/* 선택 페이지에 상태 변경 함수들 전달 */}
                <Route
                    path="/select/:category"
                    element={
                        <SelectPage
                            setZodiac={setZodiac}
                            setMbti={setMbti}
                            setHoroscope={setHoroscope}
                        />
                    }
                />

                {/* 로그인 상태에 따라 결과 페이지 접근 제한 */}
                <Route
                    path="/result"
                    element={
                        loggedIn ? (
                            <ResultPage zodiac={zodiac}  currentUser={currentUser} mbti={mbti} horoscope={horoscope} />
                        ) : (
                            <Navigate to="/login" replace />
                        )
                    }
                />

                <Route path="/detail/:type/:name" element={<DetailPage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route
                    path="/login"
                    element={
                        <LoginPage
                            loggedIn={loggedIn}
                            username={username}
                            onLogin={handleLogin}
                            onLogout={handleLogout}

                        />
                    }
                />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
