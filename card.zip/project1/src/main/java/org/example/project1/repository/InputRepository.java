package org.example.project1.repository;

import org.example.project1.entity.Input;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface InputRepository extends JpaRepository<Input, Long> {
    Optional<Input> findByZodiacAndMbtiAndHoroscope(String zodiac, String mbti, String horoscope);

}
