package org.example.project1.controller;


import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.example.project1.entity.Comment;
import org.example.project1.entity.User;
import org.example.project1.service.CommentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CommentController {
    private final CommentService commentService;

    // ✅ 댓글 생성
    @PostMapping("/add")
    public String addComment(@RequestParam String zodiac,
                             @RequestParam String mbti,
                             @RequestParam String horoscope,
                             @RequestParam String content,
                             HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "로그인 필요";

        commentService.addComment(user, zodiac, mbti, horoscope, content);
        return "코멘트 저장 완료";
    }

    // ✅ 조건별 댓글 전체 조회
    @GetMapping("/list")
    public List<Comment> getComments(@RequestParam String zodiac,
                                     @RequestParam String mbti,
                                     @RequestParam String horoscope) {
        return commentService.getComments(zodiac, mbti, horoscope);
    }

    // ✅ 댓글 수정
    @PutMapping("/update/{id}")
    public String updateComment(@PathVariable Long id,
                                @RequestParam String content,
                                HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "로그인 필요";

        boolean updated = commentService.updateComment(id, user, content);
        return updated ? "수정 완료" : "수정 실패 (권한 없음)";
    }

    // ✅ 댓글 삭제
    @DeleteMapping("/delete/{id}")
    public String deleteComment(@PathVariable Long id,
                                HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) return "로그인 필요";

        boolean deleted = commentService.deleteComment(id, user);
        return deleted ? "삭제 완료" : "삭제 실패 (권한 없음)";
    }

}
