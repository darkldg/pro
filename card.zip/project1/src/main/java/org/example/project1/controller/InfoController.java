package org.example.project1.controller;

import org.example.project1.entity.Info;
import org.example.project1.repository.InfoRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/info")
@CrossOrigin(origins = "*")  // 필요하면 CORS 허용
public class InfoController {

    private final InfoRepository infoRepository;

    public InfoController(InfoRepository infoRepository) {
        this.infoRepository = infoRepository;
    }

    // 예: /api/info/zodiac/쥐
    @GetMapping("/{type}/{name}")
    public ResponseEntity<Info> getInfoByTypeAndName(@PathVariable String type, @PathVariable String name) {
        try {
            Info info = infoRepository.findByTypeAndName(type, name);
            if (info == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(info);
        } catch (Exception e) {
            e.printStackTrace();  // 콘솔에 예외 로그 출력
            return ResponseEntity.status(500).body(null);
        }
    }

}
