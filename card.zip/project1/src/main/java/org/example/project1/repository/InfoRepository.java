package org.example.project1.repository;

import org.example.project1.entity.Info;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InfoRepository extends JpaRepository<Info, Long> {
    Info findByTypeAndName(String type, String name);  // 띠/MBTI/별자리 중 해당 이름
}
