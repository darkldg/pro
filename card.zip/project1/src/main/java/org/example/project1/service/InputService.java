package org.example.project1.service;

import org.example.project1.entity.Input;
import org.example.project1.repository.InputRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InputService {

    private final InputRepository inputRepository;

    @Autowired
    public InputService(InputRepository inputRepository) {
        this.inputRepository = inputRepository;
    }

    public Optional<Input> findByCombination(String zodiac, String mbti, String horoscope) {
        return inputRepository.findByZodiacAndMbtiAndHoroscope(zodiac, mbti, horoscope);
    }
}
