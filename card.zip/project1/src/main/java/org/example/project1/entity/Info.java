package org.example.project1.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Info {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;         // "zodiac", "mbti", "horoscope"
    private String name;         // 이름 (ex: 쥐, INTJ, 물병자리)

    @Column(length = 1000)
    private String personality;
    @Column(length = 1000)
    private String ideal_role;// 설명
    @Column(length = 1000)
    private String strengths;    // 강점
    @Column(length = 1000)
    private String weaknesses;   // 약점


}
