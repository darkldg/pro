package org.example.project1.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Input {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 예: "쥐_INTJ_물병자리"

    private String zodiac;
    private String mbti;
    private String horoscope;

    @Column(length = 2000)
    private String interpersonalRelationship;

    @Column(length = 1000)
    private String bestMatchCombo;

    @Column(length = 1000)
    private String communicationStyle;

    @Column(length = 1000)
    private String decisionStyle;

    @Column(columnDefinition = "TEXT")
    private String advice;


    // 기본 생성자
    public Input() {}
}
