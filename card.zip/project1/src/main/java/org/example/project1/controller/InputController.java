package org.example.project1.controller;

import org.example.project1.entity.Input;
import org.example.project1.service.InputService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")  // CORS 허용 (필요에 따라 조절)
public class InputController {

    private final InputService inputService;

    @Autowired
    public InputController(InputService inputService) {
        this.inputService = inputService;
    }

    // 띠, MBTI, 별자리 세 가지로 결과 조회
    @GetMapping("/result")
    public ResponseEntity<Input> getResult(
            @RequestParam String zodiac,
            @RequestParam String mbti,
            @RequestParam String horoscope

    ) {
        Optional<Input> inputOpt = inputService.findByCombination(zodiac, mbti, horoscope);
        if (inputOpt.isPresent()) {
            return ResponseEntity.ok(inputOpt.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

}
