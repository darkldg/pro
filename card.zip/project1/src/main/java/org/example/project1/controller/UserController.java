package org.example.project1.controller;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

import org.example.project1.entity.User;
import org.example.project1.service.UserService;

import org.springframework.web.bind.annotation.*;


import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // 회원가입
    @PostMapping("/signup")
    public Map<String, String> register(@RequestBody Map<String, String> user) {
        String username = user.get("username");
        String password = user.get("password");
        String result = userService.register(username, password);
        return Map.of("message", result);
    }


    // 로그인
    @PostMapping("/login")
    public Map<String, Object> login(@RequestParam String username, @RequestParam String password, HttpSession session) {
        var userOpt = userService.login(username, password);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            session.setAttribute("user", user);

            // user 객체를 통째로 넣지 않고 필요한 값만 직접 Map에 넣기
            Map<String, Object> response = new HashMap<>();
            response.put("message", "로그인 성공");
            response.put("user", Map.of(
                    "id", user.getId(),
                    "username", user.getUsername()
            ));
            return response;
        }
        return Map.of("message", "로그인 실패");
    }


    // 로그아웃
    @PostMapping("/logout")
    public Map<String, String> logout(HttpSession session) {
        session.invalidate();
        return Map.of("message", "로그아웃 완료");
    }
}


