package org.example.project1.service;


import lombok.RequiredArgsConstructor;
import org.example.project1.entity.Comment;
import org.example.project1.entity.User;
import org.example.project1.repository.CommentRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CommentService {
    private final CommentRepository commentRepositoy;

    public Comment addComment(User user, String zodiac, String mbti, String horoscope, String content) {
        Comment comment = new Comment();
        comment.setUser(user);
        comment.setZodiac(zodiac);
        comment.setMbti(mbti);
        comment.setHoroscope(horoscope);
        comment.setContent(content);
        return commentRepositoy.save(comment);
    }

    public List<Comment> getComments(String zodiac, String mbti, String horoscope) {
        return commentRepositoy.findByZodiacAndMbtiAndHoroscope(zodiac, mbti, horoscope);
    }

    public boolean updateComment(Long id, User user, String content) {
        Optional<Comment> commentOpt = commentRepositoy.findById(id);
        if (commentOpt.isPresent()) {
            Comment comment = commentOpt.get();
            if (comment.getUser().getId().equals(user.getId())) {
                comment.setContent(content);
                commentRepositoy.save(comment);
                return true;
            }
        }
        return false;
    }

    public boolean deleteComment(Long id, User user) {
        Optional<Comment> commentOpt = commentRepositoy.findById(id);
        if (commentOpt.isPresent()) {
            Comment comment = commentOpt.get();
            if (comment.getUser().getId().equals(user.getId())) {
                commentRepositoy.delete(comment);
                return true;
            }
        }
        return false;
    }
}
