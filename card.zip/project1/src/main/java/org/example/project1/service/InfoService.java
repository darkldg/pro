package org.example.project1.service;

public class InfoService {
}
