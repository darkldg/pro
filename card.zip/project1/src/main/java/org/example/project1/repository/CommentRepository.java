package org.example.project1.repository;

import org.example.project1.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository  extends JpaRepository<Comment, Long> {
    List<Comment> findByZodiacAndMbtiAndHoroscope(String zodiac, String mbti, String horoscope);
}
