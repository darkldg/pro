package org.example.project1.service;

import lombok.RequiredArgsConstructor;
import org.example.project1.entity.User;
import org.example.project1.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    // 회원가입
    public String register(String username, String password) {

        User user = new User();
        user.setUsername(username);
        user.setPassword(password); // 간단히, 암호화 안 함(프로젝트 용)
        userRepository.save(user);
        return "회원가입 성공";
    }

    // 로그인 (아이디와 비밀번호 체크)
    public Optional<User> login(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent() && userOpt.get().getPassword().equals(password)) {
            return userOpt;
        }
        return Optional.empty();
    }
}