package com.example.back.repository;

import com.example.back.entity.Monster; // Monster 엔티티 임포트
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Monster 엔티티에 대한 데이터 접근 계층 (Repository).
 * JpaRepository를 상속받아 기본적인 CRUD 및 페이징/정렬 기능을 자동으로 제공받습니다.
 * <Monster: 관리할 엔티티 타입, String: 엔티티의 ID 타입>
 */
@Repository
public interface MonsterRepository extends JpaRepository<Monster, String> {
    // 필요한 경우 여기에 추가적인 사용자 정의 쿼리 메서드를 정의할 수 있습니다.
    // 예: List<Monster> findByName(String name);
    // 예: Optional<Monster> findByTypeAndStage(String type, int stage);
    List<Monster> findByType(String type);
}