package com.example.back.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import jakarta.persistence.FetchType;
import com.example.back.entity.UnitType;
import com.example.back.entity.UnitClass;
import com.example.back.entity.UnitRarity;
import com.example.back.entity.Skill;
// Skill 엔티티 임포트. Skill.java 파일에 패키지 선언이 없으므로, Unit.java와 같은 패키지에 있다고 가정합니다.
// 만약 Skill.java에 package com.example.yourgame.entity; 가 없다면 추가해줘야 합니다.
// 그리고 이 import 문도 필요 없어집니다.


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "units")
public class Unit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name", nullable = false, length = 50)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "unit_type", nullable = false)
    private UnitType unitType;

    @Enumerated(EnumType.STRING)
    @Column(name = "unit_class", nullable = false)
    private UnitClass unitClass;

    @Enumerated(EnumType.STRING)
    @Column(name = "unit_rarity", nullable = false)
    private UnitRarity unitRarity;

    @Column(name = "base_attack", nullable = false)
    private int baseAttack;

    @Column(name = "base_defense", nullable = false)
    private int baseDefense;

    @Column(name = "base_health", nullable = false)
    private int baseHealth;

    @Column(name = "description", length = 500)
    private String description;

    @ManyToOne(fetch = FetchType.LAZY) // ⭐ EAGER 대신 LAZY로 변경 ⭐
    @JoinColumn(name = "passive_skill_id")
    private Skill passiveSkill;

    @Column(name = "illustration_url", length = 255)
    private String illustrationUrl; // 유닛 이미지 URL

    @Column(name = "required_barracks_level", nullable = false)
    private int requiredBarracksLevel; // 유닛 훈련에 필요한 최소 병영 레벨

    // 유닛 훈련 비용
    @Column(name = "gold_cost", nullable = false)
    private int goldCost;
    @Column(name = "wood_cost", nullable = false)
    private int woodCost;
    @Column(name = "iron_cost", nullable = false)
    private int ironCost;

    // 훈련에 걸리는 시간 (초)
    @Column(name = "training_duration_seconds", nullable = false)
    private int trainingDurationSeconds;

    public boolean isHeroUnit() {
        // unitType이 HERO인 경우에만 영웅으로 간주합니다.
        // 만약 UnitType.HERO가 없다면 UnitType enum에 추가하거나,
        // 다른 필드 (예: unitClass나 unitRarity)로 영웅을 식별하는 로직으로 변경해야 합니다.
        return this.unitType == UnitType.HERO;
    }

    // 영웅 전용 필드 (일반 유닛의 경우 null 또는 0)
    // @Column(name = "hero_type", length = 50)
    // private String heroType; // 예: "딜러", "탱커", "힐러"
}