package com.example.back.repository;

import com.example.back.entity.PlayerHeroMastery;
import com.example.back.entity.User;
import com.example.back.entity.Unit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PlayerHeroMasteryRepository extends JpaRepository<PlayerHeroMastery, Long> {
    // 특정 플레이어가 특정 영웅 종류에 대한 마스터리 정보를 가지고 있는지 확인
    Optional<PlayerHeroMastery> findByPlayerAndUnit(User player, Unit unit);
}