// PartyItemRequestDto.java
package com.example.back.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PartyItemRequestDto {
    private Long id; // 영웅 ID (PlayerOwnedHero ID) 또는 유닛 ID (UserUnit ID)
    private String type; // "HERO" 또는 "UNIT"
    private Integer slotIndex; // 파티 슬롯 인덱스 (0, 1, 2, 3)
}