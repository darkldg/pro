package com.example.back.entity;

public enum UnitType { // public 키워드 추가
    HERO,
    SOLDIER
}