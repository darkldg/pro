package com.example.back.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity // 이 클래스가 JPA 엔티티임을 나타냅니다.
@Table(name = "skills") // 매핑될 데이터베이스 테이블 이름을 지정합니다. (일반적으로 클래스명과 동일하면 생략 가능)
@Getter // Lombok: 모든 필드에 대한 Getter 메소드를 자동 생성합니다.
@Setter // Lombok: 모든 필드에 대한 Setter 메소드를 자동 생성합니다.
@NoArgsConstructor // Lombok: 기본 생성자를 자동 생성합니다.
@AllArgsConstructor // Lombok: 모든 필드를 인자로 받는 생성자를 자동 생성합니다.
@Builder // Lombok: 빌더 패턴을 사용하여 객체를 생성할 수 있게 합니다.
public class Skill {

    @Id // 기본 키(Primary Key)임을 나타냅니다.
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 데이터베이스에서 ID가 자동으로 생성되도록 합니다. (MySQL, H2 등에서 IDENTITY 사용)
    @Column(name = "skill_id") // 데이터베이스 컬럼 이름을 지정합니다.
    private Long skillId; // 스킬 고유 ID

    @Column(name = "skill_name", nullable = false, length = 100) // 스킬 이름, 필수 값이며 최대 길이 100
    private String skillName;

    @Column(name = "skill_description", length = 500) // 스킬 설명, 최대 길이 500
    private String skillDescription;

    @Enumerated(EnumType.STRING) // Enum 값을 문자열 형태로 DB에 저장
    @Column(name = "effect_type", nullable = false, length = 50)
    private SkillEffectType effectType; // 타입 변경

    @Column(name = "effect_value", nullable = false) // 스킬 효과 수치 (예: 0.1, 50)
    private Double effectValue; // 수치는 소수점도 포함할 수 있도록 Double 타입으로 정의

    enum SkillEffectType {
        ATTACK_BOOST_FLAT,     // 버프 (능력치 증가)
               DEFENSE_BOOST_FLAT,   // 디버프 (능력치 감소)
              DEFENSE_BOOST_PERCENT,   // 피해 (공격 스킬)
                ATTACK_BOOST_PERCENT,     // 회복 (체력 회복 스킬)

        // 필요한 스킬 효과 타입을 여기에 추가하세요.
    }
}