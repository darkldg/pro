// src/main/java/com/example/back/dto/TrainingQueueResponse.java (수정 제안)
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.Instant; // TrainingQueue 엔티티와 일관성을 위해 Instant 사용

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainingQueueResponse {
    private Long id; // TrainingQueue의 ID
    private Long userId;
    private Long unitId;
    private String unitName; // 프론트엔드에서 표시할 유닛 이름
    private int quantity;
    private Instant startTime;
    private Instant completionTime;
    private long remainingSeconds; // 프론트엔드에서 사용할 남은 시간 (초)
}