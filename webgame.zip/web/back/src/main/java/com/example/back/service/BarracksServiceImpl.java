package com.example.back.service.impl;

import com.example.back.dto.BarracksInfoResponse;
import com.example.back.dto.BarracksInfoResponse.ResourceCost;
import com.example.back.dto.BarracksInfoResponse.TrainableUnit;
import com.example.back.dto.BarracksInfoResponse.TrainingQueueItem;
import com.example.back.dto.BarracksInfoResponse.PartyUnit;
import com.example.back.dto.TrainUnitRequest;
import com.example.back.dto.TrainUnitResponse;
import com.example.back.entity.*;
import com.example.back.repository.*;
import com.example.back.service.BarracksService;
import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BarracksServiceImpl implements BarracksService {

    private final UserRepository userRepository;
    private final BarracksRepository barracksRepository;
    private final UnitRepository unitRepository;
    private final TrainingQueueRepository trainingQueueRepository;
    private final UserUnitRepository userUnitRepository;

    private static final int MAX_BARRACKS_LEVEL = 3; // 병영 최대 레벨을 3으로 설정


    @Autowired
    public BarracksServiceImpl(UserRepository userRepository, BarracksRepository barracksRepository,
                               UnitRepository unitRepository, TrainingQueueRepository trainingQueueRepository,
                               UserUnitRepository userUnitRepository) {
        this.userRepository = userRepository;
        this.barracksRepository = barracksRepository;
        this.unitRepository = unitRepository;
        this.trainingQueueRepository = trainingQueueRepository;
        this.userUnitRepository = userUnitRepository;
    }

    @Override
    public BarracksInfoResponse getBarracksInfo(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        Barracks barracks = barracksRepository.findByUser(user)
                .orElseThrow(() -> new EntityNotFoundException("Barracks not found for user id: " + userId));

        // 다음 업그레이드 비용 계산 (예시 로직)
        int nextLevel = barracks.getLevel() + 1;
        ResourceCost nextUpgradeCost = new ResourceCost(nextLevel * 100, nextLevel * 50, nextLevel * 20); // 예시

        // 훈련 가능한 유닛 목록 조회 (병영 레벨에 따라)
        List<Unit> allTrainableUnits = unitRepository.findByUnitType(UnitType.SOLDIER);
        List<TrainableUnit> trainableUnits = allTrainableUnits.stream()
                .filter(unit -> unit.getRequiredBarracksLevel() <= barracks.getLevel())
                .map(unit -> TrainableUnit.builder()
                        .id(unit.getId())
                        .name(unit.getName())
                        .unitType(unit.getUnitType().name())
                        .unitClass(unit.getUnitClass().name())
                        .unitRarity(unit.getUnitRarity().name())
                        .baseAttack(unit.getBaseAttack())
                        .baseDefense(unit.getBaseDefense())
                        .baseHealth(unit.getBaseHealth())
                        .illustrationUrl(unit.getIllustrationUrl())
                        .requiredBarracksLevel(unit.getRequiredBarracksLevel())
                        .goldCost(unit.getGoldCost())
                        .woodCost(unit.getWoodCost())
                        .ironCost(unit.getIronCost())
                        .trainingDurationSeconds(unit.getTrainingDurationSeconds())
                        .build())
                .collect(Collectors.toList());

        // 현재 훈련 대기열 조회
        List<TrainingQueue> currentQueue = trainingQueueRepository.findByUserIdOrderByCompletionTimeAsc(userId);
        List<TrainingQueueItem> trainingQueueItems = currentQueue.stream()
                .map(queueItem -> {
                    Unit unit = unitRepository.findById(queueItem.getUnitId())
                            .orElse(null);
                    long remainingSeconds = Duration.between(Instant.now(), queueItem.getCompletionTime()).getSeconds();
                    return TrainingQueueItem.builder()
                            .id(queueItem.getId())
                            .unitName(unit != null ? unit.getName() : "알 수 없음")
                            .quantity(queueItem.getQuantity())
                            .completionTime(queueItem.getCompletionTime())
                            .remainingSeconds(Math.max(0, remainingSeconds))
                            .build();
                })
                .collect(Collectors.toList());

        // 현재 보유 유닛 (UserUnit) 정보만 포함
        Map<Long, Integer> currentTroops = new HashMap<>();
        userUnitRepository.findByUserId(userId).forEach(uu -> currentTroops.put(uu.getUnitId(), uu.getQuantity()));

        // 보유 유닛 목록 DTO 변환 (UserUnit만)
        List<PartyUnit> ownedUnitsAndHeroes = new ArrayList<>();
        List<UserUnit> allUserUnits = userUnitRepository.findByUserId(userId);
        Set<Long> userUnitIds = allUserUnits.stream().map(UserUnit::getUnitId).collect(Collectors.toSet());
        Map<Long, Unit> userUnitDetails = unitRepository.findAllById(userUnitIds).stream() // findAllByIdWithPassiveSkill 대신 findAllById 사용
                .collect(Collectors.toMap(Unit::getId, unit -> unit));

        for (UserUnit uu : allUserUnits) {
            Unit detail = userUnitDetails.get(uu.getUnitId());
            if (detail != null) {
                ownedUnitsAndHeroes.add(PartyUnit.builder()
                        .unitId(detail.getId())
                        .name(detail.getName())
                        .illustrationUrl(detail.getIllustrationUrl())
                        .isHero(false) // UserUnit은 영웅이 아님
                        .baseAttack(detail.getBaseAttack())
                        .baseDefense(detail.getBaseDefense())
                        .build());
            }
        }

        // 현재 파티는 일단 빈 목록으로 반환 (파티 관련 로직이 여관으로 이동)
        List<PartyUnit> currentParty = Collections.emptyList();

        // 업그레이드 상태 메시지 설정
        String currentUpgradeStatus = "업그레이드 중이 아닙니다.";
        if (barracks.getIsUpgrading() != null && barracks.getIsUpgrading()) {
            if (barracks.getUpgradeCompletionTime() != null) {
                if (barracks.getUpgradeCompletionTime().isAfter(LocalDateTime.now())) {
                    Duration remaining = Duration.between(LocalDateTime.now(), barracks.getUpgradeCompletionTime());
                    currentUpgradeStatus = String.format("업그레이드 중... (남은 시간: %d분 %d초)",
                            remaining.toMinutes(), remaining.getSeconds() % 60);
                } else {
                    currentUpgradeStatus = "업그레이드 완료! 새로고침 해주세요.";
                }
            } else {
                currentUpgradeStatus = "업그레이드 중... (완료 시간 미정)";
            }
        }

        return BarracksInfoResponse.builder()
                .barracksLevel(barracks.getLevel())
                .currentUpgradeStatus(currentUpgradeStatus)
                .nextUpgradeCost(nextUpgradeCost)
                .upgradeCompletionTime(barracks.getUpgradeCompletionTime() != null ? barracks.getUpgradeCompletionTime().atZone(ZoneId.systemDefault()).toInstant() : null)
                .currentTroops(currentTroops)
                .trainingQueue(trainingQueueItems)
                .trainableUnits(trainableUnits)
                .currentParty(currentParty)
                .ownedUnitsAndHeroes(ownedUnitsAndHeroes)
                .build();
    }


    @Override
    @Transactional
    public String upgradeBarracks(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        Barracks barracks = barracksRepository.findByUser(user)
                .orElseThrow(() -> new EntityNotFoundException("Barracks not found for user id: " + userId));

        if (barracks.getIsUpgrading() != null && barracks.getIsUpgrading()) {
            return "이미 병영이 업그레이드 중입니다.";
        }

        int currentLevel = barracks.getLevel();
        int goldCost = (currentLevel + 1) * 100;
        int woodCost = (currentLevel + 1) * 50;
        int ironCost = (currentLevel + 1) * 20;

        if (user.getGold() < goldCost || user.getWood() < woodCost || user.getIron() < ironCost) {
            return "자원이 부족하여 병영을 업그레이드할 수 없습니다.";
        }

        user.setGold(user.getGold() - goldCost);
        user.setWood(user.getWood() - woodCost);
        user.setIron(user.getIron() - ironCost);
        userRepository.save(user);

        barracks.setIsUpgrading(true);
        barracks.setUpgradeCompletionTime(LocalDateTime.now().plusMinutes(5));
        barracks.setUpgradeCostGold(goldCost);
        barracksRepository.save(barracks);

        log.info("User {}'s Barracks upgrade started. Level: {}", userId, currentLevel);
        return "병영 업그레이드를 시작합니다. 5분 후 완료됩니다.";
    }

    @Override
    @Transactional
    public TrainUnitResponse trainUnit(TrainUnitRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + request.getUserId()));

        Barracks barracks = barracksRepository.findByUser(user)
                .orElseThrow(() -> new EntityNotFoundException("Barracks not found for user id: " + request.getUserId()));

        Unit unitToTrain = unitRepository.findByName(request.getUnitType())
                .orElseThrow(() -> new EntityNotFoundException("유닛을 찾을 수 없습니다: " + request.getUnitType()));


        int quantity = request.getQuantity();

        if (barracks.getLevel() < unitToTrain.getRequiredBarracksLevel()) {
            return TrainUnitResponse.builder()
                    .success(false)
                    .message("병영 레벨이 부족하여 해당 유닛을 훈련할 수 없습니다.")
                    .build();
        }

        long currentUnitsInQueue = trainingQueueRepository.findByUserIdOrderByCompletionTimeAsc(user.getId()).stream()
                .mapToLong(TrainingQueue::getQuantity)
                .sum();

        // 훈련 요청 수량과 현재 대기열의 총 수량을 합쳐 병영의 훈련 수용량과 비교합니다.
        if (currentUnitsInQueue + quantity > barracks.getTrainingCapacity()) {
            return TrainUnitResponse.builder()
                    .success(false)
                    .message("훈련 수용량이 부족합니다. 현재 훈련 중인 유닛을 확인하거나 병영을 업그레이드하세요.")
                    .build();
        }

        long totalGoldCost = (long) unitToTrain.getGoldCost() * quantity;
        long totalWoodCost = (long) unitToTrain.getWoodCost() * quantity;
        long totalIronCost = (long) unitToTrain.getIronCost() * quantity;


        if (user.getGold() < totalGoldCost || user.getWood() < totalWoodCost || user.getIron() < totalIronCost) {
            return TrainUnitResponse.builder()
                    .success(false)
                    .message("자원이 부족하여 유닛을 훈련할 수 없습니다.")
                    .build();
        }

        user.setGold(user.getGold() - (int)totalGoldCost);
        user.setWood(user.getWood() - (int)totalWoodCost);
        user.setIron(user.getIron() - (int)totalIronCost);
        userRepository.save(user);

        Instant startTime = Instant.now();
        Instant completionTime = startTime.plusSeconds((long) unitToTrain.getTrainingDurationSeconds() * quantity);

        TrainingQueue newTraining = TrainingQueue.builder()
                .userId(user.getId())
                .unitId(unitToTrain.getId())
                .quantity(quantity)
                .startTime(startTime)
                .completionTime(completionTime)
                .build();
        trainingQueueRepository.save(newTraining);

        log.info("User {} started training {} {} units. Completion time: {}",
                user.getId(), quantity, unitToTrain.getName(), completionTime);

        return TrainUnitResponse.builder()
                .success(true)
                .message(unitToTrain.getName() + " " + quantity + "명 훈련을 시작합니다!")
                .completionTime(completionTime)
                .build();
    }


    @Override
    @Transactional
    public String saveParty(Long userId, List<Long> unitIds, List<Boolean> isHeroes) {
        // 파티 저장 로직은 병영 서비스에서 제거되었으며, 여관 서비스 등 다른 곳으로 이동해야 합니다.
        log.warn("saveParty method called in BarracksServiceImpl, but party logic moved. User ID: {}", userId);
        return "파티 저장 로직은 병영 서비스에서 제거되었습니다.";
    }

    @Override
    @Transactional
    public String disbandParty(Long userId) {
        // 파티 해체 로직은 병영 서비스에서 제거되었으며, 여관 서비스 등 다른 곳으로 이동해야 합니다.
        log.warn("disbandParty method called in BarracksServiceImpl, but party logic moved. User ID: {}", userId);
        return "파티 해체 로직은 병영 서비스에서 제거되었습니다.";
    }


    // ⭐ 예약된 작업: 완료된 훈련 처리 (메서드 이름이 BarracksService 인터페이스와 일치하도록 수정) ⭐
    @Scheduled(fixedRate = 5000) // ⭐ 2000에서 5000으로 변경 ⭐
    @Transactional
    public void processCompletedTraining() { // 이름 변경: processCompletedTrainings -> processCompletedTraining
        log.info("Completed training processing started at {}", Instant.now());
        List<TrainingQueue> completedTrainings = trainingQueueRepository.findByCompletionTimeBefore(Instant.now());

        if (completedTrainings.isEmpty()) {
            log.info("No completed trainings to process.");
            return;
        }

        for (TrainingQueue training : completedTrainings) {
            try {
                User user = userRepository.findById(training.getUserId())
                        .orElseThrow(() -> new EntityNotFoundException("User not found for completed training: " + training.getId()));
                Unit unit = unitRepository.findById(training.getUnitId())
                        .orElseThrow(() -> new EntityNotFoundException("Unit not found for completed training: " + training.getId()));

                // 유닛 타입이 SOLDIER인 경우에만 처리 (HERO는 병영에서 훈련하지 않음)
                if (unit.getUnitType() == UnitType.SOLDIER) {
                    userUnitRepository.findByUserIdAndUnitId(user.getId(), unit.getId())
                            .ifPresentOrElse(
                                    userUnit -> {
                                        userUnit.setQuantity(userUnit.getQuantity() + training.getQuantity());
                                        userUnitRepository.save(userUnit);
                                        log.info("Updated UserUnit for user {} unit {}: new quantity {}", user.getId(), unit.getName(), userUnit.getQuantity());
                                    },
                                    () -> {
                                        UserUnit newUserUnit = UserUnit.builder()
                                                .userId(user.getId())
                                                .unitId(unit.getId())
                                                .quantity(training.getQuantity())
                                                .build();
                                        userUnitRepository.save(newUserUnit);
                                        log.info("Created new UserUnit for user {} unit {}: quantity {}", user.getId(), unit.getName(), newUserUnit.getQuantity());
                                    }
                            );
                } else {
                    log.warn("Attempted to train a non-SOLDIER unit (Type: {}) in Barracks queue {}. Skipping.", unit.getUnitType(), training.getId());
                }

                trainingQueueRepository.delete(training);
                log.info("Removed completed training from queue: {}", training.getId());

            } catch (EntityNotFoundException e) {
                log.error("Error processing completed training {}: {}", training.getId(), e.getMessage());
                trainingQueueRepository.delete(training);
            } catch (Exception e) {
                log.error("Unexpected error processing completed training {}: {}", training.getId(), e.getMessage(), e);
            }
        }
        log.info("Completed training processing finished.");
    }


    // 유닛 훈련 취소 메서드 (BarracksService 인터페이스에 정의되어 있으므로 유지)
    @Override
    @Transactional
    public String cancelTraining(Long userId, Long queueId) {
        TrainingQueue trainingQueue = trainingQueueRepository.findById(queueId)
                .orElseThrow(() -> new EntityNotFoundException("훈련 대기열 항목을 찾을 수 없습니다. queueId: " + queueId));

        if (!trainingQueue.getUserId().equals(userId)) {
            throw new IllegalArgumentException("해당 훈련 항목에 대한 권한이 없습니다.");
        }

        // 훈련 취소 시 소모된 자원 환불 로직 (선택 사항)
        // Unit unitToRefund = unitRepository.findById(trainingQueue.getUnitId())
        //         .orElseThrow(() -> new EntityNotFoundException("유닛을 찾을 수 없습니다. unitId: " + trainingQueue.getUnitId()));
        // User user = userRepository.findById(userId)
        //         .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        // user.addGold(unitToRefund.getGoldCost() * trainingQueue.getQuantity());
        // user.addWood(unitToRefund.getWoodCost() * trainingQueue.getQuantity());
        // user.addIron(unitToRefund.getIronCost() * trainingQueue.getQuantity());
        // userRepository.save(user);

        trainingQueueRepository.delete(trainingQueue);
        log.info("User {} cancelled training for queueId: {}", userId, queueId);
        return "훈련이 성공적으로 취소되었습니다.";
    }


    // ⭐ 예약된 작업: 병영 업그레이드 완료 처리 ⭐
    @Scheduled(fixedRate = 5000) // ⭐ 1000에서 5000으로 변경 ⭐
    @Transactional
    public void processCompletedBarracksUpgrades() {
        List<Barracks> upgradingBarracks = barracksRepository.findByIsUpgradingTrueAndUpgradeCompletionTimeBefore(LocalDateTime.now());

        if (upgradingBarracks.isEmpty()) {
            return;
        }

        log.info("Processing {} completed barracks upgrades.", upgradingBarracks.size());

        for (Barracks barracks : upgradingBarracks) {
            try {
                // ⭐ 이 줄을 수정합니다. getLevel()과 setLevel()을 사용합니다. ⭐
                barracks.setLevel(barracks.getLevel() + 1); // level 필드를 직접 수정
                barracks.setIsUpgrading(false);
                barracks.setUpgradeCompletionTime(null);
                barracksRepository.save(barracks);
                log.info("Barracks for user {} upgraded to level {}.", barracks.getUser().getId(), barracks.getLevel());
            } catch (Exception e) {
                log.error("Error processing completed barracks upgrade for user {}: {}", barracks.getUser().getId(), e.getMessage(), e);
            }
        }
        log.info("Completed barracks upgrade processing finished.");
    }
}