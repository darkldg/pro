// src/main/java/com/example/back/entity/Barracks.java (수정된 버전)
package com.example.back.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "barracks") // 데이터베이스 테이블 이름
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Barracks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // User 엔티티와 OneToOne 관계 설정
    // 한 명의 User는 하나의 Barracks를 가집니다.
    @OneToOne(fetch = FetchType.LAZY) // 지연 로딩 설정 (필요할 때 User 정보를 로드)
    @JoinColumn(name = "user_id", nullable = false, unique = true) // user_id 컬럼을 통해 User 엔티티와 조인
    private User user; // 이 병영을 소유한 User 엔티티

    @Column(name = "barracks_level", nullable = false) // 'barracks_level' 컬럼명 유지
    private int level; // 현재 병영 레벨 (필드명 'level'로 변경하여 DTO와 일관성)

    @Column(name = "training_capacity", nullable = false)
    private int trainingCapacity; // 병영 훈련 수용량

    @Column(name = "is_upgrading")
    private Boolean isUpgrading; // 현재 업그레이드 중인지 여부

    @Column(name = "upgrade_completion_time")
    private LocalDateTime upgradeCompletionTime; // 현재 진행 중인 업그레이드 완료 시간

    @Column(name = "upgrade_cost_gold")
    private Integer upgradeCostGold; // 다음 업그레이드에 필요한 골드 비용
    @Column(name = "upgrade_cost_wood")
    private Integer upgradeCostWood; // 다음 업그레이드에 필요한 나무 비용
    @Column(name = "upgrade_cost_iron")
    private Integer upgradeCostIron; // 다음 업그레이드에 필요한 철 비용

    // Barracks 엔티티에 편의 메서드 추가 (업그레이드 관련)
    public void startUpgrade(LocalDateTime completionTime, int gold, int wood, int iron) {
        this.setIsUpgrading(true);
        this.setUpgradeCompletionTime(completionTime);
        this.setUpgradeCostGold(gold);
        this.setUpgradeCostWood(wood);
        this.setUpgradeCostIron(iron);
    }

    public void completeUpgrade() {
        this.setLevel(this.getLevel() + 1);
        this.setTrainingCapacity(this.getTrainingCapacity() + 1); // 레벨업마다 수용량 증가 (예시)
        this.setIsUpgrading(false);
        this.setUpgradeCompletionTime(null);
        this.setUpgradeCostGold(null);
        this.setUpgradeCostWood(null);
        this.setUpgradeCostIron(null);
    }
}