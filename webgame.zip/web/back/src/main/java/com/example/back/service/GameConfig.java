package com.example.back.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class GameConfig {

    public static final Map<Integer, Map<String, Object>> TERRITORY_UPGRADE_COSTS;
    public static final Map<Integer, Map<String, Object>> BARRACKS_UPGRADE_COSTS;
    public static final Map<Integer, Map<String, Double>> TERRITORY_RESOURCE_PRODUCTION_PER_HOUR;

    // 최대 영지 레벨 상수를 추가할 수도 있습니다.
    public static final int MAX_TERRITORY_LEVEL = 3; // 영지의 최대 레벨
    public static final int MAX_BARRACKS_LEVEL = 3; // 병영의 최대 레벨

    // ⭐ 모든 static 필드 초기화는 이 하나의 static 블록 안에서 이루어져야 합니다. ⭐
    static {
        // --- 1. TERRITORY_UPGRADE_COSTS 초기화 ---
        Map<Integer, Map<String, Object>> territoryCosts = new HashMap<>();

        // 레벨 1 -> 2 영지 업그레이드 비용
        Map<String, Object> costLevel2Territory = new HashMap<>();
        costLevel2Territory.put("gold", 500L);
        costLevel2Territory.put("food", 300L);
        costLevel2Territory.put("wood", 200L);
        costLevel2Territory.put("iron", 100L);
        costLevel2Territory.put("duration_seconds", 30L);
        territoryCosts.put(2, costLevel2Territory);

        // 레벨 2 -> 3 영지 업그레이드 비용
        Map<String, Object> costLevel3Territory = new HashMap<>();
        costLevel3Territory.put("gold", 1000L);
        costLevel3Territory.put("food", 600L);
        costLevel3Territory.put("wood", 400L);
        costLevel3Territory.put("iron", 200L);
        costLevel3Territory.put("duration_seconds", 60L);
        territoryCosts.put(3, costLevel3Territory);

        TERRITORY_UPGRADE_COSTS = Collections.unmodifiableMap(territoryCosts);


        // --- 2. BARRACKS_UPGRADE_COSTS 초기화 ---
        Map<Integer, Map<String, Object>> barracksCosts = new HashMap<>();

        // 레벨 1 -> 2 병영 업그레이드 비용
        Map<String, Object> costLevel2Barracks = new HashMap<>();
        costLevel2Barracks.put("gold", 250L);
        costLevel2Barracks.put("food", 150L);
        costLevel2Barracks.put("wood", 100L);
        costLevel2Barracks.put("iron", 50L);
        costLevel2Barracks.put("duration_seconds", 15L);
        barracksCosts.put(2, costLevel2Barracks);

        // 레벨 2 -> 3 병영 업그레이드 비용
        Map<String, Object> costLevel3Barracks = new HashMap<>();
        costLevel3Barracks.put("gold", 1000L);
        costLevel3Barracks.put("food", 600L);
        costLevel3Barracks.put("wood", 400L);
        costLevel3Barracks.put("iron", 200L);
        costLevel3Barracks.put("duration_seconds", 60L);
        barracksCosts.put(3, costLevel3Barracks);

        BARRACKS_UPGRADE_COSTS = Collections.unmodifiableMap(barracksCosts);


        // --- 3. TERRITORY_RESOURCE_PRODUCTION_PER_HOUR 초기화 ---
        Map<Integer, Map<String, Double>> productionRates = new HashMap<>();

        // 레벨 1 생산량
        Map<String, Double> productionLevel1 = new HashMap<>();
        productionLevel1.put("gold", 100.0);
        productionLevel1.put("food", 150.0);
        productionLevel1.put("wood", 50.0);
        productionLevel1.put("iron", 20.0);
        productionRates.put(1, productionLevel1);

        // 레벨 2 생산량
        Map<String, Double> productionLevel2 = new HashMap<>();
        productionLevel2.put("gold", 200.0);
        productionLevel2.put("food", 300.0);
        productionLevel2.put("wood", 100.0);
        productionLevel2.put("iron", 40.0);
        productionRates.put(2, productionLevel2);

        // 레벨 3 생산량
        Map<String, Double> productionLevel3 = new HashMap<>();
        productionLevel3.put("gold", 400.0);
        productionLevel3.put("food", 600.0);
        productionLevel3.put("wood", 200.0);
        productionLevel3.put("iron", 80.0);
        productionRates.put(3, productionLevel3);

        TERRITORY_RESOURCE_PRODUCTION_PER_HOUR = Collections.unmodifiableMap(productionRates);
    }
}