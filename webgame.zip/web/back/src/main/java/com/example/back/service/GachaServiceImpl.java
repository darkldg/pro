// src/main/java/com/example/back/service/impl/GachaServiceImpl.java
package com.example.back.service.impl;

import com.example.back.dto.BarracksInfoResponse; // PartyUnit DTO를 위해 필요
import com.example.back.dto.GachaRequest;
import com.example.back.dto.GachaResponse;
import com.example.back.entity.PlayerOwnedHeroes;
import com.example.back.entity.User; // ⭐ User 엔티티 사용 ⭐
import com.example.back.entity.Unit;
import com.example.back.entity.UnitType; // HERO 타입 필터링을 위해 필요
import com.example.back.repository.PlayerOwnedHeroesRepository;
import com.example.back.repository.UnitRepository;
import com.example.back.repository.UserRepository; // ⭐ UserRepository 사용 ⭐
import com.example.back.service.GachaService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

@Service
@Transactional // 트랜잭션 관리
public class GachaServiceImpl implements GachaService { // ⭐ GachaService 인터페이스를 구현합니다. ⭐

    private final UnitRepository unitRepository;
    private final PlayerOwnedHeroesRepository playerOwnedHeroesRepository;
    private final UserRepository userRepository; // ⭐ UserRepository 사용 ⭐

    private static final int HERO_DRAW_COST = 10; // 영웅 뽑기 비용 (상수)

    @Autowired
    public GachaServiceImpl(UnitRepository unitRepository,
                            PlayerOwnedHeroesRepository playerOwnedHeroesRepository,
                            UserRepository userRepository) {
        this.unitRepository = unitRepository;
        this.playerOwnedHeroesRepository = playerOwnedHeroesRepository;
        this.userRepository = userRepository;
    }

    @Override
    public GachaResponse drawHero(GachaRequest request) {
        Long userId = request.getUserId();

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        // 1. 신비한 가루 확인 및 차감 (User 엔티티에서 직접)
        if (user.getMagicPowder() < HERO_DRAW_COST) {
            return GachaResponse.builder()
                    .success(false)
                    .message("신비한 가루가 부족합니다! (현재: " + user.getMagicPowder() + ", 필요: " + HERO_DRAW_COST + ")")
                    .magicPowderRemaining(user.getMagicPowder())
                    .build();
        }
        user.subtractMagicPowder(HERO_DRAW_COST); // 신비한 가루 차감
        userRepository.save(user); // 사용자 엔티티 변경사항 저장

        // 2. HERO 타입 유닛 목록 조회 (뽑기 풀)
        List<Unit> heroUnits = unitRepository.findByUnitType(UnitType.HERO);
        if (heroUnits.isEmpty()) {
            return GachaResponse.builder()
                    .success(false)
                    .message("뽑기 가능한 영웅이 없습니다. 관리자에게 문의하세요.")
                    .magicPowderRemaining(user.getMagicPowder())
                    .build();
        }

        // 3. 무작위 영웅 선택
        Random random = new Random();
        Unit drawnUnit = heroUnits.get(random.nextInt(heroUnits.size())); // 리스트에서 무작위 영웅 선택

        // 4. PlayerOwnedHeroes에 추가
        PlayerOwnedHeroes newHero = PlayerOwnedHeroes.builder()
                .user(user)
                .unit(drawnUnit)
                .level(1) // 초기 레벨
                .currentHp(drawnUnit.getBaseHealth()) // 초기 체력은 기본 체력으로 설정
                .currentAttack(drawnUnit.getBaseAttack()) // 초기 공격력은 기본 공격력으로 설정
                .currentDefense(drawnUnit.getBaseDefense()) // 초기 방어력은 기본 방어력으로 설정
                .build();
        playerOwnedHeroesRepository.save(newHero); // DB에 새로운 보유 영웅 저장

        // 5. 응답 DTO 구성
        BarracksInfoResponse.PartyUnit drawnHeroDto = BarracksInfoResponse.PartyUnit.builder()
                .unitId(newHero.getId()) // PlayerOwnedHeroes의 고유 ID를 unitId로 사용 (프론트엔드 PartyUnit과 호환)
                .name(drawnUnit.getName())
                .illustrationUrl(drawnUnit.getIllustrationUrl())
                .isHero(true) // 영웅이므로 true
                .baseAttack(drawnUnit.getBaseAttack())
                .baseDefense(drawnUnit.getBaseDefense())
                .currentHp(newHero.getCurrentHp())
                .currentAttack(newHero.getCurrentAttack())
                .currentDefense(newHero.getCurrentDefense())
                .heroLevel(newHero.getLevel())
                .build();

        return GachaResponse.builder()
                .success(true)
                .message(drawnUnit.getName() + " (영웅)을(를) 획득했습니다!")
                .drawnHero(drawnHeroDto) // 뽑힌 영웅 정보 포함
                .magicPowderRemaining(user.getMagicPowder()) // 남은 신비한 가루 정보 포함
                .build();
    }
}
