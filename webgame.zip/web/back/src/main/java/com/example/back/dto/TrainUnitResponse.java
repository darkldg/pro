// src/main/java/com/example/back/dto/TrainUnitResponse.java
package com.example.back.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.Instant;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainUnitResponse {
    private boolean success; // 훈련 성공 여부
    private String message; // 사용자에게 표시할 메시지


    private Instant  completionTime; // 훈련 완료 시간 (성공 시에만 해당)
}