// src/main/java/com/example/back/dto/UserResponseDto.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserResponseDto {
    private Long id;
    private String username;
    private Integer gold;
    private Integer food;
    private Integer wood;
    private Integer iron;
    private Integer magicPowder;
    private int territoryLevel;
    // 필요한 다른 필드가 있다면 여기에 추가합니다.
}
