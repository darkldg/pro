// src/main/java/com/example/back/dto/UserGainRequestDto.java
package com.example.back.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor // Lombok이 기본 생성자를 자동으로 생성해줍니다.
public class UserGainRequestDto {
    private Long exp;
    private Long gold;

    // 필요하다면 모든 필드를 포함하는 생성자나 Builder 패턴을 추가할 수 있습니다.
    // 여기서는 @RequestBody가 필드를 자동으로 매핑해주므로 getter/setter만 있어도 충분합니다.
}