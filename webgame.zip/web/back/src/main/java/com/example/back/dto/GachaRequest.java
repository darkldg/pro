// src/main/java/com/example/back/dto/GachaRequest.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GachaRequest {
    private Long userId;
    // Add additional parameters for gacha type if needed
}
