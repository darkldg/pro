// src/main/java/com/example/back/dto/TrainableUnitDTO.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainableUnitDTO {
    private Long id; // Unit 엔티티의 ID
    private String name; // 유닛 이름
    private String unitType; // SOLDIER, HERO 등
    private String unitClass; // SWORD, ARCHER 등
    private int baseAttack;
    private int baseDefense;
    private String illustrationUrl; // 유닛 이미지 URL
    private int requiredBarracksLevel; // 훈련에 필요한 병영 레벨
    private int goldCost;
    private int woodCost;
    private int ironCost;
    // 필요에 따라 추가 필드
}