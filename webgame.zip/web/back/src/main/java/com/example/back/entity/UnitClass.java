package com.example.back.entity;

public enum UnitClass { // public 키워드 추가
    SWORD,
    BOW,
    MAGE
}