package com.example.back.service;

import com.example.back.entity.Monster;
import com.example.back.repository.MonsterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * 몬스터와 관련된 비즈니스 로직을 처리하는 서비스 클래스.
 */
@Service
public class MonsterService {

    private final MonsterRepository monsterRepository;

    @Autowired
    public MonsterService(MonsterRepository monsterRepository) {
        this.monsterRepository = monsterRepository;
    }

    /**
     * 데이터베이스에서 모든 몬스터 목록을 조회합니다.
     * @return 모든 몬스터 엔티티의 리스트
     */
    public List<Monster> getAllMonsters() {
        return monsterRepository.findAll();
    }

    /**
     * 특정 ID의 몬스터를 데이터베이스에서 조회합니다.
     * @param id 조회할 몬스터의 ID
     * @return 해당 ID의 몬스터 (Optional<Monster>로 반환하여 존재하지 않을 경우를 처리)
     */
    public Optional<Monster> getMonsterById(String id) {
        return monsterRepository.findById(id);
    }

    /**
     * ⭐⭐ 새로 추가할 메서드: 특정 타입의 몬스터 목록을 조회합니다. ⭐⭐
     * @param type 조회할 몬스터의 타입 (예: "B" for 일반, "V" for 보스)
     * @return 해당 타입의 몬스터 엔티티 리스트
     */
    public List<Monster> getMonstersByType(String type) {
        return monsterRepository.findByType(type);
    }

    // 향후 추가될 비즈니스 로직 예시:
    // - public Monster spawnRandomMonsterByArea(String areaType, int playerLevel) { ... }
    // - public CombatResult simulateCombat(String monsterId, String playerId) { ... }
}