package com.example.back.entity; // 적절한 패키지 경로로 수정해주세요.

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user_units")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserUnit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId; // User 엔티티의 ID와 연결

    @Column(name = "unit_id", nullable = false)
    private Long unitId; // Unit 엔티티의 ID와 연결

    @Column(name = "quantity", nullable = false)
    private int quantity; // 사용자가 보유한 해당 유닛의 수량

    // ⭐ 새로 추가할 필드: 장착 여부 ⭐
    @Column(name = "is_equipped", nullable = false) // 데이터베이스 컬럼명과 제약 조건을 일치시킵니다.
    private boolean isEquipped; // boolean 타입으로 장착 여부를 나타냅니다.

    // 추가적으로 필요한 필드가 있다면 여기에 추가 (예: 유닛의 고유한 강화 상태 등)
}