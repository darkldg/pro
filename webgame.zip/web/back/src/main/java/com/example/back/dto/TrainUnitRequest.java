// src/main/java/com/example/back/dto/TrainUnitRequest.java (수정 제안)
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainUnitRequest {
    private Long userId;
    private String unitType; // 프론트엔드에서 unitType (유닛 이름)을 보냅니다.
    private int quantity;
}