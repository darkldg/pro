// src/main/java/com/example/back/dto/LoginResponseDto.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponseDto {
    // private String token; // ⭐ token 필드 제거
    private boolean success;
    private String message;
    private Long userId; // userId 필드는 유지
}