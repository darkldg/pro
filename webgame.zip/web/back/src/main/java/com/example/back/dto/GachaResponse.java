// src/main/java/com/example/back/dto/GachaResponse.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GachaResponse {
    private boolean success; // Whether the gacha draw was successful
    private String message;  // Message to display to the user
    // BarracksInfoResponse.PartyUnit DTO를 재사용하여 뽑힌 영웅 정보를 포함합니다.
    // 이는 프론트엔드의 PartyUnit 구조와 호환성을 유지하기 위함입니다.
    private BarracksInfoResponse.PartyUnit drawnHero; // Drawn hero information
    private int magicPowderRemaining; // Magic powder remaining after the draw
}
