package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// Unit 엔티티의 핵심 정보를 담는 DTO
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartyResponse {
    private Long id;
    private String name;
    private String unitType; // HERO, SOLDIER
    private String unitClass;
    private int baseAttack;
    private int baseDefense;
    private int baseHealth;
    private String illustrationUrl;
    private boolean isHero; // 편의상 추가, unitType과 연동
}