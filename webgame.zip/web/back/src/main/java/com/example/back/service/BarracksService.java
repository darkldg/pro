// src/main/java/com/example/back/service/BarracksService.java (인터페이스)
package com.example.back.service;

import com.example.back.dto.BarracksInfoResponse;
import com.example.back.dto.TrainUnitRequest;
import com.example.back.dto.TrainUnitResponse;
import com.example.back.dto.UnitResponseDto;
import com.example.back.entity.Unit;

import java.util.List;

public interface BarracksService {
    BarracksInfoResponse getBarracksInfo(Long userId);
    String upgradeBarracks(Long userId);
    TrainUnitResponse trainUnit(TrainUnitRequest request);
    String saveParty(Long userId, List<Long> unitIds, List<Boolean> isHeroes);
    String disbandParty(Long userId);
    void processCompletedTraining();
    String cancelTraining(Long userId, Long queueId); // ⭐ 이 줄을 추가합니다. ⭐
}
