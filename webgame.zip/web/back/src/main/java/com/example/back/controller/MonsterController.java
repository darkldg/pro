package com.example.back.controller;

import com.example.back.entity.Monster;
import com.example.back.service.MonsterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin; // ⭐ CrossOrigin 어노테이션 임포트 ⭐

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/monsters")
@CrossOrigin(origins = "http://localhost:5173") // ⭐ CORS 허용할 출처 명시 ⭐
public class MonsterController {

    private final MonsterService monsterService;

    @Autowired
    public MonsterController(MonsterService monsterService) {
        this.monsterService = monsterService;
    }

    @GetMapping
    public ResponseEntity<List<Monster>> getAllMonsters() {
        List<Monster> monsters = monsterService.getAllMonsters();
        System.out.println("[백엔드] 모든 몬스터 조회 요청: " + monsters.size() + "개 반환");
        return ResponseEntity.ok(monsters);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Monster> getMonsterById(@PathVariable String id) {
        System.out.println("[백엔드] 특정 몬스터 조회 요청 받음. ID: \"" + id + "\"");
        Optional<Monster> monster = monsterService.getMonsterById(id);

        if (monster.isPresent()) {
            System.out.println("[백엔드] 몬스터 찾음. 이름: " + monster.get().getName());
            return ResponseEntity.ok(monster.get());
        } else {
            System.out.println("[백엔드] 몬스터 찾기 실패. ID: \"" + id + "\"에 해당하는 몬스터 없음.");
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * 특정 타입의 몬스터 목록을 조회하는 API 엔드포인트.
     * HTTP GET 요청: /api/monsters/type/{type} (예: /api/monsters/type/B, /api/monsters/type/V)
     * @param type 조회할 몬스터의 타입 (예: "B" for 일반, "V" for 보스)
     * @return 해당 타입의 몬스터 정보 리스트 (JSON 형식)
     */
    @GetMapping("/type/{type}") // 새로운 경로 추가
    public ResponseEntity<List<Monster>> getMonstersByType(@PathVariable String type) {
        System.out.println("[백엔드] 타입별 몬스터 조회 요청 받음. 타입: \"" + type + "\"");
        List<Monster> monsters = monsterService.getMonstersByType(type);

        if (!monsters.isEmpty()) {
            System.out.println("[백엔드] 타입 \"" + type + "\"에 해당하는 몬스터 " + monsters.size() + "개 찾음.");
            return ResponseEntity.ok(monsters);
        } else {
            System.out.println("[백엔드] 타입 \"" + type + "\"에 해당하는 몬스터 없음.");
            // 타입은 존재하지만 해당 몬스터가 없는 경우 200 OK와 빈 리스트 반환
            return ResponseEntity.ok(List.of()); // 비어있는 리스트 반환
        }
    }
}
