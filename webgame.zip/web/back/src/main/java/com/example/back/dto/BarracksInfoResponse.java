// src/main/java/com/example/back/dto/BarracksInfoResponse.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BarracksInfoResponse {
    private int barracksLevel;
    private String currentUpgradeStatus;
    private ResourceCost nextUpgradeCost; // 다음 업그레이드 비용 DTO는 유지
    private Instant upgradeCompletionTime;
    private Map<Long, Integer> currentTroops; // key: unitId, value: quantity
    private List<TrainingQueueItem> trainingQueue;
    private List<TrainableUnit> trainableUnits; // 병영에서 훈련 가능한 유닛 목록
    private List<PartyUnit> currentParty; // 현재 파티 구성
    private List<PartyUnit> ownedUnitsAndHeroes; // 보유한 유닛과 영웅 목록

    // 병영 업그레이드 비용 DTO (BarracksInfoResponse 내부에 정의)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ResourceCost {
        private int gold;
        private int wood;
        private int iron;
    }

    // 훈련 대기열 아이템 DTO (BarracksInfoResponse 내부에 정의)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TrainingQueueItem {
        private Long id; // TrainingQueue의 ID (선택 사항)
        private String unitName;
        private int quantity;
        private Instant completionTime;
        private long remainingSeconds;
    }

    // 훈련 가능한 유닛 DTO (BarracksInfoResponse 내부에 정의)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TrainableUnit {
        private Long id;
        private String name;
        private String unitType;
        private String unitClass;
        private String unitRarity;
        private int baseAttack;
        private int baseDefense;
        private int baseHealth; // baseHealth 추가
        private String illustrationUrl;
        private int requiredBarracksLevel;
        private int goldCost;
        private int woodCost;
        private int ironCost;
        private int trainingDurationSeconds;
    }

    // 파티 유닛 DTO (PartyUnitDTO와 유사하지만, 더 상세한 정보 포함)
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PartyUnit {
        private Long unitId; // Unit의 ID (or PlayerOwnedHeroes의 ID)
        private String name;
        private String illustrationUrl;
        private boolean isHero;
        private int baseAttack;
        private int baseDefense;
        // 영웅 전용 필드 (일반 유닛의 경우 null 또는 0)
        private Integer currentHp;
        private Integer currentAttack;
        private Integer currentDefense;
        private Integer heroLevel;
        // ... (필요에 따라 추가 필드)
    }
}