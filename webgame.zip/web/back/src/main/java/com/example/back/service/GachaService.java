// src/main/java/com/example/back/service/GachaService.java
package com.example.back.service;

import com.example.back.dto.GachaResponse;
import com.example.back.dto.GachaRequest;

public interface GachaService {
    // 영웅을 뽑는 로직을 수행합니다.
    GachaResponse drawHero(GachaRequest request);
}
