// src/main/java/com/example/back/entity/UserParty.java (수정된 엔티티 - 수동 Getter/Setter 포함)
package com.example.back.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder; // @Builder는 유지합니다.

@Entity
@Table(name = "user_parties")
// @Data, @Getter, @Setter, @NoArgsConstructor, @AllArgsConstructor 어노테이션 제거
@Builder // @Builder는 유지하여 빌더 패턴 사용 가능
public class UserParty {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId; // User 엔티티의 ID와 연결

    @Column(name = "slot_number", nullable = false)
    private int slotNumber; // 파티 슬롯 번호 (예: 0, 1, 2, 3)

    @Column(name = "unit_id") // 유닛 ID (null 가능, 슬롯이 비어있을 경우)
    private Long unitId;

    @Column(name = "is_hero", nullable = false)
    private boolean isHero; // 해당 슬롯의 유닛이 영웅인지 일반 유닛인지 구분

    // @NoArgsConstructor 대체: 기본 생성자
    public UserParty() {
    }

    // @AllArgsConstructor 대체: 모든 필드를 포함하는 생성자 (Builder와 함께 사용)
    // Builder 어노테이션은 이 생성자를 내부적으로 활용하여 인스턴스를 생성합니다.
    // 하지만 명시적으로 모든 필드를 받는 생성자를 정의하지 않으면 Builder가 private 생성자를 만들 수 있습니다.
    // Builder와 함께 사용될 때 이 생성자는 직접 호출되기보다는 Lombok에 의해 내부적으로 활용됩니다.
    public UserParty(Long id, Long userId, int slotNumber, Long unitId, boolean isHero) {
        this.id = id;
        this.userId = userId;
        this.slotNumber = slotNumber;
        this.unitId = unitId;
        this.isHero = isHero;
    }

    // --- Getter 메소드 ---
    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public Long getUnitId() {
        return unitId;
    }

    public boolean getIsHero() { // 오류가 발생했던 getIsHero() 메소드를 직접 작성
        return isHero;
    }

    // --- Setter 메소드 ---
    public void setId(Long id) {
        this.id = id;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setSlotNumber(int slotNumber) {
        this.slotNumber = slotNumber;
    }

    public void setUnitId(Long unitId) {
        this.unitId = unitId;
    }

    public void setIsHero(boolean isHero) {
        this.isHero = isHero;
    }
}