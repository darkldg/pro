package com.example.back.repository;

import com.example.back.entity.PlayerOwnedHeroes;
import com.example.back.entity.User; // User 엔티티 임포트
import com.example.back.entity.Unit; // Unit 엔티티 임포트
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PlayerOwnedHeroesRepository extends JpaRepository<PlayerOwnedHeroes, Long> {

    // ⭐ PlayerOwnedHeroesRepository에 이 메서드를 추가하거나 정확히 일치시켜야 합니다.
    // 특정 User가 소유한 모든 영웅(UnitType이 HERO인 Unit)을 가져옵니다.
    // FETCH JOIN을 사용하여 N+1 문제를 방지합니다.
    @Query("SELECT poh FROM PlayerOwnedHeroes poh JOIN FETCH poh.unit u WHERE poh.user = :user AND u.unitType = 'HERO'")
    List<PlayerOwnedHeroes> findByUserWithHeroUnit(@Param("user") User user);

    // 유저와 특정 유닛에 대한 PlayerOwnedHeroes를 찾는 메서드 (영웅 뽑기 시 중복 체크 등)
    Optional<PlayerOwnedHeroes> findByUserAndUnit(User user, Unit unit);

    List<PlayerOwnedHeroes> findByUser(User user);

    List<PlayerOwnedHeroes> findByUserAndIsEquipped(User user, boolean isEquipped);

}