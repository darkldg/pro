// src/main/java/com/example/back/dto/UnitResponseDto.java (수정될 내용)
package com.example.back.dto;

import com.example.back.entity.PlayerOwnedHeroes;
import com.example.back.entity.Unit;
import com.example.back.entity.UserUnit;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UnitResponseDto {
    private Long id;
    private String name;
    private String illustrationUrl;
    private String unitType;
    private String unitClass;
    private String unitRarity;

    private Integer level;
    private Long currentExp;
    private Long requiredExpForNextLevel;
    private Integer currentHp;
    private Integer currentAttack;
    private Integer currentDefense;

    private Boolean isEquipped; // 영웅 전용
    private Integer slotIndex; // 영웅 전용

    // UserUnit에서 DTO 생성 (기존과 동일)
    public static UnitResponseDto fromUserUnit(UserUnit userUnit, Unit unit) {
        if (userUnit == null || unit == null) {
            return null;
        }
        return UnitResponseDto.builder()
                .id(userUnit.getId())
                .name(unit.getName())
                .illustrationUrl(unit.getIllustrationUrl())
                .unitType(unit.getUnitType() != null ? unit.getUnitType().name() : null)
                .unitClass(unit.getUnitClass() != null ? unit.getUnitClass().name() : null)
                .unitRarity(unit.getUnitRarity() != null ? unit.getUnitRarity().name() : null)
                // 일반 유닛은 레벨이나 경험치 개념이 없을 수 있으므로 0 또는 1로 설정
                .level(1)
                .currentExp(0L)
                .requiredExpForNextLevel(0L)
                .currentHp(unit.getBaseHealth())
                .currentAttack(unit.getBaseAttack())
                .currentDefense(unit.getBaseDefense())
                .build();
    }

    // ⭐ PlayerOwnedHeroes에서 DTO 생성 (마스터리 보너스 인자 추가) ⭐
    public static UnitResponseDto fromPlayerOwnedHero(PlayerOwnedHeroes playerOwnedHero,
                                                      int masteryBonusHp,
                                                      int masteryBonusAttack,
                                                      int masteryBonusDefense) {
        if (playerOwnedHero == null) {
            return null;
        }
        Unit unit = playerOwnedHero.getUnit();
        return UnitResponseDto.builder()
                .id(playerOwnedHero.getId())
                .name(unit.getName())
                .illustrationUrl(unit.getIllustrationUrl())
                .unitType(unit.getUnitType() != null ? unit.getUnitType().name() : null)
                .unitClass(unit.getUnitClass() != null ? unit.getUnitClass().name() : null)
                .unitRarity(unit.getUnitRarity() != null ? unit.getUnitRarity().name() : null)
                .level(playerOwnedHero.getLevel())
                .currentExp(playerOwnedHero.getCurrentExp())
                .requiredExpForNextLevel(playerOwnedHero.getRequiredExpForNextLevel())
                // ⭐ 현재 스탯에 마스터리 보너스를 합산 ⭐
                .currentHp(playerOwnedHero.getCurrentHp() + masteryBonusHp)
                .currentAttack(playerOwnedHero.getCurrentAttack() + masteryBonusAttack)
                .currentDefense(playerOwnedHero.getCurrentDefense() + masteryBonusDefense)
                .isEquipped(playerOwnedHero.getIsEquipped())
                .slotIndex(playerOwnedHero.getSlotIndex())
                .build();
    }
}