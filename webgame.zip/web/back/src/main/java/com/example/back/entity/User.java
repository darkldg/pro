package com.example.back.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false)
    private String password;

    // ⭐ 자원 필드 ⭐
    @Column(nullable = false)
    private int gold;

    @Column(nullable = false)
    private int food;

    @Column(nullable = false)
    private int wood;

    @Column(nullable = false)
    private int iron;

    @Column(nullable = false)
    private int magicPowder;
    // ⭐ 새로 추가되는 필드: 영지 레벨 ⭐
    @Column(nullable = false)
    private int territoryLevel;

    @Column(nullable = false)
    private int exp;


    // ⭐ 자원 추가/차감 메서드 ⭐
    public void addGold(int amount) { this.gold += amount; }
    public void subtractGold(int amount) { this.gold = Math.max(0, this.gold - amount); }
    public void addFood(int amount) { this.food += amount; }
    public void subtractFood(int amount) { this.food = Math.max(0, this.food - amount); }
    public void addWood(int amount) { this.wood += amount; }
    public void subtractWood(int amount) { this.wood = Math.max(0, this.wood - amount); }
    public void addIron(int amount) { this.iron += amount; }
    public void subtractIron(int amount) { this.iron = Math.max(0, this.iron - amount); }
    public void addMagicPowder(int amount) { this.magicPowder += amount; }
    public void subtractMagicPowder(int amount) { this.magicPowder = Math.max(0, this.magicPowder - amount); }

}