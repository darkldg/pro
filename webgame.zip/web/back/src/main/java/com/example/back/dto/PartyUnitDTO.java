// src/main/java/com/example/back/dto/PartyUnitDTO.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PartyUnitDTO {
    private Long id; // Unit의 ID (또는 PlayerOwnedHeroes의 ID)
    private String name; // 유닛/영웅 이름
    private String illustrationUrl; // 이미지 URL
    private boolean isHero; // 영웅인지 일반 유닛인지
    private int baseAttack;
    private int baseDefense;
    // 필요에 따라 추가 필드 (예: 현재 체력 등)
}