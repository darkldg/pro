// src/main/java/com/example/back/dto/TerritoryInfoResponse.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant; // Instant import for upgradeCompletionTime

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TerritoryInfoResponse {
    private int level;
    private String currentUpgradeStatus; // 현재 업그레이드 상태 메시지 (예: "업그레이드 가능", "업그레이드 중")
    private ResourceCost nextUpgradeCost; // 다음 업그레이드 비용 (내부 DTO)
    private Instant upgradeCompletionTime; // 업그레이드 완료 시간 (UTC Instant)
    private int nextUpgradeDurationSeconds; // 다음 업그레이드에 걸리는 시간 (초)

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ResourceCost {
        private int gold;
        private int wood;
        private int iron;
        // 마법 가루는 영지 업그레이드 비용에 사용되지 않으므로 포함하지 않습니다.
    }
}
