package com.example.back.controller;

import com.example.back.dto.UserResponseDto;
import com.example.back.dto.UserResourceUpdateRequestDto;
import com.example.back.entity.User;
import com.example.back.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:5173")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository userRepository;

    // 사용자 정보 조회 API
    @GetMapping("/{userId}")
    public ResponseEntity<UserResponseDto> getUserInfo(@PathVariable Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        UserResponseDto userDto = UserResponseDto.builder()
                .id(user.getId())
                .username(user.getUsername())
                .gold(user.getGold())
                .food(user.getFood())
                .wood(user.getWood())
                .iron(user.getIron())
                .magicPowder(user.getMagicPowder())
                .territoryLevel(user.getTerritoryLevel()) // ⭐ 영지 레벨 포함 ⭐
                .build();

        return ResponseEntity.ok(userDto);
    }

    // 사용자 자원 및 영지 레벨 업데이트 API
    // 이 API는 프론트엔드에서 자원 소모 또는 업그레이드 완료 후 자원/레벨 상태를 저장할 때 사용됩니다.
    @PutMapping("/{userId}/resources")
    public ResponseEntity<UserResponseDto> updateResources(
            @PathVariable Long userId,
            @RequestBody UserResourceUpdateRequestDto requestDto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        user.setGold(requestDto.getGold());
        user.setFood(requestDto.getFood());
        user.setWood(requestDto.getWood());
        user.setIron(requestDto.getIron());
        user.setMagicPowder(requestDto.getMagicPowder());

        // ⭐ 영지 레벨이 DTO에 포함되어 있다면 업데이트 ⭐
        // 프론트엔드에서 업그레이드 완료 후 새로운 레벨을 보낼 때 사용됩니다.
        if (requestDto.getTerritoryLevel() != null) {
            user.setTerritoryLevel(requestDto.getTerritoryLevel());
        }

        User updatedUser = userRepository.save(user);

        UserResponseDto userDto = UserResponseDto.builder()
                .id(updatedUser.getId())
                .username(updatedUser.getUsername())
                .gold(updatedUser.getGold())
                .food(updatedUser.getFood())
                .wood(updatedUser.getWood())
                .iron(updatedUser.getIron())
                .magicPowder(updatedUser.getMagicPowder())
                .territoryLevel(updatedUser.getTerritoryLevel()) // ⭐ 업데이트된 영지 레벨 포함 ⭐
                .build();

        return ResponseEntity.ok(userDto);
    }

    // 자원 자동 증가 및 저장 API
    // 이 API는 일정 시간마다 자동으로 자원을 채집하여 업데이트할 때 사용됩니다.
    @PostMapping("/{userId}/collect-auto-resources")
    public ResponseEntity<UserResponseDto> collectAutoResources(@PathVariable Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        // 사용자 영지 레벨을 사용하여 자원 증가량을 계산 (이제 User 엔티티에서 가져옴)
        int currentTerritoryLevel = user.getTerritoryLevel(); // ⭐ User 엔티티의 territoryLevel 사용 ⭐

        int goldGain = currentTerritoryLevel * 5;
        int foodGain = currentTerritoryLevel * 3;
        int woodGain = currentTerritoryLevel * 3;
        int ironGain = currentTerritoryLevel * 2;
        int magicPowderGain = (int) Math.floor(currentTerritoryLevel * 1.5);

        user.addGold(goldGain);
        user.addFood(foodGain);
        user.addWood(woodGain);
        user.addIron(ironGain);
        user.addMagicPowder(magicPowderGain);

        User updatedUser = userRepository.save(user);

        UserResponseDto userDto = UserResponseDto.builder()
                .id(updatedUser.getId())
                .username(updatedUser.getUsername())
                .gold(updatedUser.getGold())
                .food(updatedUser.getFood())
                .wood(updatedUser.getWood())
                .iron(updatedUser.getIron())
                .magicPowder(updatedUser.getMagicPowder())
                .territoryLevel(updatedUser.getTerritoryLevel()) // ⭐ 업데이트된 영지 레벨 포함 ⭐
                .build();

        return ResponseEntity.ok(userDto);
    }

    // ⭐ 새로 추가되는 API: 영지 업그레이드 완료 처리 및 보너스 자원 지급 ⭐
    // 이 API는 영지 업그레이드 카운트다운이 완료되었을 때 프론트엔드에서 호출됩니다.
    @PostMapping("/{userId}/complete-territory-upgrade")
    public ResponseEntity<UserResponseDto> completeTerritoryUpgrade(@PathVariable Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + userId));

        // 여기서 user.getTerritoryLevel()은 이미 프론트에서 레벨을 증가시킨 후
        // updateResources API를 통해 저장된 최신 레벨일 것입니다.
        // 따라서 이 레벨에 맞춰 보너스 자원을 계산하여 지급합니다.
        int currentTerritoryLevel = user.getTerritoryLevel();

        // ⭐ 영지 레벨에 따른 보너스 자원 계산 (이 값은 게임의 밸런스에 맞춰 조절 가능) ⭐
        // 예시: 레벨이 오를 때마다 골드 50, 식량 20, 목재 30, 철 10, 신비한 가루 5 추가
        // 레벨이 높을수록 보너스도 증가하도록 currentTerritoryLevel을 곱합니다.
        int bonusGold = 50 * currentTerritoryLevel;
        int bonusFood = 20 * currentTerritoryLevel;
        int bonusWood = 30 * currentTerritoryLevel;
        int bonusIron = 10 * currentTerritoryLevel;
        int bonusMagicPowder = 5 * currentTerritoryLevel;

        user.addGold(bonusGold);
        user.addFood(bonusFood);
        user.addWood(bonusWood);
        user.addIron(bonusIron);
        user.addMagicPowder(bonusMagicPowder);

        User updatedUser = userRepository.save(user); // 변경된 사용자 정보를 저장

        // 업데이트된 사용자 정보를 DTO로 변환하여 프론트엔드에 반환
        UserResponseDto userDto = UserResponseDto.builder()
                .id(updatedUser.getId())
                .username(updatedUser.getUsername())
                .gold(updatedUser.getGold())
                .food(updatedUser.getFood())
                .wood(updatedUser.getWood())
                .iron(updatedUser.getIron())
                .magicPowder(updatedUser.getMagicPowder())
                .territoryLevel(updatedUser.getTerritoryLevel())
                .build();

        return ResponseEntity.ok(userDto);
    }
}