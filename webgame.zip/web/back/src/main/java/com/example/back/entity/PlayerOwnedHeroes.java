// src/main/java/com/example/back/entity/PlayerOwnedHeroes.java (수정된 엔티티)
package com.example.back.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import jakarta.persistence.FetchType;

@Entity
@Table(name = "player_owned_heroes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerOwnedHeroes {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "player_hero_id") // <<< 이 줄을 추가하여 데이터베이스 컬럼 이름과 매핑
    private Long id; // 플레이어 소유 영웅의 고유 ID

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // 영웅을 소유한 플레이어 엔티티 (User 엔티티와 연결)

    @ManyToOne(fetch = FetchType.LAZY) // ⭐ EAGER 대신 LAZY로 변경 ⭐
    @JoinColumn(name = "unit_id", nullable = false)
    private Unit unit;

    @Column(name = "level", nullable = false)
    private Integer level; // 영웅의 현재 레벨 (데이터베이스의 'level' 컬럼에 매핑)

    @Column(name = "current_exp", nullable = false)
    private Long currentExp; // 현재 레벨에서 누적된 경험치

    @Column(name = "required_exp_for_next_level", nullable = false)
    private Long requiredExpForNextLevel; // 다음 레벨로 가기 위해 필요한 총 경험치

    @Column(name = "current_hp", nullable = false)
    private Integer currentHp; // 영웅의 현재 체력

    @Column(name = "current_attack", nullable = false)
    private Integer currentAttack; // 영웅의 현재 공격력

    @Column(name = "current_defense", nullable = false)
    private Integer currentDefense; // 영웅의 현재 방어력

    @Column(name = "is_equipped", nullable = false)
    private Boolean isEquipped; // 파티에 장착되어 있는지 여부

    @Column(name = "slot_index") // 파티 내 배치된 슬롯 위치 (장착 시에만 유효)
    private Integer slotIndex;

    @Column(name = "level_up_hp_bonus", nullable = false)
    private Integer levelUpHpBonus; // 레벨업 시 순수하게 증가한 체력 보너스 (누적)

    @Column(name = "level_up_attack_bonus", nullable = false)
    private Integer levelUpAttackBonus; // 레벨업 시 순수하게 증가한 공격력 보너스 (누적)

    @Column(name = "level_up_defense_bonus", nullable = false)
    private Integer levelUpDefenseBonus; // 레벨업 시 순수하게 증가한 방어력 보너스 (누적)


}