package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserResourceUpdateRequestDto {
    private int gold;
    private int food;
    private int wood;
    private int iron;
    private int magicPowder;
    private Integer territoryLevel; // null을 허용하기 위해 Integer로 선언
}