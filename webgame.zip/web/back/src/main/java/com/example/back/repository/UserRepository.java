package com.example.back.repository;


import com.example.back.entity.User;

import org.springframework.data.jpa.repository.JpaRepository; // JpaRepository 임포트
import java.util.Optional; // Optional 임포트

// JpaRepository를 상속받아 User 엔티티와 그 기본 키(Long)를 지정합니다.
public interface UserRepository extends JpaRepository<User, Long> {

    // 사용자 ID(username)로 User를 찾는 쿼리 메서드를 정의합니다.
    // Spring Data JPA가 메서드 이름을 분석하여 자동으로 SQL 쿼리를 생성합니다.
    Optional<User> findByUsername(String username);
}