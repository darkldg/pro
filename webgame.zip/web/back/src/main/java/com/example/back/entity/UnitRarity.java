// C:\Users\lee\Desktop\web\back\src\main\java\com\example\back\entity\UnitRarity.java
package com.example.back.entity;

public enum UnitRarity { // public 키워드 추가
    NORMAL,
    RARE,
    UNIQUE
}