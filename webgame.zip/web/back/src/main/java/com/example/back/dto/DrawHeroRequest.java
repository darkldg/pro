package com.example.back.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DrawHeroRequest {
    private Long heroId; // 프론트에서 선택한 영웅의 ID
    private Integer cost; // 뽑기 비용
}