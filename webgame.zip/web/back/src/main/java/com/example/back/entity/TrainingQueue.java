package com.example.back.entity; // 적절한 패키지 경로로 수정해주세요.

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.Instant;

@Entity
@Table(name = "training_queue")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainingQueue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId; // User 엔티티의 ID와 연결

    @Column(name = "unit_id", nullable = false)
    private Long unitId; // 훈련 중인 Unit 엔티티의 ID

    @Column(name = "quantity", nullable = false)
    private int quantity; // 훈련 중인 유닛의 수량

    @Column(name = "start_time", nullable = false)
    private Instant  startTime; // 훈련 시작 시간

    @Column(name = "completion_time", nullable = false)
    private Instant  completionTime; // 훈련 완료 예상 시간
}