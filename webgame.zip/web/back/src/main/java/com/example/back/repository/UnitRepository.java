// src/main/java/com/example/back/repository/UnitRepository.java
package com.example.back.repository;

import com.example.back.entity.Unit;
import com.example.back.entity.UnitType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface UnitRepository extends JpaRepository<Unit, Long> {

    // Retrieves SOLDIER units below a specific barracks level (trainable units).
    @Query("SELECT u FROM Unit u LEFT JOIN FETCH u.passiveSkill WHERE u.requiredBarracksLevel <= :barracksLevel AND u.unitType = :unitType")
    List<Unit> findByRequiredBarracksLevelLessThanEqualAndUnitTypeWithPassiveSkill(@Param("barracksLevel") int barracksLevel, @Param("unitType") UnitType unitType);

    // Retrieves units by a list of IDs (used in parties, training queues, etc.).
    @Query("SELECT u FROM Unit u LEFT JOIN FETCH u.passiveSkill WHERE u.id IN :unitIds")
    List<Unit> findAllByIdWithPassiveSkill(@Param("unitIds") Set<Long> unitIds);

    // Retrieves units by UnitType (e.g., HERO type units).
    List<Unit> findByUnitType(UnitType unitType);

    // Retrieves a single unit by ID (when explicit fetching of lazy relationships is not needed).
    Optional<Unit> findById(Long id);

    // Retrieves a single unit by ID, fetching passiveSkill eagerly.
    // ⭐ This is the method causing the error in BarracksServiceImpl if missing ⭐
    @Query("SELECT u FROM Unit u LEFT JOIN FETCH u.passiveSkill WHERE u.id = :id")
    Optional<Unit> findByIdWithPassiveSkill(@Param("id") Long id);

    // ⭐ 유닛 이름으로 유닛을 찾는 메서드 추가 (BarracksServiceImpl 에서 필요) ⭐
    Optional<Unit> findByName(String name);
}