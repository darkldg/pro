// src/main/java/com/example/back/repository/TrainingQueueRepository.java (수정)
package com.example.back.repository;

import com.example.back.entity.TrainingQueue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TrainingQueueRepository extends JpaRepository<TrainingQueue, Long> {
    // 특정 User의 훈련 대기열을 완료 시간 기준으로 정렬하여 조회
    List<TrainingQueue> findByUserIdOrderByCompletionTimeAsc(Long userId);

    // 완료 시간이 현재 시간보다 이전인 훈련 대기열을 조회
    List<TrainingQueue> findByCompletionTimeBefore(Instant now);

    // 특정 User의 훈련 대기열에 있는 항목 수 조회
    long countByUserId(Long userId); // 이 메소드도 필요할 수 있으니 추가해둡니다.
}