package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data // Getter, Setter, toString, equals, hashCode 자동 생성
@NoArgsConstructor // 기본 생성자 자동 생성
@AllArgsConstructor // 모든 필드를 인자로 받는 생성자 자동 생성
public class ActivityLogEntryDto {
    private String message;
    private String type; // ⭐ 로그의 종류를 나타내는 필드 (예: "SYSTEM", "UPGRADE", "BARRACKS", "COMBAT")
    private LocalDateTime timestamp; // 로그가 발생한 시간
}