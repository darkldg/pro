// src/main/java/com/example/back/service/AuthService.java
package com.example.back.service;

import com.example.back.dto.LoginRequestDto;
import com.example.back.dto.LoginResponseDto;
import com.example.back.dto.RegisterRequestDto;
import com.example.back.entity.User;
// ⭐ 이 두 줄을 추가합니다. ⭐
import com.example.back.entity.Barracks;
import com.example.back.repository.BarracksRepository;
import com.example.back.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    // ⭐ BarracksRepository를 추가합니다. ⭐
    private final BarracksRepository barracksRepository;

    @Transactional
    public String registerUser(RegisterRequestDto requestDto) {
        if (userRepository.findByUsername(requestDto.getUsername()).isPresent()) {
            return "이미 존재하는 사용자 이름입니다.";
        }
        // 사용자가 처음 생성될 때 초기 자원 부여
        User newUser = User.builder()
                .username(requestDto.getUsername())
                // ⭐ 비밀번호를 일반 텍스트로 저장합니다. 보안 취약점이므로 실제 서비스에서는 절대 사용 금지 ⭐
                .password(requestDto.getPassword())
                .gold(1000)
                .food(500)
                .wood(500)
                .iron(500)
                .magicPowder(50) // 신비한 가루 초기값
                .build();
        userRepository.save(newUser);

        // ⭐ 이 부분을 새로 추가합니다: 사용자 생성 후 병영(Barracks)도 함께 생성 및 저장 ⭐
        Barracks newBarracks = Barracks.builder()
                .user(newUser) // 새로 생성된 User와 병영 연결
                .level(1) // 병영의 초기 레벨 (예시: 1)
                .trainingCapacity(5) // ⭐ 여기에 병영의 초기 훈련 수용량을 설정합니다. (예: 5) ⭐
                .isUpgrading(false) // 초기에는 업그레이드 중 아님
                .build();
        barracksRepository.save(newBarracks); // 새로 생성된 병영을 데이터베이스에 저장합니다.

        return "회원가입 성공!";
    }

    @Transactional(readOnly = true)
    public LoginResponseDto loginUser(LoginRequestDto requestDto) {
        Optional<User> userOptional = userRepository.findByUsername(requestDto.getUsername());

        // 사용자 존재 여부 및 비밀번호 일치 여부 확인 (일반 텍스트 비교)
        // ⭐ 비밀번호를 일반 텍스트로 비교합니다. 보안 취약점이므로 실제 서비스에서는 절대 사용 금지 ⭐
        if (userOptional.isEmpty() || !userOptional.get().getPassword().equals(requestDto.getPassword())) {
            return new LoginResponseDto(false, "아이디 또는 비밀번호가 잘못되었습니다.", null);
        }

        User user = userOptional.get();
        return new LoginResponseDto(true, "로그인 성공!", user.getId());
    }
}