// src/main/java/com/example/back/service/InnService.java
package com.example.back.service;

import com.example.back.dto.Hero;
import com.example.back.dto.UnitResponseDto;
import java.util.List;

public interface InnService {
    List<Hero> getAvailableHeroes();
    // ⭐ drawHero 메서드 시그니처 유지: heroId 추가 ⭐
    Hero drawHero(Long userId, Integer cost, Long heroId);
    List<UnitResponseDto> getAllOwnedUnitsAndHeroes(Long userId);
    String saveUserParty(Long userId, List<String> partyUnitIds);
    Hero levelUpHero(Long playerOwnedHeroId, Long expAmount);
}