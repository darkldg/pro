// src/main/java/com/example/back/controller/BarracksController.java
package com.example.back.controller;

import com.example.back.dto.BarracksInfoResponse;
import com.example.back.dto.SavePartyRequest;
import com.example.back.dto.TrainUnitRequest;
import com.example.back.dto.TrainUnitResponse;
import com.example.back.service.BarracksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/barracks")
@CrossOrigin(origins = "http://localhost:5173")
public class BarracksController {

    private final BarracksService barracksService;

    @Autowired
    public BarracksController(BarracksService barracksService) {
        this.barracksService = barracksService;
    }

    @GetMapping("/{userId}")
    public ResponseEntity<BarracksInfoResponse> getBarracksInfo(@PathVariable Long userId) {
        BarracksInfoResponse barracksInfo = barracksService.getBarracksInfo(userId);
        return ResponseEntity.ok(barracksInfo);
    }

    @PostMapping("/{userId}/upgrade")
    public ResponseEntity<String> upgradeBarracks(@PathVariable Long userId) {
        String result = barracksService.upgradeBarracks(userId);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/train")
    public ResponseEntity<TrainUnitResponse> trainUnit(@RequestBody TrainUnitRequest request) {
        TrainUnitResponse response = barracksService.trainUnit(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/{userId}/save-party")
    public ResponseEntity<String> saveParty(
            @PathVariable Long userId,
            @RequestBody SavePartyRequest request
    ) {
        String result = barracksService.saveParty(userId, request.getUnitIds(), request.getIsHeroes());
        return ResponseEntity.ok(result);
    }

    @PostMapping("/{userId}/disband-party")
    public ResponseEntity<String> disbandParty(@PathVariable Long userId) {
        String result = barracksService.disbandParty(userId);
        return ResponseEntity.ok(result);
    }

    // ⭐ 훈련 취소 API 추가 ⭐
    // POST 요청: /api/barracks/{userId}/cancel-training/{queueId}
    @PostMapping("/{userId}/cancel-training/{queueId}")
    public ResponseEntity<String> cancelTraining(
            @PathVariable Long userId,
            @PathVariable Long queueId) {
        String result = barracksService.cancelTraining(userId, queueId);
        return ResponseEntity.ok(result);
    }
}