// src/main/java/com/example/back/controller/InnController.java
package com.example.back.controller;

import com.example.back.dto.Hero;
import com.example.back.dto.UnitResponseDto;
import com.example.back.service.InnService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/inn")
@CrossOrigin(origins = "http://localhost:5173")
public class InnController {

    private final InnService innService;

    @Autowired
    public InnController(InnService innService) {
        this.innService = innService;
    }

    @GetMapping("/available-heroes")
    public ResponseEntity<List<Hero>> getAvailableHeroes() {
        List<Hero> heroes = innService.getAvailableHeroes();
        return ResponseEntity.ok(heroes);
    }

    // ⭐ drawHero 엔드포인트를 원래대로 복구하고, 요청 본문에서 heroId와 cost를 직접 파싱 ⭐
    @PostMapping("/draw-hero/{userId}")
    public ResponseEntity<Hero> drawHero(
            @PathVariable Long userId,
            @RequestBody Map<String, Object> requestBody) { // ⭐ Map으로 받아서 수동 파싱 ⭐
        try {
            Long heroId = ((Number) requestBody.get("heroId")).longValue(); // heroId 추출
            Integer cost = (Integer) requestBody.get("cost"); // cost 추출

            // ⭐ innService.drawHero 호출 시 heroId와 cost를 함께 전달합니다 ⭐
            Hero drawnHero = innService.drawHero(userId, cost, heroId);
            return ResponseEntity.ok(drawnHero);
        } catch (ClassCastException | NullPointerException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // 잘못된 요청 본문 형식
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    @GetMapping("/owned-units-heroes/{userId}")
    public ResponseEntity<List<UnitResponseDto>> getAllOwnedUnitsAndHeroes(@PathVariable Long userId) {
        try {
            List<UnitResponseDto> ownedUnits = innService.getAllOwnedUnitsAndHeroes(userId);
            return ResponseEntity.ok(ownedUnits);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(List.of()); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(List.of());
        }
    }

    @PostMapping("/save-party/{userId}")
    public ResponseEntity<String> saveUserParty(@PathVariable Long userId, @RequestBody List<String> partyUnitIds) {
        try {
            String result = innService.saveUserParty(userId, partyUnitIds);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("파티 저장 중 오류 발생: " + e.getMessage());
        }
    }

    @PostMapping("/level-up-hero/{playerOwnedHeroId}")
    public ResponseEntity<?> levelUpHero(@PathVariable Long playerOwnedHeroId, @RequestBody Map<String, Long> requestBody) {
        try {
            Long expAmount = requestBody.get("expAmount");
            if (expAmount == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("경험치 (expAmount)가 필요합니다.");
            }
            Hero updatedHero = innService.levelUpHero(playerOwnedHeroId, expAmount);
            return ResponseEntity.ok(updatedHero);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}