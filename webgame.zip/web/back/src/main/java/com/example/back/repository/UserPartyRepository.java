// src/main/java/com/example/back/repository/UserPartyRepository.java
package com.example.back.repository;

import com.example.back.entity.UserParty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UserPartyRepository extends JpaRepository<UserParty, Long> {
    List<UserParty> findByUserIdOrderBySlotNumberAsc(Long userId);
    // ⭐ 추가된 메소드: userId를 기준으로 UserParty 엔티티를 삭제합니다. ⭐
    void deleteByUserId(Long userId);
    List<UserParty> findByUserId(Long userId); // deleteAllInBatch 등을 위해 사용
}