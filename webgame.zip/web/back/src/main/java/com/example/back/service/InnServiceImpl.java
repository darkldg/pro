// src/main/java/com/example/back/service/InnServiceImpl.java
package com.example.back.service;

import com.example.back.dto.Hero;
import com.example.back.dto.UnitResponseDto;
import com.example.back.entity.PlayerHeroMastery;
import com.example.back.entity.PlayerOwnedHeroes;
import com.example.back.entity.Unit;
import com.example.back.entity.UnitType;
import com.example.back.entity.User;
import com.example.back.entity.UserUnit;
import com.example.back.repository.PlayerHeroMasteryRepository;
import com.example.back.repository.PlayerOwnedHeroesRepository;
import com.example.back.repository.UnitRepository;
import com.example.back.repository.UserRepository;
import com.example.back.repository.UserUnitRepository;
import jakarta.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random; // ⭐ 다시 복구 ⭐
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class InnServiceImpl implements InnService {

    private final PlayerOwnedHeroesRepository playerOwnedHeroesRepository;
    private final UserUnitRepository userUnitRepository;
    private final UnitRepository unitRepository;
    private final UserRepository userRepository;
    private final PlayerHeroMasteryRepository playerHeroMasteryRepository;

    @Autowired
    public InnServiceImpl(PlayerOwnedHeroesRepository playerOwnedHeroesRepository,
                          UserUnitRepository userUnitRepository,
                          UnitRepository unitRepository,
                          UserRepository userRepository,
                          PlayerHeroMasteryRepository playerHeroMasteryRepository) {
        this.playerOwnedHeroesRepository = playerOwnedHeroesRepository;
        this.userUnitRepository = userUnitRepository;
        this.unitRepository = unitRepository;
        this.userRepository = userRepository;
        this.playerHeroMasteryRepository = playerHeroMasteryRepository;
    }

    private int calculateMasteryBonus(int baseStat, int totalPermanentBonus) {
        return baseStat + totalPermanentBonus;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Hero> getAvailableHeroes() {
        log.info("[InnService] 현재 뽑기 가능한 영웅 목록을 데이터베이스에서 조회합니다.");
        List<Unit> heroUnits = unitRepository.findByUnitType(UnitType.HERO);

        if (heroUnits.size() > 4) {
            Collections.shuffle(heroUnits);
            heroUnits = heroUnits.subList(0, 4);
        }

        return heroUnits.stream()
                .map(Hero::fromUnit)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    // ⭐ heroId 파라미터 추가 및 로직 변경 ⭐
    public Hero drawHero(Long userId, Integer cost, Long heroId) {
        log.info("[InnService] 영웅 뽑기를 시도합니다. User ID: {}, Cost: {}, 선택 영웅 ID: {}", userId, cost, heroId);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));

        if (user.getMagicPowder() < cost) {
            throw new IllegalStateException("마법 가루가 부족합니다! 현재 마법 가루: " + user.getMagicPowder());
        }

        user.setMagicPowder(user.getMagicPowder() - cost);
        userRepository.save(user);
        log.info("[InnService] 사용자 마법 가루 {} 감소. 현재 마법 가루: {}", cost, user.getMagicPowder());

        // ⭐ 선택된 heroId로 특정 영웅을 찾습니다 (랜덤 뽑기 로직 제거) ⭐
        Unit chosenUnit = unitRepository.findById(heroId)
                .orElseThrow(() -> new EntityNotFoundException("선택된 영웅을 찾을 수 없습니다. Unit ID: " + heroId));

        if (!chosenUnit.getUnitType().equals(UnitType.HERO)) {
            throw new IllegalArgumentException("선택된 유닛은 영웅 타입이 아닙니다. Unit ID: " + heroId);
        }

        Optional<PlayerHeroMastery> existingMastery = playerHeroMasteryRepository.findByPlayerAndUnit(user, chosenUnit);
        PlayerHeroMastery playerMastery;

        int currentBonusHp = 0;
        int currentBonusAttack = 0;
        int currentBonusDefense = 0;

        if (existingMastery.isPresent()) {
            playerMastery = existingMastery.get();
            playerMastery.setAcquisitionCount(playerMastery.getAcquisitionCount() + 1);
            playerMastery.setMasteryLevel(playerMastery.getAcquisitionCount());

            playerMastery.setTotalPermanentHpBonus(playerMastery.getTotalPermanentHpBonus() + 10);
            playerMastery.setTotalPermanentAttackBonus(playerMastery.getTotalPermanentAttackBonus() + 5);
            // ⭐ 이전에 제가 수정했던 오타를 다시 사용자님 코드대로 복구합니다. ⭐
            playerMastery.setTotalPermanentAttackBonus(playerMastery.getTotalPermanentAttackBonus() + 3); // 다시 원래대로 (오타 포함)

            playerHeroMasteryRepository.save(playerMastery);
            log.info("[InnService] 영웅 {} (ID: {}) 중복 획득. 마스터리 카운트 증가: {}, 마스터리 레벨: {}. 누적 보너스: HP:{}, ATK:{}, DEF:{}",
                    chosenUnit.getName(), chosenUnit.getId(), playerMastery.getAcquisitionCount(), playerMastery.getMasteryLevel(),
                    playerMastery.getTotalPermanentHpBonus(), playerMastery.getTotalPermanentAttackBonus(), playerMastery.getTotalPermanentDefenseBonus());

            currentBonusHp = playerMastery.getTotalPermanentHpBonus();
            currentBonusAttack = playerMastery.getTotalPermanentAttackBonus();
            currentBonusDefense = playerMastery.getTotalPermanentDefenseBonus(); // 이 값은 실제 totalPermanentDefenseBonus로 사용되어야 하지만, 오타는 유지합니다.

        } else {
            playerMastery = PlayerHeroMastery.builder()
                    .player(user)
                    .unit(chosenUnit)
                    .acquisitionCount(1)
                    .masteryLevel(1)
                    .totalPermanentHpBonus(0)
                    .totalPermanentAttackBonus(0)
                    .totalPermanentDefenseBonus(0)
                    .build();
            playerHeroMasteryRepository.save(playerMastery);
            log.info("[InnService] 새로운 영웅 종류 {} (ID: {}) 첫 획득. 마스터리 생성. 마스터리 레벨: {}", chosenUnit.getName(), chosenUnit.getId(), playerMastery.getMasteryLevel());
        }

        Optional<PlayerOwnedHeroes> optionalExistingOwnedHero = playerOwnedHeroesRepository.findByUserAndUnit(user, chosenUnit);

        PlayerOwnedHeroes targetOwnedHero;
        if (optionalExistingOwnedHero.isPresent()) {
            targetOwnedHero = optionalExistingOwnedHero.get();

            int levelUpHpBonus = (targetOwnedHero.getLevel() - 1) * 10;
            int levelUpAttackBonus = (targetOwnedHero.getLevel() - 1) * 5;
            int levelUpDefenseBonus = (targetOwnedHero.getLevel() - 1) * 3;

            targetOwnedHero.setLevelUpHpBonus(levelUpHpBonus);
            targetOwnedHero.setLevelUpAttackBonus(levelUpAttackBonus);
            targetOwnedHero.setLevelUpDefenseBonus(levelUpDefenseBonus);

            targetOwnedHero.setCurrentHp(chosenUnit.getBaseHealth() + levelUpHpBonus + currentBonusHp);
            targetOwnedHero.setCurrentAttack(chosenUnit.getBaseAttack() + levelUpAttackBonus + currentBonusAttack);
            targetOwnedHero.setCurrentDefense(chosenUnit.getBaseDefense() + levelUpDefenseBonus + currentBonusDefense);

            playerOwnedHeroesRepository.save(targetOwnedHero);
            log.info("[InnService] 기존 영웅 인스턴스 {} (ID: {}) 스탯 업데이트 완료. 최종 스탯: HP:{}, ATK:{}, DEF:{}",
                    targetOwnedHero.getUnit().getName(), targetOwnedHero.getId(),
                    targetOwnedHero.getCurrentHp(), targetOwnedHero.getCurrentAttack(), targetOwnedHero.getCurrentDefense());

        } else {
            targetOwnedHero = PlayerOwnedHeroes.builder()
                    .user(user)
                    .unit(chosenUnit)
                    .level(1)
                    .currentExp(0L)
                    .requiredExpForNextLevel(100L)
                    .levelUpHpBonus(0)
                    .levelUpAttackBonus(0)
                    .levelUpDefenseBonus(0)
                    .currentHp(chosenUnit.getBaseHealth() + currentBonusHp)
                    .currentAttack(chosenUnit.getBaseAttack() + currentBonusAttack)
                    .currentDefense(chosenUnit.getBaseDefense() + currentBonusDefense)
                    .isEquipped(false)
                    .slotIndex(null)
                    .build();
            playerOwnedHeroesRepository.save(targetOwnedHero);
            log.info("[InnService] 새로운 영웅 인스턴스 획득 및 저장: {} (PlayerOwnedHeroes ID: {})", targetOwnedHero.getUnit().getName(), targetOwnedHero.getId());
        }

        return Hero.fromPlayerOwnedHeroWithMastery(targetOwnedHero, currentBonusHp, currentBonusAttack, currentBonusDefense);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UnitResponseDto> getAllOwnedUnitsAndHeroes(Long userId) {
        log.info("[InnService] 사용자 보유 유닛 및 영웅 목록을 데이터베이스에서 조회합니다. User ID: {}", userId);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));

        List<UnitResponseDto> allOwnedUnits = new ArrayList<>();

        List<PlayerOwnedHeroes> ownedHeroes = playerOwnedHeroesRepository.findByUserWithHeroUnit(user);
        for (PlayerOwnedHeroes poh : ownedHeroes) {
            Optional<PlayerHeroMastery> mastery = playerHeroMasteryRepository.findByPlayerAndUnit(user, poh.getUnit());
            int bonusHp = mastery.map(PlayerHeroMastery::getTotalPermanentHpBonus).orElse(0);
            int bonusAttack = mastery.map(PlayerHeroMastery::getTotalPermanentAttackBonus).orElse(0);
            int bonusDefense = mastery.map(PlayerHeroMastery::getTotalPermanentDefenseBonus).orElse(0);

            UnitResponseDto dto = UnitResponseDto.fromPlayerOwnedHero(poh, bonusHp, bonusAttack, bonusDefense);
            allOwnedUnits.add(dto);
        }

        List<UserUnit> userUnits = userUnitRepository.findByUserId(userId);
        for (UserUnit uu : userUnits) {
            Optional<Unit> unitOptional = unitRepository.findById(uu.getUnitId());
            if (unitOptional.isPresent()) {
                Unit unit = unitOptional.get();
                allOwnedUnits.add(UnitResponseDto.fromUserUnit(uu, unit));
            } else {
                log.warn("UserUnit에 연결된 Unit(ID: {})을 찾을 수 없습니다.", uu.getUnitId());
            }
        }
        return allOwnedUnits;
    }

    @Override
    @Transactional
    public String saveUserParty(Long userId, List<String> partyUnitIds) {
        log.info("[InnService] 사용자 파티 저장을 시도합니다. User ID: {}", userId);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));

        List<PlayerOwnedHeroes> currentPartyHeroes = playerOwnedHeroesRepository.findByUserAndIsEquipped(user, true);
        for (PlayerOwnedHeroes hero : currentPartyHeroes) {
            hero.setIsEquipped(false);
            hero.setSlotIndex(null);
            playerOwnedHeroesRepository.save(hero);
        }
        log.info("[InnService] 기존 파티 설정 초기화 완료.");

        for (int i = 0; i < partyUnitIds.size(); i++) {
            String unitIdStr = partyUnitIds.get(i);
            if (unitIdStr != null && !unitIdStr.isEmpty()) {
                try {
                    Long playerOwnedHeroId = Long.parseLong(unitIdStr);
                    PlayerOwnedHeroes heroToEquip = playerOwnedHeroesRepository.findById(playerOwnedHeroId)
                            .orElseThrow(() -> new EntityNotFoundException("PlayerOwnedHero not found with ID: " + playerOwnedHeroId));

                    if (!heroToEquip.getUser().getId().equals(userId)) {
                        throw new IllegalStateException("해당 영웅을 소유하고 있지 않습니다: " + playerOwnedHeroId);
                    }

                    heroToEquip.setIsEquipped(true);
                    heroToEquip.setSlotIndex(i);
                    playerOwnedHeroesRepository.save(heroToEquip);
                    log.info("[InnService] 영웅 {} (ID: {})을 파티 슬롯 {}에 장착 완료.", heroToEquip.getUnit().getName(), playerOwnedHeroId, i);
                } catch (NumberFormatException e) {
                    log.warn("[InnService] 유효하지 않은 파티 슬롯 ID: {}", unitIdStr);
                }
            }
        }
        log.info("[InnService] 사용자 파티 저장 완료.");
        return "파티가 성공적으로 저장되었습니다!";
    }

    @Override
    @Transactional
    public Hero levelUpHero(Long playerOwnedHeroId, Long expAmount) {
        log.info("[InnService] 영웅 레벨업을 시도합니다. PlayerOwnedHero ID: {}, 경험치: {}", playerOwnedHeroId, expAmount);

        PlayerOwnedHeroes hero = playerOwnedHeroesRepository.findById(playerOwnedHeroId)
                .orElseThrow(() -> new EntityNotFoundException("PlayerOwnedHero not found with ID: " + playerOwnedHeroId));

        hero.setCurrentExp(hero.getCurrentExp() + expAmount);
        log.info("[InnService] 영웅 {} (ID: {}) 경험치 획득. 현재 경험치: {}", hero.getUnit().getName(), playerOwnedHeroId, hero.getCurrentExp());

        while (hero.getCurrentExp() >= hero.getRequiredExpForNextLevel()) {
            hero.setLevel(hero.getLevel() + 1);
            hero.setCurrentExp(hero.getCurrentExp() - hero.getRequiredExpForNextLevel());

            hero.setRequiredExpForNextLevel(hero.getRequiredExpForNextLevel() + 50);

            hero.setCurrentHp(hero.getCurrentHp() + 10);
            hero.setCurrentAttack(hero.getCurrentAttack() + 5);
            hero.setCurrentDefense(hero.getCurrentDefense() + 3);

            hero.setLevelUpHpBonus((hero.getLevel() - 1) * 10);
            hero.setLevelUpAttackBonus((hero.getLevel() - 1) * 5);
            hero.setLevelUpDefenseBonus((hero.getLevel() - 1) * 3);

            log.info("[InnService] 영웅 {} (ID: {}) 레벨업! 새로운 레벨: {}, 남은 경험치: {}", hero.getUnit().getName(), playerOwnedHeroId, hero.getLevel(), hero.getCurrentExp());
        }

        playerOwnedHeroesRepository.save(hero);
        log.info("[InnService] 영웅 {} (ID: {}) 레벨업 처리 완료. 최종 레벨: {}, 최종 스탯: HP {}, ATK {}, DEF {}",
                hero.getUnit().getName(), playerOwnedHeroId, hero.getLevel(), hero.getCurrentHp(), hero.getCurrentAttack(), hero.getCurrentDefense());

        Optional<PlayerHeroMastery> mastery = playerHeroMasteryRepository.findByPlayerAndUnit(hero.getUser(), hero.getUnit());
        int bonusHp = mastery.map(PlayerHeroMastery::getTotalPermanentHpBonus).orElse(0);
        int bonusAttack = mastery.map(PlayerHeroMastery::getTotalPermanentAttackBonus).orElse(0);
        int bonusDefense = mastery.map(PlayerHeroMastery::getTotalPermanentDefenseBonus).orElse(0);

        return Hero.fromPlayerOwnedHeroWithMastery(hero, bonusHp, bonusAttack, bonusDefense);
    }
}