// src/main/java/com/example/back/dto/TrainingQueueItemDTO.java (수정 제안)
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainingQueueItemDTO {
    private Long id; // TrainingQueue의 ID (선택 사항)
    private String unitName;
    private int quantity;
    private Instant completionTime;
    private long remainingSeconds; // 훈련 완료까지 남은 시간 (초)
}