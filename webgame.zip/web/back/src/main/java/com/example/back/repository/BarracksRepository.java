// src/main/java/com/example/back/repository/BarracksRepository.java (수정된 리포지토리)
package com.example.back.repository;

import com.example.back.entity.Barracks;
import com.example.back.entity.User; // User 엔티티 import
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BarracksRepository extends JpaRepository<Barracks, Long> {
    // userId 대신 User 엔티티로 Barracks를 찾는 메소드 추가
    Optional<Barracks> findByUser(User user);

    // ⭐ 이 메서드를 추가해야 합니다! ⭐
    List<Barracks> findByIsUpgrading(Boolean isUpgrading);

    Optional<Barracks> findByUserId(Long userId);

    // isUpgrading이 true이고, upgradeCompletionTime이 주어진 시간(now) 이전인 Barracks를 찾습니다.
    List<Barracks> findByIsUpgradingTrueAndUpgradeCompletionTimeBefore(LocalDateTime upgradeCompletionTime);

}
