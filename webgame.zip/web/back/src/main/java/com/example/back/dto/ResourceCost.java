// src/main/java/com/example/back/dto/ResourceCost.java
package com.example.back.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResourceCost {
    private int gold;
    private int wood;
    private int iron;
    // 필요한 경우 다른 자원 추가
}