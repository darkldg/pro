package com.example.back.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ResourceUpdateRequest {
    private String resourceType; // "ore" 또는 "wood"
    private int amount; // 획득량
}