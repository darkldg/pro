// src/main/java/com/example/back/dto/Hero.java (수정될 내용)
package com.example.back.dto;

import com.example.back.entity.PlayerOwnedHeroes;
import com.example.back.entity.Unit;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Hero {
    private Long id;
    private String name;
    private String illustrationUrl;
    private String unitType;
    private String unitClass;
    private String unitRarity;

    private Integer level;
    private Long currentExp;
    private Long requiredExpForNextLevel;
    private Integer currentHp;
    private Integer currentAttack;
    private Integer currentDefense;

    public static Hero fromUnit(Unit unit) {
        if (unit == null) {
            return null;
        }
        return Hero.builder()
                .id(unit.getId())
                .name(unit.getName())
                .illustrationUrl(unit.getIllustrationUrl())
                .unitType(unit.getUnitType() != null ? unit.getUnitType().name() : null)
                .unitClass(unit.getUnitClass() != null ? unit.getUnitClass().name() : null)
                .unitRarity(unit.getUnitRarity() != null ? unit.getUnitRarity().name() : null)
                .level(1) // 기본 유닛 정보이므로 레벨 1
                .currentExp(0L)
                .requiredExpForNextLevel(0L) // UI 표시용, 실제 값은 백엔드 로직에 따름
                .currentHp(unit.getBaseHealth())
                .currentAttack(unit.getBaseAttack())
                .currentDefense(unit.getBaseDefense())
                .build();
    }

    // ⭐ 기존 fromPlayerOwnedHero를 수정 또는 오버로드: 마스터리 보너스 인자를 받도록 ⭐
    // 이 메서드는 이제 PlayerOwnedHeroes의 스탯에 마스터리 보너스를 합산하여 반환합니다.
    public static Hero fromPlayerOwnedHeroWithMastery(PlayerOwnedHeroes playerOwnedHero,
                                                      int masteryBonusHp,
                                                      int masteryBonusAttack,
                                                      int masteryBonusDefense) {
        if (playerOwnedHero == null) {
            return null;
        }
        Unit unit = playerOwnedHero.getUnit();
        return Hero.builder()
                .id(playerOwnedHero.getId())
                .name(unit.getName())
                .illustrationUrl(unit.getIllustrationUrl())
                .unitType(unit.getUnitType() != null ? unit.getUnitType().name() : null)
                .unitClass(unit.getUnitClass() != null ? unit.getUnitClass().name() : null)
                .unitRarity(unit.getUnitRarity() != null ? unit.getUnitRarity().name() : null)
                .level(playerOwnedHero.getLevel())
                .currentExp(playerOwnedHero.getCurrentExp())
                .requiredExpForNextLevel(playerOwnedHero.getRequiredExpForNextLevel())
                // ⭐ PlayerOwnedHeroes의 현재 스탯에 마스터리 보너스를 합산 ⭐
                .currentHp(playerOwnedHero.getCurrentHp() + masteryBonusHp)
                .currentAttack(playerOwnedHero.getCurrentAttack() + masteryBonusAttack)
                .currentDefense(playerOwnedHero.getCurrentDefense() + masteryBonusDefense)
                .build();
    }

    // 기존 fromPlayerOwnedHero도 유지 (혹시 다른 곳에서 마스터리 없이 순수 PlayerOwnedHeroes만 필요할 경우)
    public static Hero fromPlayerOwnedHero(PlayerOwnedHeroes playerOwnedHero) {
        // 이 메서드는 이제 마스터리 보너스가 합산되지 않은 순수 PlayerOwnedHeroes의 스탯만 반환합니다.
        // 또는, 위 fromPlayerOwnedHeroWithMastery를 호출하여 0,0,0을 전달하도록 변경할 수도 있습니다.
        if (playerOwnedHero == null) {
            return null;
        }
        Unit unit = playerOwnedHero.getUnit();
        return Hero.builder()
                .id(unit.getId())
                .name(unit.getName())
                .illustrationUrl(unit.getIllustrationUrl())
                .unitType(unit.getUnitType() != null ? unit.getUnitType().name() : null)
                .unitClass(unit.getUnitClass() != null ? unit.getUnitClass().name() : null)
                .unitRarity(unit.getUnitRarity() != null ? unit.getUnitRarity().name() : null)
                .level(1) // 기본 유닛 정보이므로 레벨 1
                .currentExp(0L)
                .requiredExpForNextLevel(0L) // UI 표시용, 실제 값은 백엔드 로직에 따름
                .currentHp(unit.getBaseHealth()) // ⭐ 이 부분! baseHealth가 currentHp로 매핑됩니다.
                .currentAttack(unit.getBaseAttack()) // ⭐ 이 부분! baseAttack이 currentAttack으로 매핑됩니다.
                .currentDefense(unit.getBaseDefense()) // ⭐ 이 부분! baseDefense가 currentDefense로 매핑됩니다.
                .build();
    }
}