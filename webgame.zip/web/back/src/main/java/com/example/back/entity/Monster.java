// src/main/java/com/example/back/entity/Monster.java

package com.example.back.entity; // 패키지 경로 변경됨

import lombok.AllArgsConstructor;
import lombok.Getter; // @Getter 명시적으로 추가
import lombok.NoArgsConstructor;
import lombok.Setter; // @Setter 명시적으로 추가
// import lombok.Data; // @Data 대신 @Getter, @Setter 사용

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

// Lombok의 @NoArgsConstructor는 인자 없는 기본 생성자를 자동 생성합니다.
// JPA는 엔티티 클래스에 기본 생성자가 반드시 필요합니다.
@NoArgsConstructor
// Lombok의 @AllArgsConstructor는 모든 필드를 인자로 받는 생성자를 자동 생성합니다.
// 이는 DataLoader 등에서 객체를 편리하게 생성할 때 유용합니다.
@AllArgsConstructor
// JPA 엔티티로 이 클래스가 데이터베이스 테이블과 매핑됨을 나타냅니다.
@Entity
// @Data 대신 @Getter와 @Setter를 명시적으로 사용합니다.
@Getter
@Setter
// 이 엔티티가 매핑될 데이터베이스 테이블의 이름을 지정합니다.
@Table(name = "monsters")
public class Monster {

    // 기본 키 필드를 나타냅니다.
    @Id
    @Column(name = "id") // 테이블 컬럼명과 필드명이 다를 경우 지정
    private String id;

    @Column(name = "name", nullable = false) // null을 허용하지 않음
    private String name;

    @Column(name = "stage", nullable = false)
    private int stage;

    @Column(name = "type", nullable = false)
    private String type; // B: 일반 몬스터, V: 보스 몬스터

    @Column(name = "attack", nullable = false)
    private int attack;

    @Column(name = "defense", nullable = false)
    private int defense;

    @Column(name = "hp", nullable = false)
    private int hp;

    @Column(name = "exp", nullable = false)
    private int exp;

    @Column(name = "illustration_url")
    private String illustrationUrl;

    // Lombok 어노테이션 덕분에 Getter/Setter 메소드를 직접 작성할 필요가 없습니다.
    // @NoArgsConstructor, @AllArgsConstructor 덕분에 생성자도 직접 작성할 필요가 없습니다.
}
