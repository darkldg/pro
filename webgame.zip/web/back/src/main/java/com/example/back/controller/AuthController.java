// src/main/java/com/example/back/controller/AuthController.java
package com.example.back.controller;

import com.example.back.dto.LoginRequestDto;
import com.example.back.dto.LoginResponseDto;
import com.example.back.dto.RegisterRequestDto;
import com.example.back.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
// ⭐ CORS 허용 설정: 프론트엔드 주소에서 오는 요청을 허용합니다. ⭐
@CrossOrigin(origins = "http://localhost:5173")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    // 회원가입 API
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody RegisterRequestDto requestDto) {
        String message = authService.registerUser(requestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(message);
    }

    // 로그인 API
    @PostMapping("/loginUser")
    public ResponseEntity<LoginResponseDto> loginUser(@RequestBody LoginRequestDto requestDto) {
        // AuthService에서 사용자 ID를 포함한 응답을 받습니다.
        LoginResponseDto responseDto = authService.loginUser(requestDto);
        // 로그인 성공 여부에 따라 HTTP 상태 코드를 다르게 보낼 수 있습니다.
        // 현재는 메시지에 따라 프론트에서 처리하도록 동일하게 OK (200)을 보냅니다.
        return ResponseEntity.ok(responseDto);
    }
}
