// src/main/java/com/example/back/dto/SavePartyRequest.java
package com.example.back.dto;

import lombok.Data;
import java.util.List;

@Data // Getter, Setter, equals, hashCode, toString 자동 생성
public class SavePartyRequest {
    private List<Long> unitIds;
    private List<Boolean> isHeroes;
}