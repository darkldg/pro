package com.example.back.repository;

import com.example.back.entity.UserUnit;
import com.example.back.entity.User; // User 임포트 (findById 메서드에 필요)
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserUnitRepository extends JpaRepository<UserUnit, Long> {

    // userId를 이용하여 UserUnit 목록을 조회하는 메서드 추가
    List<UserUnit> findByUserId(Long userId);

    // 필요하다면, 특정 유저와 특정 유닛 ID로 조회하는 메서드도 추가할 수 있습니다.
    Optional<UserUnit> findByUserIdAndUnitId(Long userId, Long unitId);
}