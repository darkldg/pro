package com.example.back.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Player와 Units 엔티티 (실제 프로젝트에 맞게 정의 필요)
// import com.yourgame.model.Player;
// import com.yourgame.model.Units;

@Entity // 이 클래스가 JPA 엔티티임을 나타냅니다.
@Table(name = "player_hero_mastery") // 매핑될 데이터베이스 테이블 이름을 지정합니다.
@Getter // Lombok: 모든 필드에 대한 Getter 메소드를 자동 생성합니다.
@Setter // Lombok: 모든 필드에 대한 Setter 메소드를 자동 생성합니다.
@NoArgsConstructor // Lombok: 기본 생성자를 자동 생성합니다.
@AllArgsConstructor // Lombok: 모든 필드를 인자로 받는 생성자를 자동 생성합니다.
@Builder // Lombok: 빌더 패턴을 사용하여 객체를 생성할 수 있게 합니다.
public class PlayerHeroMastery {

    @Id // 기본 키(Primary Key)임을 나타냅니다.
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 데이터베이스에서 ID가 자동으로 생성되도록 합니다.
    @Column(name = "mastery_id") // 데이터베이스 컬럼 이름을 지정합니다.
    private Long masteryId; // 플레이어-영웅 종류 조합의 고유 ID

    // 'Player' 엔티티와의 다대일(ManyToOne) 관계 설정
    // 한 명의 플레이어가 여러 영웅 종류에 대한 마스터리 정보를 가질 수 있습니다.
    @ManyToOne
    @JoinColumn(name = "player_id", nullable = false) // player_id 컬럼을 통해 Player 엔티티와 조인합니다. 필수 값.
    private User player; // 이 마스터리 정보를 소유한 플레이어 엔티티

    // 'Units' 엔티티와의 다대일(ManyToOne) 관계 설정
    // 여러 PlayerHeroMastery 인스턴스가 하나의 Units 데이터(특정 영웅 종류)를 참조할 수 있습니다.
    @ManyToOne
    @JoinColumn(name = "unit_id", nullable = false) // unit_id 컬럼을 통해 Units 엔티티와 조인합니다. 필수 값.
    private Unit unit; // 이 마스터리 정보가 어떤 종류의 영웅에 대한 것인지 나타내는 Units 엔티티

    @Column(name = "acquisition_count", nullable = false)
    private Integer acquisitionCount; // 해당 영웅 종류를 총 몇 번 획득했는지의 횟수

    @Column(name = "total_permanent_hp_bonus", nullable = false)
    private Integer totalPermanentHpBonus; // 중복 획득으로 누적된 영구 체력 보너스

    @Column(name = "total_permanent_attack_bonus", nullable = false)
    private Integer totalPermanentAttackBonus; // 중복 획득으로 누적된 영구 공격력 보너스

    @Column(name = "total_permanent_defense_bonus", nullable = false)
    private Integer totalPermanentDefenseBonus; // 중복 획득으로 누적된 영구 방어력 보너스

    @Column(name = "mastery_level", nullable = false)
    private Integer masteryLevel; // acquisition_count에 따라 결정되는 마스터리 레벨

    // 필요에 따라 추가적인 마스터리 효과 필드를 추가할 수 있습니다.
    // 예: 스킬 강화 레벨, 경험치 획득량 보너스 등
    // @Column(name = "exp_gain_bonus_percentage")
    // private Double expGainBonusPercentage;
}