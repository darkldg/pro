import React, { useContext, useEffect, useState, useRef } from 'react';
import { ActivityLogContext } from './ActivityLogContext'; // 경로 맞게 조정

function TerritoryResourceWatcher({ currentResources }) {
    const { addActivity } = useContext(ActivityLogContext);
    const prevResourcesRef = useRef(null);

    useEffect(() => {
        const prev = prevResourcesRef.current;
        if (prev) {
            // 자원별 증가량 계산
            const deltas = {
                gold: currentResources.gold - prev.gold,
                food: currentResources.food - prev.food,
                wood: currentResources.wood - prev.wood,
                iron: currentResources.iron - prev.iron,
                magicPowder: currentResources.magicPowder - prev.magicPowder,
            };

            // 증가량이 0보다 큰 자원만 메시지로 만들기
            const gainedResources = Object.entries(deltas)
                .filter(([_, delta]) => delta > 0)
                .map(([name, delta]) => `${name} +${delta}`);

            if (gainedResources.length > 0) {
                addActivity(`자원 획득: ${gainedResources.join(', ')}`, 'RESOURCE');
            }
        }
        // 현재 자원을 이전 자원으로 저장
        prevResourcesRef.current = { ...currentResources };
    }, [currentResources, addActivity]);

    return null; // 화면에 UI는 따로 없음, 감시용 컴포넌트
}
