import React, { createContext, useState, useCallback } from 'react';

export const ActivityLogContext = createContext();

export const ActivityLogProvider = ({ children }) => {
    const [activityLogs, setActivityLogs] = useState([]);

    const addActivity = useCallback((message, type = 'SYSTEM') => {
        const newLog = {
            type: type.toUpperCase(),
            message,
            timestamp: new Date(), // Date 객체로 저장 (시간 표시용)
        };

        setActivityLogs(prevLogs => {
            const updatedLogs = [newLog, ...prevLogs];
            // 로그는 최대 50개만 유지
            return updatedLogs.slice(0, 50);
        });

        // 자동 삭제는 하지 않습니다 (로그가 계속 남음)
    }, []);

    return (
        <ActivityLogContext.Provider value={{ activityLogs, addActivity }}>
            {children}
        </ActivityLogContext.Provider>
    );
};
