// src/services/AuthenticationService.jsx
import axios from 'axios';

const API_BASE_URL = '/api/auth';

const AuthenticationService = { // ⭐ 객체 이름도 AuthenticationService로 변경 ⭐
    register: async (username, password) => {
        try {
            const response = await axios.post(`${API_BASE_URL}/register`, { username, password });
            console.log("회원가입 성공 응답:", response.data);
            return response.data.message;
        } catch (error) {
            console.error('Registration error:', error.response ? error.response.data : error.message);
            if (error.response && error.response.data && error.response.data.message) {
                throw new Error(error.response.data.message);
            } else if (error.message) {
                throw new Error(`회원가입 중 오류: ${error.message}`);
            } else {
                throw new Error('회원가입 실패: 알 수 없는 오류가 발생했습니다.');
            }
        }
    },

    login: async (username, password) => {
        try {
            const response = await axios.post(`${API_BASE_URL}/loginUser`, { username, password });

            if (response.data.userId) {
                localStorage.setItem('currentUserId', response.data.userId);
                if (response.data.token) {
                    localStorage.setItem('userToken', response.data.token);
                    console.log("로그인 성공 (userId, token):", response.data.userId, response.data.token);
                } else {
                    console.warn("경고: 백엔드 로그인 응답에 토큰이 없습니다. 인증 헤더가 작동하지 않을 수 있습니다.");
                }
            } else {
                throw new Error(response.data.message || '로그인 실패: 사용자 ID가 없습니다.');
            }
            return response.data;
        } catch (error) {
            console.error('Login error:', error.response ? error.response.data : error.message);

            if (error.response && error.response.data && error.response.data.message) {
                throw new Error(error.response.data.message);
            } else if (error.response) {
                throw new Error(`로그인 오류: ${error.response.status} ${error.response.statusText}`);
            } else {
                throw new Error('로그인 중 네트워크 오류가 발생했습니다.');
            }
        }
    },

    getCurrentUserId: () => {
        return localStorage.getItem('currentUserId');
    },

    getAuthHeader: () => {
        const token = localStorage.getItem('userToken');
        if (token) {
            return { headers: { Authorization: 'Bearer ' + token } };
        } else {
            return {};
        }
    },

    logout: () => {
        localStorage.removeItem('currentUserId');
        localStorage.removeItem('userToken');
        console.log("로그아웃 되었습니다.");
    }
};

export default AuthenticationService; // ⭐ 변경된 객체 이름으로 export ⭐
