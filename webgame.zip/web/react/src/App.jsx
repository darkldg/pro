// src/App.jsx
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AuthPage from './components/AuthPage';

// VillagePage를 메인 레이아웃으로 사용하므로, VillagePage만 여기서 임포트합니다.
import VillagePage from './components/VillagePage';

import AuthenticationService from './services/AuthenticationService';
import { ActivityLogProvider } from './contexts/ActivityLogContext';

console.log("App.jsx: AuthenticationService 모듈 임포트됨:", AuthenticationService);
console.log("App.jsx: AuthenticationService.getCurrentUserId는 현재 타입:", typeof AuthenticationService.getCurrentUserId);


function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    console.log("App.jsx 렌더링 - isAuthenticated (초기화 후):", isAuthenticated);

    const handleAuthChange = (loggedIn) => {
        console.log("handleAuthChange 호출됨. 로그인 상태:", loggedIn);
        setIsAuthenticated(loggedIn);
    };

    useEffect(() => {
        console.log("App.jsx: useEffect 실행됨 (컴포넌트 마운트 시)");
        console.log("App.jsx: useEffect 내부에서 AuthenticationService.getCurrentUserId() 확인:", AuthenticationService.getCurrentUserId);

        // AuthenticationService.getCurrentUserId가 함수인지 확인 후 호출합니다.
        if (typeof AuthenticationService.getCurrentUserId === 'function') {
            const userId = AuthenticationService.getCurrentUserId();
            console.log("App.jsx: useEffect에서 가져온 userId:", userId);
            setIsAuthenticated(!!userId); // userId가 있으면 true, 없으면 false
        } else {
            console.error("App.jsx: useEffect 내부에서 AuthenticationService.getCurrentUserId가 함수가 아닙니다. 타입:", typeof AuthenticationService.getCurrentUserId);
            // 이 경우, localStorage에서 직접 userId를 확인하는 대체 로직을 추가할 수 있습니다.
            const directUserId = localStorage.getItem('currentUserId');
            if (directUserId) {
                console.log("App.jsx: localStorage에서 직접 userId 발견:", directUserId);
                setIsAuthenticated(true);
            }
        }
    }, []); // 빈 종속성 배열로 컴포넌트 마운트 시에만 실행

    return (
        <Router>
            {/* 모든 라우트를 ActivityLogProvider로 감싸서 컨텍스트 접근 가능하도록 합니다. */}
            <ActivityLogProvider>
                <Routes>
                    {/* 1. 기본 경로 "/" 처리: 현재 인증 상태에 따라 리다이렉트 */}
                    <Route
                        path="/"
                        element={isAuthenticated ? (
                            <Navigate to="/village" replace />
                        ) : (
                            <Navigate to="/auth" replace />
                        )}
                    />

                    {/* 2. "/auth" 경로: AuthPage를 보여줍니다. */}
                    <Route path="/auth" element={<AuthPage onAuthChange={handleAuthChange} />} />

                    {/* 3. "/village/*" 경로: VillagePage를 메인 레이아웃으로 사용하고, 그 안에 중첩 라우트를 허용합니다. */}
                    <Route
                        path="/village/*" // ⭐ 중요: 하위 라우트를 위한 와일드카드 추가 ⭐
                        element={
                            isAuthenticated ? (
                                <VillagePage onAuthChange={handleAuthChange} />
                            ) : (
                                <Navigate to="/auth" replace />
                            )
                        }
                    />

                    {/* 4. 정의되지 않은 모든 경로 처리: 현재 인증 상태에 따라 리다이렉트 */}
                    {/* VillagePage에서 모든 게임 내 페이지를 처리하므로, 다른 개별 페이지 경로는 제거되었습니다. */}
                    <Route
                        path="*"
                        element={isAuthenticated ? (
                            <Navigate to="/village" replace />
                        ) : (
                            <Navigate to="/auth" replace />
                        )}
                    />
                </Routes>
            </ActivityLogProvider>
        </Router>
    );
}

export default App;
