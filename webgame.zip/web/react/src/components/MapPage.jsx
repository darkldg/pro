// src/pages/MapPage.jsx
import React, { useState, useEffect, useRef, useCallback, useContext, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthService from "../services/AuthenticationService.jsx";
import { ActivityLogContext } from '../contexts/ActivityLogContext';
import './MapPage.css';
import axios from 'axios';
import BattleModal from '../components/BattleModal';

const BACKEND_BASE_URL = "http://localhost:7777";

const tileEmojis = {
    'G': '', // Grass (Empty)
    'B': '💀', // Regular Monster
    'V': '👹', // Boss Monster
};

const formatDuration = (totalSeconds) => {
    if (totalSeconds < 0) totalSeconds = 0;
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}분 ${String(seconds).padStart(2, '0')}초`;
};

const generateRandomMap = (regularMonsters, bossMonsters, mapSize) => {
    const map = [];
    const size = mapSize;
    const monsterTileCount = 40;

    for (let i = 0; i < size; i++) {
        map.push(Array(size).fill(['G', null, 0])); // 기본적으로 빈 타일 'G'로 채움
    }

    // 보스 몬스터를 각 꼭짓점에 고정 배치
    const bossData = bossMonsters && bossMonsters.length > 0
        ? bossMonsters?.[Math.floor(Math.random() * bossMonsters.length)]
        : null;

    if (bossData) {
        map[0][0] = ['V', bossData, 0]; // 좌측 상단
        map[0][size - 1] = ['V', bossData, 0]; // 우측 상단
        map[size - 1][0] = ['V', bossData, 0]; // 좌측 하단
        map[size - 1][size - 1] = ['V', bossData, 0]; // 우측 하단
    }

    if (regularMonsters && regularMonsters.length > 0) {
        let placedRegularMonsters = 0;
        while (placedRegularMonsters < monsterTileCount) {
            const r = Math.floor(Math.random() * size);
            const c = Math.floor(Math.random() * size);
            if (map?.[r]?.[c]?.[0] === 'G') {
                const originalMonsterData = regularMonsters?.[Math.floor(Math.random() * regularMonsters.length)];

                const randomQuantity = Math.floor(Math.random() * (5 - 2 + 1)) + 2; // 2에서 5까지 랜덤 숫자
                const monsterWithQuantity = { ...originalMonsterData, quantity: randomQuantity };

                map[r][c] = ['B', monsterWithQuantity, 0];
                placedRegularMonsters++;
            }
        }
    }
    return map;
};

const MapPage = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { activityLogs, addActivity } = useContext(ActivityLogContext);

    const [map, setMap] = useState([]);
    const [mapSize, setMapSize] = useState(16);
    const [playerPosition, setPlayerPosition] = useState({ r: 0, c: 0 });
    const [selectedTileInfo, setSelectedTileInfo] = useState(null);
    const [message, setMessage] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const [userInfo, setUserInfo] = useState(null);

    const [showBattleModal, setShowBattleModal] = useState(false);
    const [currentMonsterForBattle, setCurrentMonsterForBattle] = useState(null);
    const [currentPartyForBattle, setCurrentPartyForBattle] = useState([]);

    const memoizedMonsterForBattle = useMemo(() => {
        return currentMonsterForBattle;
    }, [
        currentMonsterForBattle?.id,
        currentMonsterForBattle?.hp,
        currentMonsterForBattle?.attack,
        currentMonsterForBattle?.defense,
        currentMonsterForBattle?.quantity // quantity를 useMemo 의존성에 추가
    ]);

    const memoizedPartyForBattle = useMemo(() => {
        if (!currentPartyForBattle || currentPartyForBattle.length === 0) {
            return [];
        }
        return currentPartyForBattle;
    }, [
        currentPartyForBattle.length,
        currentPartyForBattle.map(hero => `${hero.id}-${hero.currentHp}`).join(','),
    ]);


    const showMessage = useCallback((msg, duration = 3000) => {
        setMessage(msg);
        const timer = setTimeout(() => {
            setMessage('');
        }, duration);
        return () => clearTimeout(timer);
    }, []);

    const formatTime = useCallback((timestamp) => {
        if (!timestamp) return '';
        const date = new Date(timestamp);
        return date.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }, []);

    const fetchMapData = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const userId = AuthService.getCurrentUserId();
            if (!userId) {
                showMessage("유저 ID를 찾을 수 없습니다. 로그인 페이지로 이동합니다.");
                navigate('/auth');
                return;
            }

            const [regularMonstersRes, bossMonstersRes, userInfoRes] = await Promise.all([
                axios.get(`${BACKEND_BASE_URL}/api/monsters/type/B`),
                axios.get(`${BACKEND_BASE_URL}/api/monsters/type/V`),
                axios.get(`${BACKEND_BASE_URL}/api/users/${userId}`)
            ]);

            const regularMonsters = regularMonstersRes.data;
            const bossMonsters = bossMonstersRes.data;
            setUserInfo(userInfoRes.data);

            const newMap = generateRandomMap(regularMonsters, bossMonsters, mapSize);
            setMap(newMap);
            setPlayerPosition({ r: Math.floor(mapSize / 2), c: Math.floor(mapSize / 2) });
            addActivity("새로운 지도를 생성했습니다.");

        } catch (err) {
            console.error("지도 데이터 로딩 중 오류:", err);
            setError("지도를 불러오는 데 실패했습니다: " + (err.response?.data || err.message));
            showMessage("지도를 불러오는 데 실패했습니다.");
            addActivity("지도 로딩 실패.");
        } finally {
            setIsLoading(false);
        }
    }, [navigate, showMessage, addActivity, mapSize]);

    useEffect(() => {
        fetchMapData();
    }, [fetchMapData]);

    const handleTileClick = (r, c) => {
        if (!map || !map[r] || !map[r][c]) {
            console.warn(`Tile (${r}, ${c}) not found or map not initialized.`);
            return;
        }

        const tile = map[r][c];
        const tileType = tile?.[0];
        const tileData = tile?.[1];

        let info = null;
        let actions = [];

        if (tileType === 'B' || tileType === 'V') {
            const monsterName = tileData?.name || (tileType === 'B' ? '일반 몬스터' : '보스 몬스터');
            const monsterHp = tileData?.hp || '정보 없음';
            const monsterAttack = tileData?.attack || '정보 없음';
            const monsterDefense = tileData?.defense || '정보 없음';
            const monsterIllustrationUrl = tileData?.illustrationUrl;
            const monsterQuantity = tileData?.quantity || 1;
            const monsterStage = tileData?.stage || 1;

            let imageBorderStyle = '';
            if (tileType === 'B') {
                imageBorderStyle = '4px solid white';
            } else if (tileType === 'V') {
                imageBorderStyle = '4px solid red';
            }


            info = (
                <>
                    {monsterIllustrationUrl && (
                        <img
                            src={`${BACKEND_BASE_URL}${monsterIllustrationUrl}`}
                            alt={monsterName}
                            style={{
                                maxWidth: '200px',
                                maxHeight: '250px',
                                marginBottom: '10px',
                                border: imageBorderStyle,
                                borderRadius: '5px',
                            }}
                        />
                    )}
                    <h3>{monsterName} ({monsterQuantity}마리)</h3>
                    {monsterStage !== '정보 없음' && <p>단계: {monsterStage}</p>}
                    <p>공격력: {monsterAttack}</p>
                    <p>방어력: {monsterDefense}</p>
                    <p>체력: {monsterHp}</p>
                </>
            );
            actions.push({
                label: '공격',
                action: () => handleAttackMonster(r, c, monsterName, tileData)
            });
        }
        else if (tileType === 'G') {
            info = (
                <>
                    <h3>풀밭</h3>
                    <p>특이사항 없습니다.</p>
                </>
            );
        }

        setSelectedTileInfo({ r, c, type: tileType, info, actions });
    };

    const handleAttackMonster = async (r, c, monsterName, monsterData) => {
        const monsterQuantity = monsterData?.quantity || 1;
        addActivity(`${monsterName} ${monsterQuantity}마리 공격 시도.`);

        const userId = AuthService.getCurrentUserId();
        if (!userId) {
            showMessage("유저 ID를 찾을 수 없습니다. 로그인해주세요.");
            return;
        }

        try {
            const partyResponse = await axios.get(`${BACKEND_BASE_URL}/api/inn/owned-units-heroes/${userId}`);
            const equippedParty = partyResponse.data.filter(unit => unit.isEquipped && unit.unitType === 'HERO');

            if (equippedParty.length === 0) {
                showMessage("장착된 영웅이 없습니다. 여관에서 파티를 설정해주세요.");
                addActivity("전투 실패: 장착된 영웅 없음.");
                return;
            }

            // ⭐ 몬스터의 스탯을 수량에 따라 조정하지 않고, 원본 몬스터 데이터 (quantity 포함)를 그대로 전달 ⭐
            setCurrentMonsterForBattle(monsterData);
            setCurrentPartyForBattle(equippedParty);
            setShowBattleModal(true);

        } catch (error) {
            console.error("전투 준비 실패:", error);
            showMessage("전투 준비 실패: " + (error.response?.data?.message || error.message));
            addActivity("전투 준비 실패.");
        }
    };

    const handleBattleEnd = (result) => {
        setShowBattleModal(false);
        setCurrentMonsterForBattle(null);
        setCurrentPartyForBattle([]);
        showMessage(`전투 결과: ${result === 'win' ? '승리' : '패배'}!`);
        addActivity(`전투 결과: ${result === 'win' ? '승리' : '패배'}.`);
    };


    return (
        <div className="map-page-container">
            {message && (
                <div style={{
                    position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
                    backgroundColor: 'rgba(0, 0, 0, 0.7)', color: 'white', padding: '10px 20px',
                    borderRadius: '5px', zIndex: 1001, fontSize: '1.1em', textAlign: 'center'
                }}>
                    {message}
                </div>
            )}

            <main className="map-main-content">
                <div className="map-grid-container">
                    {(map || []).map((row, rIdx) => (
                        <div
                            key={rIdx}
                            className="map-row"
                            style={{ gridTemplateColumns: `repeat(${mapSize}, 40px)` }}
                        >
                            {row.map((tile, cIdx) => {
                                const halfSize = mapSize / 2;
                                let backgroundColor = '';

                                if (rIdx < halfSize && cIdx < halfSize) {
                                    backgroundColor = '#87CEEB';
                                } else if (rIdx < halfSize && cIdx >= halfSize) {
                                    backgroundColor = '#66CDAA';
                                } else if (rIdx >= halfSize && cIdx < halfSize) {
                                    backgroundColor = '#DAA520';
                                } else {
                                    backgroundColor = '#CD5C5C';
                                }

                                return (
                                    <div
                                        key={`${rIdx}-${cIdx}`}
                                        className={`map-tile ${tile?.[0] === 'B' || tile?.[0] === 'V' ? 'monster-tile' : ''}`}
                                        onClick={() => handleTileClick(rIdx, cIdx)}
                                        style={{ backgroundColor }}
                                    >
                                        {tileEmojis?.[tile?.[0]]}
                                    </div>
                                );
                            })}
                        </div>
                    ))}
                </div>

                <div className="side-panel">
                    {selectedTileInfo ? (
                        <>
                            <div className="tile-info">
                                {selectedTileInfo.info}
                            </div>
                            {selectedTileInfo.actions?.length > 0 && (
                                <div className="side-panel-buttons">
                                    {selectedTileInfo.actions.map((action, index) => (
                                        <button key={index} onClick={action.action} className="side-panel-button">
                                            {action.label}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="no-tile-selected" style={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                            <h2>지도를 클릭하여 타일 정보를 확인하세요</h2>
                        </div>
                    )}
                </div>
            </main>

            {/* BattleModal 렌더링 */}
            {showBattleModal && memoizedMonsterForBattle && (
                <BattleModal
                    isOpen={showBattleModal}
                    onClose={() => setShowBattleModal(false)}
                    monster={memoizedMonsterForBattle}
                    party={memoizedPartyForBattle}
                    onBattleEnd={handleBattleEnd}
                />
            )}
        </div>
    );
};

export default MapPage;