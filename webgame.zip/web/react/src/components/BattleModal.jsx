// src/components/BattleModal.jsx
import React, { useState, useEffect, useCallback, useRef, useContext } from 'react';
import './BattleModal.css';
import { ActivityLogContext } from '../contexts/ActivityLogContext';

const BACKEND_BASE_URL = "http://localhost:7777";

const BattleModal = ({ isOpen, onClose, monster, party, onBattleEnd }) => {
    if (!isOpen) return null;

    const { addActivity } = useContext(ActivityLogContext);

    const monsterQuantity = monster.quantity || 1;
    const baseMonsterHp = monster.hp;
    const baseMonsterAttack = monster.attack;
    const baseMonsterDefense = monster.defense;

    const [currentPartyHps, setCurrentPartyHps] = useState(() => {
        const initialHps = {};
        party.forEach(hero => {
            initialHps[hero.id] = hero.currentHp;
        });
        return initialHps;
    });
    const [currentMonsterHp, setCurrentMonsterHp] = useState(baseMonsterHp * monsterQuantity);
    const [numMonstersRemaining, setNumMonstersRemaining] = useState(monsterQuantity);

    const [battleLog, setBattleLog] = useState([]);
    const [isBattleOver, setIsBattleOver] = useState(false);
    const [battleResult, setBattleResult] = useState('');

    const [attackingHeroId, setAttackingHeroId] = useState(null);
    const [hittingMonster, setHittingMonster] = useState(false);
    const [attackingMonster, setAttackingMonster] = useState(false);

    const logEndRef = useRef(null);

    useEffect(() => {
        if (logEndRef.current) {
            logEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [battleLog]);

    const performBattleRound = useCallback(() => {
        if (isBattleOver) return;

        let logEntries = [];
        let updatedPartyHps = { ...currentPartyHps };

        // 1. 영웅들이 몬스터 공격
        let totalPartyAttack = party.reduce((sum, hero) => {
            return sum + (updatedPartyHps[hero.id] > 0 ? hero.currentAttack : 0);
        }, 0);

        const monsterEffectiveDefense = baseMonsterDefense * numMonstersRemaining;
        const damageToMonster = Math.max(1, totalPartyAttack - monsterEffectiveDefense);

        const newMonsterHp = Math.max(0, currentMonsterHp - damageToMonster);

        const newNumMonstersRemaining = newMonsterHp <= 0 ? 0 : Math.max(0, Math.ceil(newMonsterHp / baseMonsterHp));
        setNumMonstersRemaining(newNumMonstersRemaining);


        logEntries.push(`영웅들이 ${monster.name}에게 ${damageToMonster} 피해를 입혔습니다. (남은 HP: ${newMonsterHp})`);
        setCurrentMonsterHp(newMonsterHp);
        setHittingMonster(true);
        setTimeout(() => setHittingMonster(false), 300);

        if (newMonsterHp <= 0) {
            setIsBattleOver(true);
            setBattleResult('win');
            addActivity("전투 승리!");
            setBattleLog(prev => [...prev, ...logEntries, `모든 ${monster.name}이(가) 쓰러졌습니다!`]);
            return;
        }

        // 2. 몬스터가 영웅 공격
        setAttackingMonster(true);
        setTimeout(() => setAttackingMonster(false), 300);

        const monsterEffectiveAttack = baseMonsterAttack * newNumMonstersRemaining;

        let aliveHeroes = party.filter(hero => updatedPartyHps[hero.id] > 0);

        if (aliveHeroes.length === 0) {
            setIsBattleOver(true);
            setBattleResult('lose');
            addActivity("전투 패배!");
            setBattleLog(prev => [...prev, ...logEntries, `모든 영웅이 쓰러졌습니다!`]);
            return;
        }

        const targetHero = aliveHeroes[Math.floor(Math.random() * aliveHeroes.length)];
        const damageToHero = Math.max(1, monsterEffectiveAttack - (targetHero.currentDefense || 0));
        const newHeroHp = Math.max(0, updatedPartyHps[targetHero.id] - damageToHero);
        updatedPartyHps[targetHero.id] = newHeroHp;
        setCurrentPartyHps(updatedPartyHps);

        setAttackingHeroId(targetHero.id);
        setTimeout(() => setAttackingHeroId(null), 300);

        logEntries.push(`${monster.name}이(가) ${targetHero.name}에게 ${damageToHero} 피해를 입혔습니다. (남은 HP: ${newHeroHp})`);

        const allHeroesDefeated = Object.values(updatedPartyHps).every(hp => hp <= 0);
        if (allHeroesDefeated) {
            setIsBattleOver(true);
            setBattleResult('lose');
            addActivity("전투 패배!");
            logEntries.push(`모든 영웅이 쓰러졌습니다!`);
        }
        setBattleLog(prev => [...prev, ...logEntries]);

    }, [currentPartyHps, currentMonsterHp, isBattleOver, monster, party, baseMonsterHp, baseMonsterAttack, baseMonsterDefense, numMonstersRemaining, addActivity]);

    useEffect(() => {
        if (!isBattleOver) {
            const roundTimer = setTimeout(() => {
                performBattleRound();
            }, 1000);

            return () => clearTimeout(roundTimer);
        }
    }, [currentPartyHps, currentMonsterHp, isBattleOver, performBattleRound]);

    const monsterHpPercent = (currentMonsterHp / (baseMonsterHp * monsterQuantity)) * 100;
    const monsterNameDisplay = monster.name;

    return (
        <div className="battle-modal-overlay">
            <div className="battle-modal-content">
                <div className="battle-entities">
                    <div className="hero-section">
                        {party.map(hero => (
                            <div key={hero.id} className={`hero-display ${attackingHeroId === hero.id ? 'hit' : ''} ${currentPartyHps[hero.id] <= 0 ? 'defeated' : ''}`}>
                                <img src={`${BACKEND_BASE_URL}${hero.illustrationUrl}`} alt={hero.name} className="hero-img" />
                                <h3>{hero.name}</h3>
                                <div className="health-bar-container">
                                    <div className="health-bar" style={{ width: `${(currentPartyHps[hero.id] / hero.currentHp) * 100}%` }}></div>
                                </div>
                                {/* ⭐ 아군 파티 공격력, 방어력, HP 수치 제거 ⭐ */}
                                {/* <p>HP: {Math.max(0, currentPartyHps[hero.id])} / {hero.currentHp}</p> */}
                                {/* <p>공격력: {hero.currentAttack}</p> */}
                                {/* <p>방어력: {hero.currentDefense}</p> */}
                            </div>
                        ))}
                    </div>

                    <div className="vs-text">VS</div>

                    <div className="enemy-section">
                        <div className="monster-display-area">
                            {Array.from({ length: numMonstersRemaining }).map((_, index) => (
                                <img
                                    key={index}
                                    src={`${BACKEND_BASE_URL}${monster.illustrationUrl}`}
                                    alt={monsterNameDisplay}
                                    className={`enemy-img ${hittingMonster ? 'hit' : ''}`}
                                    style={{
                                        transform: `translateX(${ (index - (numMonstersRemaining - 1) / 2) * 20 }px)`,
                                        zIndex: numMonstersRemaining - index
                                    }}
                                />
                            ))}
                        </div>
                        <h3>{monsterNameDisplay} ({numMonstersRemaining} / {monsterQuantity}마리)</h3>
                        <div className="health-bar-container">
                            <div className="health-bar" style={{ width: `${monsterHpPercent}%` }}></div>
                        </div>
                        <p>HP: {Math.max(0, currentMonsterHp)} / {baseMonsterHp * monsterQuantity}</p>
                        {/* 몬스터 공격력, 방어력 수치 제거 (이전 답변에서 이미 제거됨) */}
                    </div>
                </div>

                <div className="battle-log">
                    {battleLog.map((log, index) => (
                        <div key={index}>{log}</div>
                    ))}
                    <div ref={logEndRef} />
                </div>

                {isBattleOver && (
                    <div className="battle-result-message">
                        {battleResult === 'win' ? (
                            <p style={{ color: 'lightgreen', fontSize: '1.5em', fontWeight: 'bold' }}>전투 승리!</p>
                        ) : (
                            <p style={{ color: 'red', fontSize: '1.5em', fontWeight: 'bold' }}>전투 패배!</p>
                        )}
                        <button onClick={() => onBattleEnd(battleResult)} className="modal-close-button">확인</button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default BattleModal;