// src/main/java/com/example/back/frontend/src/pages/BarracksPage.jsx

import React, { useState, useEffect, useCallback, useContext, useRef, memo } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthenticationService from '../services/AuthenticationService.jsx';
import { ActivityLogContext } from '../contexts/ActivityLogContext';
import axios from 'axios';
import '../components/BarracksPage.css';
import barracksImage from '../assets/병영.jpg';

const BACKEND_BASE_URL = "http://localhost:7777";

// ⭐ 1. TrainableUnitCard 컴포넌트 분리 및 memoization 적용 ⭐
const TrainableUnitCard = memo(({ unit, quantity, handleQuantityChange, handleTrainUnit, isLoading, BACKEND_BASE_URL }) => {
    return (
        <div
            className="trainable-unit-card"
            disabled={isLoading}
        >
            <img src={`${BACKEND_BASE_URL}${unit.illustrationUrl}`} alt={unit.name} className="unit-illustration"/>
            <div className="unit-name">{unit.name}</div>
            <div className="unit-cost">
                💰{unit.goldCost} 🌳{unit.woodCost} ⚙️{unit.ironCost}
            </div>
            <div className="unit-duration">
                훈련 시간: {unit.trainingDurationSeconds}초
            </div>

            <div className="selected-unit-controls">
                <p>공격력: {unit.baseAttack}, 방어력: {unit.baseDefense}</p>
                <div className="quantity-controls">
                    <button
                        onClick={() => handleQuantityChange(unit.id, -1)}
                        disabled={isLoading || quantity <= 1}
                        className="quantity-button decrease"
                    >
                        -
                    </button>
                    <input
                        type="number"
                        min="1"
                        value={quantity}
                        onChange={(e) => handleQuantityChange(unit.id, parseInt(e.target.value) || 1, 'input')}
                        disabled={isLoading}
                        className="quantity-display-input"
                    />
                    <button
                        onClick={() => handleQuantityChange(unit.id, 1)}
                        disabled={isLoading}
                        className="quantity-button increase"
                    >
                        +
                    </button>
                </div>
                <button
                    onClick={() => handleTrainUnit(unit, quantity)}
                    disabled={isLoading}
                    className="train-button-individual"
                >
                    훈련
                </button>
            </div>
        </div>
    );
});

// ⭐ 2. TrainingQueueItem 컴포넌트 분리 및 memoization 적용 ⭐
const TrainingQueueItem = memo(({ item, formatTime, remainingSeconds, handleCancelTraining, isLoading }) => {
    return (
        <li key={item.id} className="queue-item">
            <p>{item.unitName} {item.quantity}명</p>
            <p>완료까지: {formatTime(new Date(Date.now() + remainingSeconds * 1000))}</p>
            <button
                onClick={() => handleCancelTraining(item.id)}
                disabled={isLoading}
                className="cancel-training-button"
            >
                취소
            </button>
        </li>
    );
});

// ⭐ 3. OwnedUnitCard 컴포넌트 분리 및 memoization 적용 ⭐
const OwnedUnitCard = memo(({ unit, count, BACKEND_BASE_URL }) => {
    if (!unit) return null; // 유닛 정보가 없으면 렌더링하지 않음
    return (
        <li className="owned-unit-card">
            <img
                src={`${BACKEND_BASE_URL}${unit.illustrationUrl}`}
                alt={unit.name}
                className="unit-icon"
            />
            <h4>{unit.name}</h4>
            <p>보유 수: {count}명</p>
        </li>
    );
});


const BarracksPage = () => {
    const navigate = useNavigate();
    const { addActivity } = useContext(ActivityLogContext);

    const [barracksInfo, setBarracksInfo] = useState(null);
    const [isPageLoading, setIsPageLoading] = useState(true); // ⭐ isPageLoading으로 이름 변경 및 초기 렌더링용 ⭐
    const [isActionLoading, setIsActionLoading] = useState(false); // ⭐ isActionLoading 추가: 버튼 등 개별 액션 로딩 ⭐
    const [error, setError] = useState(null);
    const [message, setMessage] = useState('');

    const [unitQuantities, setUnitQuantities] = useState({});

    const [computedRemainingUpgradeSeconds, setComputedRemainingUpgradeSeconds] = useState(0);

    const barracksContainerRef = useRef(null);
    const scrollRestorationPositionRef = useRef(null);
    const countdownIntervalRef = useRef(null); // 업그레이드 타이머 interval ID 저장용
    const fetchDebounceTimerRef = useRef(null); // fetchBarracksInfo 디바운스 타이머 ID 저장용


    const showMessage = useCallback((msg, duration = 3000) => {
        setMessage(msg);
        const timer = setTimeout(() => {
            setMessage('');
        }, duration);
        return () => clearTimeout(timer);
    }, []);

    const formatTime = useCallback((timestamp) => {
        if (!timestamp) return 'N/A';
        const now = Date.now();
        const completionTime = new Date(timestamp).getTime();
        const remainingSeconds = Math.max(0, Math.floor((completionTime - now) / 1000));

        const hours = Math.floor(remainingSeconds / 3600);
        const minutes = Math.floor((remainingSeconds % 3600) / 60);
        const seconds = remainingSeconds % 60;

        return `${hours}시간 ${minutes}분 ${seconds}초`;
    }, []);

    const fetchBarracksInfo = useCallback(async (preserveScroll = false) => {
        let currentScrollPosition = 0;
        if (preserveScroll && barracksContainerRef.current) {
            currentScrollPosition = barracksContainerRef.current.scrollTop;
        }

        setError(null);
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            setError("사용자 정보가 없습니다. 다시 로그인해주세요.");
            setIsPageLoading(false); // ⭐ 초기 로딩 상태 해제 ⭐
            navigate('/auth');
            return;
        }

        try {
            const authHeader = AuthenticationService.getAuthHeader();
            const response = await axios.get(`${BACKEND_BASE_URL}/api/barracks/${userId}`, authHeader);
            const data = response.data;

            if (preserveScroll) {
                scrollRestorationPositionRef.current = currentScrollPosition;
            } else {
                scrollRestorationPositionRef.current = null;
            }

            setBarracksInfo(data);

            if (data.upgradeCompletionTime) {
                const completionInstant = new Date(data.upgradeCompletionTime);
                const now = new Date();
                const remaining = Math.max(0, Math.floor((completionInstant.getTime() - now.getTime()) / 1000));
                setComputedRemainingUpgradeSeconds(remaining);
            } else {
                setComputedRemainingUpgradeSeconds(0);
            }

        } catch (err) {
            console.error("병영 정보를 불러오는 데 실패했습니다:", err);
            setError("병영 정보를 불러오는 데 실패했습니다.");
            showMessage("병영 정보를 불러오는 데 실패했습니다.", 5000);
            if (err.response && (err.response.status === 401 || err.response.status === 403)) {
                AuthenticationService.logout();
                navigate('/auth');
                addActivity(`[에러] 인증 오류로 로그인 페이지로 이동합니다.`);
            } else {
                addActivity(`[에러] 병영 정보 로드 실패: ${err.message}`);
            }
        } finally {
            setIsPageLoading(false); // ⭐ 초기 로딩 상태 해제 ⭐
        }
    }, [addActivity, navigate, showMessage]);

    useEffect(() => {
        fetchBarracksInfo();

        const upgradeCountdown = setInterval(() => {
            setComputedRemainingUpgradeSeconds(prev => {
                if (prev <= 1) {
                    if (countdownIntervalRef.current) {
                        clearInterval(countdownIntervalRef.current);
                        countdownIntervalRef.current = null;
                    }
                    fetchBarracksInfo(true);
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);

        countdownIntervalRef.current = upgradeCountdown;

        return () => {
            if (countdownIntervalRef.current) {
                clearInterval(countdownIntervalRef.current);
                countdownIntervalRef.current = null;
            }
        };
    }, [fetchBarracksInfo]);

    useEffect(() => {
        if (scrollRestorationPositionRef.current !== null && barracksContainerRef.current) {
            const storedScrollPosition = scrollRestorationPositionRef.current;
            scrollRestorationPositionRef.current = null;

            const timeoutId = setTimeout(() => {
                if (barracksContainerRef.current) {
                    barracksContainerRef.current.scrollTop = storedScrollPosition;
                }
            }, 300);

            return () => clearTimeout(timeoutId);
        }
    }, [barracksInfo]);


    const [trainingQueueTimers, setTrainingQueueTimers] = useState({});

    useEffect(() => {
        if (barracksInfo?.trainingQueue) {
            const newTimers = {};
            barracksInfo.trainingQueue.forEach(item => {
                if (item.completionTime) {
                    const completionInstant = new Date(item.completionTime);
                    const now = new Date();
                    const remaining = Math.max(0, Math.floor((completionInstant.getTime() - now.getTime()) / 1000));
                    newTimers[item.id] = remaining;
                } else {
                    newTimers[item.id] = 0;
                }
            });
            setTrainingQueueTimers(newTimers);

            const interval = setInterval(() => {
                setTrainingQueueTimers(prevTimers => {
                    const updatedTimers = { ...prevTimers };
                    let needsRefresh = false;
                    for (const id in updatedTimers) {
                        if (updatedTimers[id] > 0) {
                            updatedTimers[id] -= 1;
                        } else if (updatedTimers[id] === 0) {
                            needsRefresh = true;
                            delete updatedTimers[id];
                        }
                    }
                    // 여기에 디바운스 로직 추가
                    if (needsRefresh) {
                        if (fetchDebounceTimerRef.current) {
                            clearTimeout(fetchDebounceTimerRef.current);
                        }
                        fetchDebounceTimerRef.current = setTimeout(() => {
                            fetchBarracksInfo(true);
                            fetchDebounceTimerRef.current = null; // 타이머 실행 후 ID 초기화
                        }, 200); // 200ms 동안 디바운스
                    }
                    return updatedTimers;
                });
            }, 1000);

            return () => {
                clearInterval(interval);
                // 컴포넌트 정리 시 대기 중인 디바운스 타이머도 클리어
                if (fetchDebounceTimerRef.current) {
                    clearTimeout(fetchDebounceTimerRef.current);
                    fetchDebounceTimerRef.current = null;
                }
            };
        }
    }, [barracksInfo?.trainingQueue, fetchBarracksInfo]);


    const handleUpgradeBarracks = async () => {
        setIsActionLoading(true); // ⭐ 액션 로딩 시작 ⭐
        setError(null);
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            setError("사용자 정보가 없습니다. 다시 로그인해주세요.");
            setIsActionLoading(false); // ⭐ 액션 로딩 종료 ⭐
            return;
        }

        try {
            const authHeader = AuthenticationService.getAuthHeader();
            const response = await axios.post(`${BACKEND_BASE_URL}/api/barracks/${userId}/upgrade`, {}, authHeader);
            showMessage(response.data);
            addActivity(`병영 업그레이드 시작: ${response.data}`);
            fetchBarracksInfo(true);
            if (document.activeElement instanceof HTMLElement) {
                document.activeElement.blur();
            }
        } catch (err) {
            console.error("병영 업그레이드 실패:", err);
            setError(err.response?.data || "병영 업그레이드에 실패했습니다.");
            showMessage(err.response?.data || "병영 업그레이드에 실패했습니다.", 5000);
            if (err.response && (err.response.status === 401 || err.response.status === 403)) {
                AuthenticationService.logout();
                navigate('/auth');
                addActivity(`[에러] 인증 오류로 로그인 페이지로 이동합니다.`);
            }
        } finally {
            setIsActionLoading(false); // ⭐ 액션 로딩 종료 ⭐
        }
    };

    const handleTrainUnit = async (unit, quantity) => {
        if (!unit || quantity <= 0) {
            showMessage("유닛을 선택하고 수량을 입력해주세요.");
            return;
        }

        setIsActionLoading(true); // ⭐ 액션 로딩 시작 ⭐
        setError(null);
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            setError("사용자 정보가 없습니다. 다시 로그인해주세요.");
            setIsActionLoading(false); // ⭐ 액션 로딩 종료 ⭐
            return;
        }

        try {
            const authHeader = AuthenticationService.getAuthHeader();
            const response = await axios.post(`${BACKEND_BASE_URL}/api/barracks/train`, {
                userId: userId,
                unitType: unit.name,
                quantity: quantity,
            }, authHeader);
            showMessage(response.data.message);
            addActivity(`${unit.name} ${quantity}명 훈련 시작`);
            fetchBarracksInfo(true);
            if (document.activeElement instanceof HTMLElement) {
                document.activeElement.blur();
            }
        } catch (err) {
            console.error("유닛 훈련 실패:", err);
            setError(err.response?.data?.message || "유닛 훈련에 실패했습니다.");
            showMessage(err.response?.data?.message || "유닛 훈련에 실패했습니다.", 5000);
            if (err.response && (err.response.status === 401 || err.response.status === 403)) {
                AuthenticationService.logout();
                navigate('/auth');
                addActivity(`[에러] 인증 오류로 로그인 페이지로 이동합니다.`);
            }
        } finally {
            setIsActionLoading(false); // ⭐ 액션 로딩 종료 ⭐
        }
    };

    const handleCancelTraining = async (queueId) => {
        setIsActionLoading(true); // ⭐ 액션 로딩 시작 ⭐
        setError(null);
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            setError("사용자 정보가 없습니다. 다시 로그인해주세요.");
            setIsActionLoading(false); // ⭐ 액션 로딩 종료 ⭐
            return;
        }

        try {
            const authHeader = AuthenticationService.getAuthHeader();
            const response = await axios.post(`${BACKEND_BASE_URL}/api/barracks/${userId}/cancel-training/${queueId}`, {}, authHeader);
            showMessage(response.data);
            addActivity(`훈련 취소: ${queueId}`);
            fetchBarracksInfo(true);
            if (document.activeElement instanceof HTMLElement) {
                document.activeElement.blur();
            }
        } catch (err) {
            console.error("훈련 취소 실패:", err);
            setError(err.response?.data || "훈련 취소에 실패했습니다.");
            showMessage(err.response?.data || "훈련 취소에 실패했습니다.", 5000);
            if (err.response && (err.response.status === 401 || err.response.status === 403)) {
                AuthenticationService.logout();
                navigate('/auth');
                addActivity(`[에러] 인증 오류로 로그인 페이지로 이동합니다.`);
            }
        } finally {
            setIsActionLoading(false); // ⭐ 액션 로딩 종료 ⭐
        }
    };

    const handleQuantityChange = useCallback((unitId, delta, type = 'button') => {
        setUnitQuantities(prev => {
            let newQuantity;
            if (type === 'input') {
                newQuantity = Math.max(1, delta); // delta가 이미 파싱된 quantity 값
            } else {
                const currentQuantity = prev[unitId] || 1;
                newQuantity = Math.max(1, currentQuantity + delta);
            }
            return {
                ...prev,
                [unitId]: newQuantity
            };
        });
    }, []);

    // ⭐ isPageLoading 일 때만 "로딩 중..." 표시 ⭐
    if (isPageLoading) {
        return (
            <div className="barracks-page-container">
                <p>로딩 중...</p>
            </div>
        );
    }

    // ⭐ 에러 메시지는 항상 표시하되, 로딩 중에는 다른 것으로 가려지지 않도록 ⭐
    if (error && !isPageLoading) { // isPageLoading 중에는 이미 로딩중 메시지가 있으므로
        return (
            <div className="barracks-page-container">
                <p className="error-message">{error}</p>
                <button onClick={() => fetchBarracksInfo()}>다시 시도</button>
            </div>
        );
    }

    const nextUpgradeCost = barracksInfo?.nextUpgradeCost;
    const MAX_BARRACKS_LEVEL = 3;
    const canUpgrade = computedRemainingUpgradeSeconds === 0 && barracksInfo?.barracksLevel < MAX_BARRACKS_LEVEL;
    const upgradeButtonText = barracksInfo?.currentUpgradeStatus === 'UPGRADING'
        ? `업그레이드 중 (${formatTime(new Date(Date.now() + computedRemainingUpgradeSeconds * 1000))})`
        : barracksInfo?.barracksLevel >= MAX_BARRACKS_LEVEL
            ? '최고 레벨'
            : nextUpgradeCost
                ? `업그레이드 (${nextUpgradeCost.gold}골드, ${nextUpgradeCost.wood}나무, ${nextUpgradeCost.iron}철)`
                : '업그레이드';

    // 현재 보유 유닛 섹션을 위한 unitIdToNameMap 생성
    const unitIdToUnitMap = barracksInfo?.trainableUnits ? new Map(
        barracksInfo.trainableUnits.map(unit => [unit.id, unit])
    ) : new Map();


    return (
        <div className="barracks-page-container" ref={barracksContainerRef}>
            <div className={`message-overlay ${message ? 'visible' : ''}`}>{message}</div>

            <h1 className="barracks-title">병영</h1>

            <div className="barracks-header">
                <img src={barracksImage} alt="병영" className="barracks-image" />
                <div className="barracks-info">
                    <p>레벨: {barracksInfo?.barracksLevel}</p>
                    <p>
                        업그레이드 상태: {
                        barracksInfo?.currentUpgradeStatus === 'UPGRADING'
                            ? `업그레이드 중 - ${formatTime(new Date(Date.now() + computedRemainingUpgradeSeconds * 1000))}`
                            : '완료'
                    }
                    </p>
                    <button
                        className="upgrade-button"
                        onClick={handleUpgradeBarracks}
                        disabled={!canUpgrade || isActionLoading}
                    >
                        {upgradeButtonText}
                    </button>
                </div>
            </div>

            <div className="barracks-sections">
                <div className="section training-section">
                    <h2>유닛 훈련</h2>
                    <div className="trainable-units-grid">
                        {barracksInfo.trainableUnits.map(unit => (
                            <TrainableUnitCard
                                key={unit.id}
                                unit={unit}
                                quantity={unitQuantities[unit.id] || 1}
                                handleQuantityChange={handleQuantityChange}
                                handleTrainUnit={handleTrainUnit}
                                isLoading={isActionLoading}
                                BACKEND_BASE_URL={BACKEND_BASE_URL}
                            />
                        ))}
                    </div>

                </div>

                <div className="section training-queue-section">
                    <h2>훈련 대기열</h2>
                    {barracksInfo?.trainingQueue && barracksInfo.trainingQueue.length > 0 ? (
                        <ul className="queue-list">
                            {barracksInfo.trainingQueue.map(item => (
                                <TrainingQueueItem
                                    key={item.id}
                                    item={item}
                                    formatTime={formatTime}
                                    remainingSeconds={trainingQueueTimers[item.id] || 0}
                                    handleCancelTraining={handleCancelTraining}
                                    isLoading={isActionLoading}
                                />
                            ))}
                        </ul>
                    ) : (
                        <p>현재 훈련 중인 유닛이 없습니다.</p>
                    )}
                </div>

                <div className="section current-units-section">
                    <h2>현재 보유 유닛</h2>
                    {barracksInfo?.currentTroops && Object.keys(barracksInfo.currentTroops).length > 0 ? (
                        <ul className="unit-list">
                            {Object.entries(barracksInfo.currentTroops).map(([unitId, count]) => (
                                <OwnedUnitCard
                                    key={unitId}
                                    unit={unitIdToUnitMap.get(parseInt(unitId))}
                                    count={count}
                                    BACKEND_BASE_URL={BACKEND_BASE_URL}
                                />
                            ))}
                        </ul>
                    ) : (
                        <p>현재 보유 유닛이 없습니다.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default BarracksPage;