// src/components/AuthPage.js
import React, { useState, useEffect } from 'react';
import AuthService from '../services/AuthenticationService.jsx';
import { useNavigate } from 'react-router-dom';
import backgroundImage from '../assets/main.jpg'; // 배경 이미지 임포트

// ⭐ onAuthChange prop을 받도록 함수 서명 변경
function AuthPage({ onAuthChange }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    // 이 상태가 true면 회원가입 폼을, false면 로그인 폼을 보여줍니다.
    const [showRegister, setShowRegister] = useState(false);
    const navigate = useNavigate();

    // ⭐ 페이지 로드 시 현재 사용자 ID를 확인하여 이미 로그인된 경우 리다이렉트
    useEffect(() => {
        if (AuthService.getCurrentUserId()) {
            navigate('/village');
        }
    }, [navigate]);


    // 회원가입 처리 함수
    const handleRegister = async (e) => {
        e.preventDefault();
        setMessage('');

        if (!username || !password) {
            setMessage('사용자 이름과 비밀번호를 모두 입력해주세요.');
            return;
        }

        try {
            const result = await AuthService.register(username, password);
            setMessage(result);
            setUsername('');
            setPassword('');
            // 회원가입 성공 후 다시 로그인 폼으로 전환
            setShowRegister(false);
        } catch (error) {
            setMessage(typeof error === 'string' ? error : '회원가입 실패: 알 수 없는 오류가 발생했습니다.');
        }
    };

    // 로그인 처리 함수
    const handleLogin = async (e) => {
        e.preventDefault();
        setMessage('');

        if (!username || !password) {
            setMessage('사용자 이름과 비밀번호를 모두 입력해주세요.');
            return;
        }

        try {
            const result = await AuthService.login(username, password);
            setMessage(result.message);

            // ⭐ userId가 존재하면 로그인 성공으로 간주하고 onAuthChange 호출
            if (result.userId) {
                onAuthChange(true); // App.jsx의 isAuthenticated 상태를 true로 업데이트
                navigate('/village'); // 영지 페이지로 이동
            }
        } catch (error) {
            // ⭐ 에러 메시지가 객체 형태로 올 수 있으므로, .message 속성 접근
            setMessage(error.message || '로그인 실패: 사용자 이름 또는 비밀번호가 올바르지 않습니다.');
        }
    };

    return (
        <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '100vh',
            width: '100vw',
            backgroundImage: `url(${backgroundImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            backgroundColor: '#282c34',
            color: 'white',
            fontFamily: 'Arial, sans-serif',
            overflow: 'hidden'
        }}>
            {/* 게임 타이틀 */}
            <h1 style={{
                marginBottom: '40px',
                fontSize: '3.5em', /* 글자 크기를 더 키워 강렬함 강조 */
                fontWeight: 'bold', /* 글자를 더 두껍게 */
                color: '#333', /* 어두운 회색 (베르세르크의 험난한 분위기에 맞게) */
                textShadow: '3px 3px 6px rgba(0,0,0,0.9), -3px -3px 6px rgba(0,0,0,0.9)', /* 더 진하고 넓은 그림자 */
                textAlign: 'center',
                fontFamily: '"Times New Roman", Times, serif', /* 장엄하고 고풍스러운 느낌의 세리프 폰트 */
                letterSpacing: '2px', /* 글자 간격 조정으로 무게감 추가 */
                borderBottom: '2px solid #555', /* 험준한 느낌을 주는 하단 테두리 */
                paddingBottom: '10px' /* 테두리와 글자 사이 간격 */
            }}>
                B E R S E R K
            </h1>

            {/* 인증 폼 컨테이너 */}
            <div style={{
                backgroundColor: 'rgba(0, 0, 0, 0.6)', // 반투명 검은색 배경
                padding: '40px',
                borderRadius: '10px',
                boxShadow: '0 8px 16px rgba(0, 0, 0, 0.5)',
                zIndex: 1,
                width: '350px', // 폼 컨테이너의 너비를 고정
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center'
            }}>
                {/* showRegister 상태에 따라 로그인 폼 또는 회원가입 폼을 렌더링 */}
                {showRegister ? (
                    // --- 회원가입 폼 섹션 ---
                    <>
                        <h2 style={{ marginBottom: '20px' }}>회원가입</h2>
                        <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: '15px', width: '100%' }}>
                            <input
                                type="text"
                                placeholder="사용자 이름"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                style={{ padding: '10px', borderRadius: '4px', border: 'none', backgroundColor: '#e0e0e0', color: '#333' }}
                            />
                            <input
                                type="password"
                                placeholder="비밀번호"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                style={{ padding: '10px', borderRadius: '4px', border: 'none', backgroundColor: '#e0e0e0', color: '#333' }}
                            />
                            <button type="submit" style={{
                                padding: '10px 20px',
                                backgroundColor: '#61dafb', // 회원가입 버튼 색상
                                color: 'white',
                                border: 'none',
                                borderRadius: '4px',
                                cursor: 'pointer',
                                fontSize: '16px',
                                transition: 'background-color 0.3s ease'
                            }}>회원가입</button>
                        </form>
                        <p style={{ marginTop: '20px' }}>
                            이미 계정이 있으신가요?
                            <span
                                onClick={() => setShowRegister(false)} // 로그인 폼으로 전환
                                style={{ color: '#21a1f1', cursor: 'pointer', marginLeft: '5px', textDecoration: 'underline' }}
                            >
                                로그인
                            </span>
                        </p>
                    </>
                ) : (
                    // --- 로그인 폼 섹션 ---
                    <>
                        <h2 style={{ marginBottom: '20px' }}>로그인</h2>
                        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '15px', width: '100%' }}>
                            <input
                                type="text"
                                placeholder="사용자 이름"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                                style={{ padding: '10px', borderRadius: '4px', border: 'none', backgroundColor: '#e0e0e0', color: '#333' }}
                            />
                            <input
                                type="password"
                                placeholder="비밀번호"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                style={{ padding: '10px', borderRadius: '4px', border: 'none', backgroundColor: '#e0e0e0', color: '#333' }}
                            />
                            <button type="submit" style={{
                                padding: '10px 20px',
                                backgroundColor: '#21a1f1', // 로그인 버튼 색상
                                color: 'white',
                                border: 'none',
                                borderRadius: '4px',
                                cursor: 'pointer',
                                fontSize: '16px',
                                transition: 'background-color 0.3s ease'
                            }}>로그인</button>
                        </form>
                        <p style={{ marginTop: '20px' }}>
                            계정이 없으신가요?
                            <span
                                onClick={() => setShowRegister(true)} // 회원가입 폼으로 전환
                                style={{ color: '#61dafb', cursor: 'pointer', marginLeft: '5px', textDecoration: 'underline' }}
                            >
                                회원가입
                            </span>
                        </p>
                    </>
                )}

                {/* 메시지 표시 영역 */}
                {message && (
                    <p style={{
                        marginTop: '20px',
                        padding: '10px 20px',
                        backgroundColor: message.includes('성공') ? 'rgba(76, 175, 80, 0.9)' : 'rgba(244, 67, 54, 0.9)',
                        color: 'white',
                        borderRadius: '5px',
                        textAlign: 'center',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.3)'
                    }}>
                        {message}
                    </p>
                )}
            </div>
        </div>
    );
}

export default AuthPage;