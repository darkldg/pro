// src/pages/InnPage.jsx

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthenticationService from '../services/AuthenticationService';
import axios from 'axios';
import '../components/InnPage.css';
import innImage from '../assets/1.jpg'; // 여관 배경 이미지

const BACKEND_BASE_URL = "http://localhost:7777";
const MAGIC_POWDER_COST_FOR_DRAW = 100; // 영웅 뽑기에 필요한 마법 가루

// ⭐ getRarityClass 헬퍼 함수 추가 ⭐
const getRarityClass = (rarity) => {
    switch (rarity) {
        case 'NORMAL':
            return 'rarity-normal';
        case 'RARE':
            return 'rarity-rare';
        case 'UNIQUE':
            return 'rarity-unique';
        case 'EPIC': // EPIC 희귀도가 있다면
            return 'rarity-epic';
        case 'LEGENDARY': // LEGENDARY 희귀도가 있다면
            return 'rarity-legendary';
        default:
            return ''; // 기본 클래스
    }
};

const InnPage = () => {
    const navigate = useNavigate();

    const [currentParty, setCurrentParty] = useState(Array(4).fill(null));
    const [selectedUnit, setSelectedUnit] = useState(null);
    const [userInfo, setUserInfo] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [message, setMessage] = useState('');

    const [allOwnedUnitsAndHeroes, setAllOwnedUnitsAndHeroes] = useState([]);
    const [heroCandidates, setHeroCandidates] = useState([]); // 영웅 후보 목록 (4명)
    const [recentlyHiredHero, setRecentlyHiredHero] = useState(null);

    const [shouldFetchCandidates, setShouldFetchCandidates] = useState(true);

    const fetchUserInfo = useCallback(async () => {
        setIsLoading(true); // 사용자 정보 로딩 시작 시 로딩 상태 설정
        try {
            const userId = AuthenticationService.getCurrentUserId();
            if (!userId) {
                navigate('/login');
                return;
            }
            // 이 부분을 수정했습니다: /api/user-info/ -> /api/users/
            const response = await axios.get(`${BACKEND_BASE_URL}/api/users/${userId}`);
            setUserInfo(response.data);
        } catch (err) {
            console.error("사용자 정보 로딩 실패:", err);
            setError("사용자 정보를 불러오는데 실패했습니다.");
            if (err.response && err.response.status === 401) {
                AuthenticationService.logout();
                navigate('/login');
            }
        } finally {
            setIsLoading(false);
        }
    }, [navigate]);

    const fetchHeroCandidates = useCallback(async () => {
        setIsLoading(true);
        try {
            const response = await axios.get(`${BACKEND_BASE_URL}/api/inn/available-heroes`);
            setHeroCandidates(response.data);
            setMessage("새로운 영웅 후보 4명을 불러왔습니다!");
        } catch (error) {
            console.error("영웅 후보 불러오기 실패:", error);
            setMessage("영웅 후보를 불러오는데 실패했습니다.");
        } finally {
            setIsLoading(false);
        }
    }, []);

    const fetchOwnedUnitsAndHeroes = useCallback(async () => {
        setIsLoading(true);
        try {
            const userId = AuthenticationService.getCurrentUserId();
            if (!userId) {
                navigate('/login');
                return;
            }
            const response = await axios.get(`${BACKEND_BASE_URL}/api/inn/owned-units-heroes/${userId}`);
            setAllOwnedUnitsAndHeroes(response.data);

            // ⭐ 추가: 불러온 유닛/영웅 중 isEquipped가 true인 영웅들로 currentParty 상태 업데이트 ⭐
            const equippedHeroes = response.data
                .filter(unit => unit.isEquipped && unit.unitType === 'HERO') // isHero 대신 unitType 확인
                .sort((a, b) => a.slotIndex - b.slotIndex); // slotIndex 기준으로 정렬

            const newCurrentParty = Array(4).fill(null);
            equippedHeroes.forEach(hero => {
                if (hero.slotIndex !== null && hero.slotIndex >= 0 && hero.slotIndex < 4) {
                    newCurrentParty[hero.slotIndex] = hero;
                }
            });
            setCurrentParty(newCurrentParty);

        } catch (error) {
            console.error("보유 유닛/영웅 목록 불러오기 실패:", error);
            setError("보유 유닛/영웅 목록을 불러오는데 실패했습니다.");
        } finally {
            setIsLoading(false);
        }
    }, [navigate]);

    // 모든 초기 데이터를 한 번에 불러오는 useEffect
    useEffect(() => {
        const loadAllData = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const userId = AuthenticationService.getCurrentUserId();
                if (!userId) {
                    navigate('/login');
                    return;
                }

                await Promise.all([
                    fetchUserInfo(), // 사용자 정보
                    fetchOwnedUnitsAndHeroes(), // 보유 유닛/영웅 (여기서 currentParty도 초기화)
                    shouldFetchCandidates ? fetchHeroCandidates() : Promise.resolve() // 영웅 후보 (필요시)
                ]);
            } catch (err) {
                console.error("초기 데이터 로딩 중 오류:", err);
                setError("페이지 정보를 불러오는 데 실패했습니다.");
            } finally {
                setIsLoading(false);
            }
        };
        loadAllData();
    }, [navigate, shouldFetchCandidates, fetchUserInfo, fetchOwnedUnitsAndHeroes, fetchHeroCandidates]); // 의존성 배열에 모든 useCallback 함수 포함

    // ⭐ handleUnitClick 함수 수정: 클릭 시 바로 파티에 추가 시도 ⭐
    const handleUnitClick = (unit) => {
        // 선택된 유닛 상세 보기 대신, 바로 파티에 추가 시도
        // 현재 파티에서 비어있는 첫 번째 슬롯을 찾아 유닛을 추가합니다.
        const emptySlotIndex = currentParty.findIndex(slot => slot === null);
        if (emptySlotIndex !== -1) {
            handlePartySlotClick(emptySlotIndex, unit);
        } else {
            setMessage('파티 슬롯이 모두 채워져 있습니다. 기존 유닛을 제거하고 추가해주세요.');
        }
    };

    const handlePartySlotClick = (index, unit = null) => {
        const newParty = [...currentParty];
        if (unit) {
            const unitExistsInParty = newParty.some(item => item && item.id === unit.id);
            if (!unitExistsInParty) {
                newParty[index] = unit;
                setMessage(`${unit.name}이(가) 파티에 추가되었습니다.`);
            } else {
                setMessage('이미 파티에 있는 유닛입니다.');
            }
        } else {
            // 슬롯 클릭 시 해당 슬롯의 유닛 제거
            const removedUnitName = newParty[index] ? newParty[index].name : '';
            newParty[index] = null;
            if (removedUnitName) {
                setMessage(`${removedUnitName}이(가) 파티에서 제거되었습니다.`);
            }
        }
        setCurrentParty(newParty);
    };


    const handleSaveParty = async () => {
        if (!userInfo) return;

        // ⭐ 변경: playerOwnedHeroId 대신 UnitResponseDto의 id 필드를 사용합니다. ⭐
        const partyUnitIds = currentParty
            .filter(unit => unit !== null && unit.unitType === 'HERO') // null이 아니고 Hero 타입인 유닛만 필터링
            .map(unit => {
                // unit.id가 PlayerOwnedHero의 ID를 나타냅니다.
                if (unit.id !== undefined && unit.id !== null) {
                    return unit.id.toString();
                } else {
                    console.error("Warning: Hero unit in party does not have a valid ID:", unit);
                    return null;
                }
            })
            .filter(id => id !== null); // null이 아닌 유효한 ID만 최종적으로 포함

        if (partyUnitIds.length === 0 && currentParty.some(u => u !== null)) {
            setMessage("파티에 유효한 영웅이 없습니다. 다시 확인해주세요.");
            return;
        }

        try {
            const userId = AuthenticationService.getCurrentUserId();
            const response = await axios.post(`${BACKEND_BASE_URL}/api/inn/save-party/${userId}`, partyUnitIds, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            setMessage(response.data);
            console.log("파티 저장 성공:", response.data);
            // ⭐ 파티 저장 후, 파티 정보를 다시 불러와서 UI 업데이트 ⭐
            await fetchOwnedUnitsAndHeroes();
        } catch (error) {
            console.error("파티 저장 실패:", error);
            setMessage(error.response?.data?.message || "파티 저장에 실패했습니다.");
        }
    };

    const handleHireSelectedHero = async (heroToHire) => {
        if (!userInfo || userInfo.magicPowder === undefined || userInfo.magicPowder < MAGIC_POWDER_COST_FOR_DRAW) {
            setMessage('마법 가루가 부족합니다!');
            return;
        }

        try {
            const userId = AuthenticationService.getCurrentUserId(); // userId는 프론트에서 얻어서 전송

            const response = await axios.post(
                // ⭐ 변경된 URL: userId를 경로 변수로 다시 포함 ⭐
                `${BACKEND_BASE_URL}/api/inn/draw-hero/${userId}`,
                // ⭐ 요청 본문: heroId와 cost를 함께 전송 (새 DTO 없이 Map 형태로 백엔드로 전달) ⭐
                { heroId: heroToHire.id, cost: MAGIC_POWDER_COST_FOR_DRAW },
                {
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );
            setRecentlyHiredHero(response.data);
            setMessage(`${response.data.name}을(를) ${MAGIC_POWDER_COST_FOR_DRAW} 마법 가루를 사용하여 고용했습니다!`);
            setUserInfo(prev => ({ ...prev, magicPowder: prev.magicPowder - MAGIC_POWDER_COST_FOR_DRAW }));

            setHeroCandidates([]); // 기존 후보 초기화
            fetchOwnedUnitsAndHeroes(); // 보유 영웅 목록 갱신
            fetchHeroCandidates(); // 새로운 영웅 후보를 즉시 다시 불러옵니다.

        } catch (error) {
            console.error("영웅 고용 실패:", error);
            setMessage(error.response?.data?.message || "영웅 고용에 실패했습니다.");
        }
    };


    if (isLoading) {
        return <div className="inn-container">로딩 중...</div>;
    }

    if (error) {
        return <div className="inn-container error-message">{error}</div>;
    }

    return (
        <div className="inn-container" style={{ backgroundImage: `url(${innImage})` }}>
            <header className="inn-header">
                <h1>영웅 여관</h1>
                <div className="user-resources">
                    <span>골드: {userInfo.gold}</span>
                    <span>식량: {userInfo.food}</span>
                    <span>나무: {userInfo.wood}</span>
                    <span>철: {userInfo.iron}</span>
                    <span>마법 가루: {userInfo.magicPowder !== undefined ? userInfo.magicPowder : '로딩 중...'}</span>
                    <span>영지 레벨: {userInfo.territoryLevel}</span>
                </div>
                {message && <div className="message-overlay">{message}</div>}
            </header>

            <main className="inn-content">
                <section className="hero-recruitment-section card">
                    <h2>영웅 모집</h2>
                    <div className="hero-candidates">
                        {heroCandidates.length > 0 ? (
                            heroCandidates.map(hero => (
                                <div key={`hero-${hero.id}`} className={`hero-card ${getRarityClass(hero.unitRarity)}`}>
                                    <img src={`${BACKEND_BASE_URL}${hero.illustrationUrl}`} alt={hero.name} className="hero-illustration" />
                                    <h3>{hero.name}</h3>

                                    <p>희귀도: {hero.unitRarity}</p>
                                    <p>공격력: {hero.currentAttack}</p>
                                    <p>방어력: {hero.currentDefense}</p>
                                    <button
                                        onClick={() => handleHireSelectedHero(hero)}
                                        className="btn hire-hero-button"
                                        disabled={!userInfo || userInfo.magicPowder === undefined || userInfo.magicPowder < MAGIC_POWDER_COST_FOR_DRAW}
                                    >
                                        고용
                                    </button>
                                </div>
                            ))
                        ) : (
                            <p>새로운 영웅 후보가 없습니다. '영웅 불러오기' 버튼을 눌러주세요.</p>
                        )}
                    </div>
                    <button
                        onClick={fetchHeroCandidates}
                        className="btn save-party-button"
                        disabled={isLoading}
                    >
                        영웅 불러오기 (무료)
                    </button>
                    {/*{recentlyHiredHero && (*/}
                    {/* <div className="recently-hired-info">*/}
                    {/* <h3>최근 고용 영웅: {recentlyHiredHero.name}</h3>*/}
                    {/* <p>레벨: {recentlyHiredHero.level}</p>*/}
                    {/* <p>공격력: {recentlyHiredHero.stats?.attack}</p>*/}
                    {/* <p>방어력: {recentlyHiredHero.stats?.defense}</p>*/}
                    {/* </div>*/}
                    {/*)}*/}
                </section>

                <section className="party-management-section card">
                    <h2>파티 관리</h2>
                    <div className="current-party-slots">
                        {currentParty.map((unit, index) => (
                            <div
                                key={index}
                                className={`party-slot ${unit ? getRarityClass(unit.unitRarity) : ''}`}
                                onClick={() => handlePartySlotClick(index)}
                            >
                                {unit ? (
                                    <>
                                        <img src={`${BACKEND_BASE_URL}${unit.illustrationUrl}`} alt={unit.name} className="party-unit-thumbnail" />
                                        <span>{unit.name}</span>
                                    </>
                                ) : (
                                    <span>비어있음</span>
                                )}
                            </div>
                        ))}
                    </div>
                    <button onClick={handleSaveParty} className="btn save-party-button">파티 저장</button>
                </section>

                <section className="owned-units-section card">
                    <h2>보유 유닛 및 영웅</h2>

                    <div className="owned-units-list">
                        {allOwnedUnitsAndHeroes.length > 0 ? (
                            allOwnedUnitsAndHeroes.map(unit => (
                                <div
                                    key={`unit-${unit.id}`}
                                    className={`owned-unit-card ${getRarityClass(unit.unitRarity)}`}
                                    onClick={() => handleUnitClick(unit)}
                                >
                                    <img src={`${BACKEND_BASE_URL}${unit.illustrationUrl}`} alt={unit.name} className="unit-illustration" />
                                    <div className="unit-info">
                                        <h3>{unit.name}</h3>
                                        <p>체력: {unit.currentHp || 'N/A'}</p>
                                        <p>공격력: {unit.currentAttack || 'N/A'}</p>
                                        <p>방어력: {unit.currentDefense || 'N/A'}</p>
                                        {/* 영웅일 경우 레벨도 표시 */}
                                        {unit.unitType === 'HERO' && <p>레벨: {unit.level}</p>}
                                        {/* 필요하다면 희귀도는 계속 표시할 수도 있습니다 (주석 해제) */}
                                        <p>희귀도: {unit.unitRarity || 'N/A'}</p>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <p className="no-units-message">보유한 유닛이나 영웅이 없습니다. 영웅을 뽑아보세요!</p>
                        )}
                    </div>
                </section>

            </main>
        </div>
    );
};

export default InnPage;