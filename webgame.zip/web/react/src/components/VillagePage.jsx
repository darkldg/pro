// src/pages/VillagePage.jsx

import React, { useState, useEffect, useCallback, useRef, useContext } from 'react';
import { useNavigate, useLocation, Routes, Route, Outlet } from 'react-router-dom';
import AuthenticationService from '../services/AuthenticationService.jsx';
import { ActivityLogContext } from '../contexts/ActivityLogContext';
import axios from 'axios';
import '../components/VillagePage.css';
import villageImage from '../assets/영지.jpg';

// ⭐ 하위 페이지 컴포넌트 임포트 ⭐
import BarracksPage from '../components/BarracksPage';
import InnPage from '../components/InnPage';
import MapPage from '../components/MapPage';

const BACKEND_BASE_URL = "http://localhost:7777";

// VillageContent 컴포넌트는 이제 순수하게 영지 메인 화면의 콘텐츠만 담당합니다.
// top-bar와 activity-log는 VillagePage로 이동합니다.
const VillageContent = ({
                            territoryLevel, handleUpgradeBuilding, currentUpgradeStatus,
                            computedRemainingUpgradeSeconds, upgradeButtonText,
                            formatDuration
                        }) => {
    return (
        <div className="territory-main-content">
            <div className="territory-display">
                <img src={villageImage} alt="내 영지" className="territory-castle" />
                <div className="territory-info">
                    <h2>내 영지 (레벨 <span id="territory-level">{territoryLevel}</span>)</h2>
                    <p>작은 마을이지만, 잠재력은 무한합니다.</p>
                    <button
                        onClick={() => handleUpgradeBuilding(1, "본부")}
                        className="upgrade-button"
                        disabled={currentUpgradeStatus.includes("진행 중") || (territoryLevel >= 3)}
                    >
                        {upgradeButtonText()}
                    </button>
                    {/* ⭐ 알림 위치 변경된 부분 ⭐ */}
                    <div className="alert-section" style={{ marginTop: '10px' }}>
                        <span>알림: {currentUpgradeStatus.includes("진행 중") ? `영지 업그레이드 진행 중 (남은 시간: ${formatDuration(computedRemainingUpgradeSeconds)})` : currentUpgradeStatus}</span>
                    </div>
                </div>
            </div>
        </div>
    );
};


const VillagePage = ({ onAuthChange }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const { activityLogs, addActivity } = useContext(ActivityLogContext);

    const [message, setMessage] = useState('');

    // ⭐ territoryLevel 초기값은 0 또는 1로 설정, 백엔드에서 실제 값 로드 ⭐
    const [territoryLevel, setTerritoryLevel] = useState(1);
    const [gold, setGold] = useState(0);
    const [food, setFood] = useState(0);
    const [wood, setWood] = useState(0);
    const [iron, setIron] = useState(0);
    const [magicPowder, setMagicPowder] = useState(0);
    const [totalTroops, setTotalTroops] = useState(0);
    const [heroesCount, setHeroesCount] = useState(3);

    const [buildings, setBuildings] = useState([
        { id: 1, name: "본부", level: 1, description: "영지의 중심입니다. 영지 레벨을 결정합니다.", type: "HEADQUARTERS", canUpgrade: true, upgradeCost: { gold: 100, wood: 50, iron: 0 }, upgradeTimeSeconds: 5 },
    ]);

    const [nextUpgradeCost, setNextUpgradeCost] = useState({
        gold: 0, food: 0, wood: 0, iron: 0, magicPowder: 0, duration: 0
    });
    const [currentUpgradeStatus, setCurrentUpgradeStatus] = useState("업그레이드 가능");
    const [upgradeCompletionTimestamp, setUpgradeCompletionTimestamp] = useState(null);
    const [computedRemainingUpgradeSeconds, setComputedRemainingUpgradeSeconds] = useState(0);

    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const countdownIntervalRef = useRef(null);
    const autoResourceCollectTimerRef = useRef(null);

    const showMessage = useCallback((msg, duration = 3000) => {
        setMessage(msg);
        const timer = setTimeout(() => {
            setMessage('');
        }, duration);
        return () => clearTimeout(timer);
    }, []);

    const formatTime = useCallback((timestamp) => {
        if (!timestamp) return '';
        const date = new Date(timestamp);
        return date.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }, []);

    const formatDuration = (seconds) => {
        if (seconds <= 0) return "0초";
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        if (minutes > 0) {
            return `${minutes}분 ${remainingSeconds}초`;
        }
        return `${remainingSeconds}초`;
    };

    // ⭐ 자원 및 영지 레벨을 백엔드에 저장하는 함수 ⭐
    const saveResourcesToBackend = useCallback(async (currentGold, currentFood, currentWood, currentIron, currentMagicPowder, currentTerritoryLevel) => {
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            console.warn("User ID not found, cannot save resources.");
            return;
        }

        try {
            await axios.put(`${BACKEND_BASE_URL}/api/users/${userId}/resources`, {
                gold: currentGold,
                food: currentFood,
                wood: currentWood,
                iron: currentIron,
                magicPowder: currentMagicPowder,
                territoryLevel: currentTerritoryLevel // ⭐ 영지 레벨도 함께 전달 ⭐
            });
            console.log("Resources and Territory Level saved to backend successfully.");
        } catch (err) {
            console.error("Error saving resources and territory level to backend:", err);
            showMessage("자원 및 영지 레벨 저장에 실패했습니다.");
        }
    }, [showMessage]);


    const collectAutoResourcesFromBackend = useCallback(async () => {
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            console.warn("User ID not found, cannot auto-collect resources.");
            return;
        }

        try {
            const response = await axios.post(`${BACKEND_BASE_URL}/api/users/${userId}/collect-auto-resources`);
            const updatedUserData = response.data;

            setGold(updatedUserData.gold);
            setFood(updatedUserData.food);
            setWood(updatedUserData.wood);
            setIron(updatedUserData.iron);
            setMagicPowder(updatedUserData.magicPowder);
            setTerritoryLevel(updatedUserData.territoryLevel); // ⭐ 자동 수집 시 영지 레벨도 업데이트 (백엔드에서 현재 레벨 사용) ⭐

            addActivity(`자원 자동 채집 완료. (골드: ${updatedUserData.gold}, 식량: ${updatedUserData.food}, 목재: ${updatedUserData.wood}, 철광: ${updatedUserData.iron}, 신비한 가루: ${updatedUserData.magicPowder})`,'resource');
            console.log("Auto-collected resources:", updatedUserData);
        } catch (err) {
            console.error("Error auto-collecting resources from backend:", err);
            showMessage("자동 자원 수집에 실패했습니다.");
        }
    }, [addActivity, showMessage]);


    const fetchInitialVillageData = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const userId = AuthenticationService.getCurrentUserId();
            if (!userId) {
                showMessage("유저 ID를 찾을 수 없습니다. 로그인 페이지로 이동합니다.");
                navigate('/auth');
                onAuthChange(false);
                return;
            }

            const userInfoResponse = await axios.get(`${BACKEND_BASE_URL}/api/users/${userId}`);
            const userData = userInfoResponse.data;

            setGold(userData.gold);
            setFood(userData.food);
            setWood(userData.wood);
            setIron(userData.iron);
            setMagicPowder(userData.magicPowder);
            setTerritoryLevel(userData.territoryLevel); // ⭐ 백엔드에서 영지 레벨 가져오기 ⭐

            setTotalTroops(100); // 임시값, 실제 병력 데이터 가져와야 함
            setHeroesCount(3); // 임시값, 실제 영웅 데이터 가져와야 함

            const headquarters = buildings.find(b => b.type === "HEADQUARTERS");
            if (headquarters) {
                // 백엔드에서 가져온 레벨을 기반으로 다음 업그레이드 비용 계산
                const currentLevel = userData.territoryLevel;
                const nextGoldCost = 100 * Math.pow(1.5, currentLevel - 1);
                const nextWoodCost = 50 * Math.pow(1.5, currentLevel - 1);

                setNextUpgradeCost({
                    gold: Math.floor(nextGoldCost),
                    wood: Math.floor(nextWoodCost),
                    iron: Math.floor(nextGoldCost * 0.5), // 철광도 비율에 따라 증가하도록 조정
                    magicPowder: 0,
                    duration: headquarters.upgradeTimeSeconds * Math.pow(2, currentLevel - 1)
                });
                // 최고 레벨 도달 여부도 초기화 시 확인
                if (currentLevel >= 3) { // 가정: 최대 3레벨
                    setCurrentUpgradeStatus("최고 레벨입니다.");
                } else {
                    setCurrentUpgradeStatus("업그레이드 가능");
                }
            }
            addActivity("영지 초기 데이터를 불러왔습니다.");

        } catch (err) {
            console.error("영지 데이터 로딩 중 오류 발생:", err);
            setError("영지 데이터를 불러오는 데 실패했습니다: " + (err.response?.data?.message || err.message));
            showMessage("영지 데이터를 불러오는 데 실패했습니다.");
            addActivity("영지 데이터 로딩 실패.");
            onAuthChange(false);
        } finally {
            setIsLoading(false);
        }
    }, [navigate, addActivity, showMessage, buildings, onAuthChange]);

    useEffect(() => {
        fetchInitialVillageData();
    }, [fetchInitialVillageData]);

    useEffect(() => {
        autoResourceCollectTimerRef.current = setInterval(() => {
            collectAutoResourcesFromBackend();
        }, 10000);

        return () => {
            if (autoResourceCollectTimerRef.current) {
                clearInterval(autoResourceCollectTimerRef.current);
            }
        };
    }, [collectAutoResourcesFromBackend]);


    useEffect(() => {
        if (countdownIntervalRef.current) {
            clearInterval(countdownIntervalRef.current);
            countdownIntervalRef.current = null;
        }

        if (upgradeCompletionTimestamp && currentUpgradeStatus === "업그레이드 중") {
            const interval = setInterval(() => {
                const now = Date.now();
                const remaining = Math.max(0, Math.floor((upgradeCompletionTimestamp - now) / 1000));
                setComputedRemainingUpgradeSeconds(remaining);

                if (remaining <= 0) {
                    clearInterval(interval);
                    countdownIntervalRef.current = null;
                    const newTerritoryLevel = territoryLevel + 1; // 업그레이드 완료 후 새 레벨
                    setCurrentUpgradeStatus("업그레이드 완료!");
                    showMessage("본부 업그레이드가 완료되었습니다!");
                    addActivity("본부 업그레이드 완료!", 'upgrade');

                    setBuildings(prevBuildings => prevBuildings.map(b =>
                        b.id === 1 ? { ...b, level: newTerritoryLevel } : b // 건물 레벨 업데이트
                    ));
                    setTerritoryLevel(newTerritoryLevel); // ⭐ 영지 레벨 상태 업데이트 ⭐

                    // ⭐ 업그레이드 완료 후 자원 및 새 영지 레벨을 백엔드에 저장 ⭐
                    saveResourcesToBackend(gold, food, wood, iron, magicPowder, newTerritoryLevel);

                    // 다음 업그레이드 비용 및 시간 계산 (새로운 레벨 기준)
                    if (newTerritoryLevel < 3) { // 가정: 최대 3레벨
                        const nextGoldCost = 100 * Math.pow(1.5, newTerritoryLevel - 1);
                        const nextWoodCost = 50 * Math.pow(1.5, newTerritoryLevel - 1);

                        setNextUpgradeCost({
                            gold: Math.floor(nextGoldCost),
                            wood: Math.floor(nextWoodCost),
                            iron: Math.floor(nextGoldCost * 0.5), // 철광도 비율에 따라 증가하도록 조정
                            magicPowder: 0,
                            duration: buildings.find(b => b.type === "HEADQUARTERS").upgradeTimeSeconds * Math.pow(2, newTerritoryLevel - 1)
                        });
                        setCurrentUpgradeStatus("업그레이드 가능");
                    } else {
                        setNextUpgradeCost({ gold: 0, food: 0, wood: 0, iron: 0, magicPowder: 0, duration: 0 });
                        setCurrentUpgradeStatus("최고 레벨입니다.");
                    }
                }
            }, 1000);
            countdownIntervalRef.current = interval;
        } else {
            setComputedRemainingUpgradeSeconds(0);
        }

        return () => {
            if (countdownIntervalRef.current) {
                clearInterval(countdownIntervalRef.current);
                countdownIntervalRef.current = null;
            }
        };
    }, [upgradeCompletionTimestamp, currentUpgradeStatus, addActivity, showMessage, buildings, gold, food, wood, iron, magicPowder, saveResourcesToBackend, territoryLevel]); // territoryLevel 의존성 추가

    const handleUpgradeBuilding = async (buildingId, buildingName) => {
        const userId = AuthenticationService.getCurrentUserId();
        if (!userId) {
            showMessage("유저 ID를 찾을 수 없습니다. 로그인해주세요.");
            return;
        }

        const buildingToUpgrade = buildings.find(b => b.id === buildingId);
        if (!buildingToUpgrade) {
            showMessage("건물을 찾을 수 없습니다.");
            return;
        }

        if (territoryLevel >= 3) { // 가정: 최대 3레벨
            showMessage(`${buildingName}은(는) 더 이상 업그레이드할 수 없습니다.`);
            setCurrentUpgradeStatus("최고 레벨입니다.");
            return;
        }

        if (currentUpgradeStatus.includes("진행 중")) { // includes로 변경하여 '업그레이드 진행 중'도 체크
            showMessage("이미 다른 업그레이드가 진행 중입니다.");
            return;
        }

        const requiredGold = nextUpgradeCost.gold;
        const requiredWood = nextUpgradeCost.wood;
        const requiredIron = nextUpgradeCost.iron;

        if (gold < requiredGold || wood < requiredWood || iron < requiredIron) {
            showMessage(`자원이 부족합니다! ${buildingName} 업그레이드에 필요: 골드 ${requiredGold}, 나무 ${requiredWood}, 철 ${requiredIron}`);
            return;
        }

        const newGold = gold - requiredGold;
        const newWood = wood - requiredWood;
        const newIron = iron - requiredIron;

        setGold(newGold);
        setWood(newWood);
        setIron(newIron);
        addActivity(`${buildingName} 업그레이드 비용 소모: 골드 -${requiredGold}, 나무 -${requiredWood}, 철 -${requiredIron}`, 'upgrade');

        // 비용 차감 후 자원 상태를 백엔드에 저장 (영지 레벨은 아직 변하지 않았으므로 기존 레벨 전달)
        saveResourcesToBackend(newGold, food, newWood, newIron, magicPowder, territoryLevel);

        setCurrentUpgradeStatus("업그레이드 중");
        const completionTime = Date.now() + (nextUpgradeCost.duration * 1000);
        setUpgradeCompletionTimestamp(completionTime);
        setComputedRemainingUpgradeSeconds(nextUpgradeCost.duration);

        showMessage(`${buildingName} 업그레이드가 시작되었습니다!`);
        addActivity(`${buildingName} 업그레이드가 시작되었습니다. ${formatDuration(nextUpgradeCost.duration)} 소요됩니다.`, 'upgrade');
    };

    const handleLogout = () => {
        AuthenticationService.logout();
        navigate('/auth');
        onAuthChange(false);
    };

    const handleNavClick = (path) => {
        navigate(path);
    };

    const upgradeButtonText = () => {
        if (currentUpgradeStatus.includes("진행 중")) {
            return `업그레이드 진행 중 (${formatDuration(computedRemainingUpgradeSeconds)})`;
        }
        if (territoryLevel >= 3) {
            return "최고 레벨 도달";
        }
        return `영지 업그레이드 (필요 자원: 골드 ${nextUpgradeCost.gold}, 나무 ${nextUpgradeCost.wood}, 철광 ${nextUpgradeCost.iron})`;
    };

    if (isLoading) {
        return <div className="loading-screen">로딩 중...</div>;
    }

    if (error) {
        return <div className="error-screen">에러: {error}</div>;
    }

    return (
        <div className="village-container">
            {message && (
                <div style={{
                    position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
                    backgroundColor: 'rgba(0, 0, 0, 0.7)', color: 'white', padding: '10px 20px',
                    borderRadius: '5px', zIndex: 1001, fontSize: '1.1em', textAlign: 'center'
                }}>
                    {message}
                </div>
            )}

            {/* top-bar를 Routes 밖으로 이동하여 항상 보이게 함 */}
            <header className="top-bar">
                <div className="resource-section">
                    <div className="resource-item">
                        <span className="emoji-icon">💰</span>
                        <span>골드: <span id="gold-amount">{gold}</span></span>
                    </div>
                    <div className="resource-item">
                        <span className="emoji-icon">🍎</span>
                        <span>식량: <span id="food-amount">{food}</span></span>
                    </div>
                    <div className="resource-item">
                        <span className="emoji-icon">🌲</span>
                        <span>목재: <span id="wood-amount">{wood}</span></span>
                    </div>
                    <div className="resource-item">
                        <span className="emoji-icon">⛏️</span>
                        <span>철광: <span id="iron-amount">{iron}</span></span>
                    </div>
                    <div className="resource-item special-resource">
                        <span className="emoji-icon">✨</span>
                        <span>신비한 가루: <span id="magic-powder-amount">{magicPowder}</span></span>
                    </div>
                </div>
                <div className="user-actions">
                    <span>총 병력: <span id="total-troops">{totalTroops}</span></span>
                    <span style={{ marginLeft: '10px' }}>영웅: <span id="heroes-count">{heroesCount}</span></span>
                    <button onClick={handleLogout} className="logout-button">로그아웃</button>
                </div>
            </header>

            {/* 메인 콘텐츠 영역: top-bar와 bottom-navigation 사이의 공간 */}
            <main className="content-area">
                <Routes>
                    <Route path="/" element={
                        <VillageContent
                            territoryLevel={territoryLevel}
                            handleUpgradeBuilding={handleUpgradeBuilding}
                            currentUpgradeStatus={currentUpgradeStatus}
                            computedRemainingUpgradeSeconds={computedRemainingUpgradeSeconds}
                            upgradeButtonText={upgradeButtonText}
                            formatDuration={formatDuration}
                        />
                    }/>
                    <Route path="barracks" element={<BarracksPage />} />
                    <Route path="inn" element={<InnPage />} />
                    <Route path="map" element={<MapPage />} />
                </Routes>
                <Outlet />

                {/* 활동 로그를 main.content-area 안에 두어 스크롤되도록 함 */}
                <div className="activity-log">
                    <h3 className="activity-log-h3">활동 로그</h3>
                    <div className="log-entries">
                        {activityLogs.map((logEntry, index) => (
                            <p key={index} className={`log-entry log-type-${logEntry.type.toLowerCase()}`}>
                                <span className="log-time">[{formatTime(logEntry.timestamp)}]</span> {logEntry.message}
                            </p>
                        ))}
                    </div>
                </div>
            </main>

            {/* bottom-navigation을 Routes 밖으로 이동하여 항상 보이게 함 */}
            <footer className="bottom-navigation">
                <button onClick={() => handleNavClick('/village')} className={`nav-button ${location.pathname === '/village' ? 'nav-button-active' : ''}`}>
                    <span className="nav-emoji-icon">🏡</span>
                    <span>영지</span>
                </button>
                <button onClick={() => handleNavClick('/village/barracks')} className={`nav-button ${location.pathname.startsWith('/village/barracks') ? 'nav-button-active' : ''}`}>
                    <span className="nav-emoji-icon">⚔️</span>
                    <span>병영</span>
                </button>
                <button onClick={() => handleNavClick('/village/forge')} className={`nav-button ${location.pathname.startsWith('/village/forge') ? 'nav-button-active' : ''}`}>
                    <span className="nav-emoji-icon">🛠️</span>
                    <span>대장간</span>
                </button>
                <button onClick={() => handleNavClick('/village/inn')} className={`nav-button ${location.pathname.startsWith('/village/inn') ? 'nav-button-active' : ''}`}>
                    <span className="nav-emoji-icon">🍻</span>
                    <span>여관</span>
                </button>
                <button onClick={() => handleNavClick('/village/map')} className={`nav-button ${location.pathname.startsWith('/village/map') ? 'nav-button-active' : ''}`}>
                    <span className="nav-emoji-icon">🗺️</span>
                    <span>지도</span>
                </button>
            </footer>
        </div>
    );
};

export default VillagePage;