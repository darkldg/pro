import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import AuthService from '../services/AuthenticationService.jsx';
import './BarracksPage.css'; // BarracksPage의 CSS를 공유하거나, PartyConfigSection을 위한 별도 CSS를 만들 수 있습니다.

// UnitSelectionModal 컴포넌트 (파티 구성의 하위 컴포넌트로 이 파일 안에 포함)
const UnitSelectionModal = ({ isOpen, onClose, units, onConfirmSelection, onDisbandPartyInModal, initialSelectedPartyMembers, addActivity, userId, fetchBarracksInfo }) => {
    if (!isOpen) return null;

    const [tempSelectedUnits, setTempSelectedUnits] = useState([]);
    const [draggingUnit, setDraggingUnit] = useState(null);

    // 모달이 열릴 때마다 initialSelectedPartyMembers로 초기화
    useEffect(() => {
        if (isOpen) {
            // initialSelectedPartyMembers는 null 값을 포함할 수 있으므로 필터링하여 유효한 유닛만 설정
            const initial = initialSelectedPartyMembers ? initialSelectedPartyMembers.filter(Boolean) : [];
            setTempSelectedUnits(initial.slice(0, 4)); // 최대 4개 슬롯에 맞춤
        }
    }, [isOpen, initialSelectedPartyMembers]);

    // 드래그 시작 시
    const handleDragStart = (e, unit) => {
        setDraggingUnit(unit);
        // 드래그 데이터 설정 (JSON.stringify로 객체 전체를 전달하여 파싱 오류 방지)
        e.dataTransfer.setData('unitData', JSON.stringify(unit));
    };

    // 드롭 시
    const handleDrop = (e, slotIndex) => {
        e.preventDefault();
        const unitDataString = e.dataTransfer.getData('unitData');
        const droppedUnit = unitDataString ? JSON.parse(unitDataString) : null;

        if (droppedUnit) {
            const updatedUnits = [...tempSelectedUnits];
            updatedUnits[slotIndex] = droppedUnit; // 드래그된 유닛을 해당 슬롯에 추가
            setTempSelectedUnits(updatedUnits);
        }
        setDraggingUnit(null);
    };

    // 드래그 오버 시
    const handleDragOver = (e) => {
        e.preventDefault();
    };

    // 슬롯에서 유닛 제거
    const handleRemoveUnit = (slotIndex) => {
        const updatedUnits = [...tempSelectedUnits];
        updatedUnits[slotIndex] = null; // 해당 슬롯을 비움
        setTempSelectedUnits(updatedUnits);
    };

    // 최종 파티 구성 확인
    const handleConfirm = () => {
        const confirmedUnits = tempSelectedUnits.filter(Boolean); // null이 아닌 유닛만 넘김
        onConfirmSelection(confirmedUnits);
        onClose();
    };

    const handleDisbandAndClose = () => {
        onDisbandPartyInModal();
        onClose();
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content barracks-party-modal">
                <h2>파티 구성</h2>
                <p>유닛을 드래그하여 파티 슬롯에 배치하세요. (영웅 최대 2명, 동일 병과 일반 유닛 중복 불가)</p>

                <h3>파티 슬롯</h3>
                <div className="party-slots-container">
                    {Array(4).fill(null).map((_, index) => (
                        <div
                            key={index}
                            className="party-slot-modal"
                            onDrop={(e) => handleDrop(e, index)}
                            onDragOver={handleDragOver}
                        >
                            {tempSelectedUnits[index] ? (
                                <div className="party-member-display-modal">
                                    <img
                                        src={tempSelectedUnits[index].illustrationUrl || 'https://placehold.co/80x90/6c757d/FFFFFF?text=Unit'}
                                        alt={tempSelectedUnits[index].name}
                                        className="party-unit-image-modal"
                                    />
                                    <span className="party-unit-name-modal">{tempSelectedUnits[index].name}</span>
                                    <button onClick={() => handleRemoveUnit(index)} className="remove-unit-button">X</button>
                                </div>
                            ) : (
                                <div className="empty-slot-modal-image-wrapper">
                                    <img
                                        src={'https://placehold.co/80x90/6c757d/FFFFFF?text=빈슬롯'}
                                        alt={`Empty Slot ${index + 1}`}
                                        className="empty-party-slot-modal-image"
                                    />
                                    <p className="empty-slot-modal-text">빈 슬롯</p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>

                <h3>보유 유닛</h3>
                {/* CSS 수정을 통해 가로 정렬 및 줄 바꿈이 되도록 함 */}
                <div className="available-units-list">
                    {units && units.length > 0 ? (
                        units.map(unit => (
                            <div
                                key={unit.id}
                                className="available-unit-card"
                                draggable
                                onDragStart={(e) => handleDragStart(e, unit)}
                            >
                                <img
                                    src={unit.illustrationUrl || 'https://placehold.co/50x60/6c757d/FFFFFF?text=Unit'}
                                    alt={unit.name}
                                    className="unit-icon-modal"
                                />
                                <div className="unit-info-modal">
                                    <h4>{unit.name}</h4>
                                    <p>수량: {unit.quantity}</p>
                                    <p>유형: {unit.unitType}</p>
                                    <p>병과: {unit.unitClass}</p>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p>현재 파티에 추가할 수 있는 유닛이 없습니다.</p>
                    )}
                </div>

                <div className="modal-actions">
                    <button onClick={handleConfirm} className="confirm-button">파티 저장</button>
                    <button onClick={handleDisbandAndClose} className="disband-button">파티 해체</button>
                    <button onClick={onClose} className="close-button">닫기</button>
                </div>
            </div>
        </div>
    );
};


const PartyConfigSection = ({ userId, currentPartyFromBackend, availableUnitsForParty, fetchBarracksInfo, addActivity }) => {
    const [selectedParty, setSelectedParty] = useState(Array(4).fill(null));
    const [isPartySelectionModalOpen, setIsPartySelectionModalOpen] = useState(false);

    // BarracksPage에서 받아온 초기 파티 멤버를 selectedParty에 설정
    useEffect(() => {
        // currentPartyFromBackend가 유효한 배열인 경우에만 처리
        if (Array.isArray(currentPartyFromBackend)) {
            const initial = currentPartyFromBackend.filter(Boolean); // null 값 제거
            const newParty = Array(4).fill(null);
            initial.forEach((member, index) => {
                if (index < 4) newParty[index] = member;
            });
            setSelectedParty(newParty);
            console.log("PartyConfigSection: 초기 파티 멤버 설정:", newParty);
        }
    }, [currentPartyFromBackend]);


    // 파티 저장 핸들러 (모달에서 최종 유닛 배열을 받아 처리)
    const handleConfirmUnitSelection = async (unitsConfirmedFromModal) => {
        console.log("PartyConfigSection: handleConfirmUnitSelection: 모달에서 전달받은 유닛 목록 (raw):", unitsConfirmedFromModal);

        const newParty = Array(4).fill(null);
        unitsConfirmedFromModal.forEach((unit, index) => {
            if (index < 4) {
                newParty[index] = unit;
            }
        });

        const heroCount = newParty.filter(member => member && member.unitType === 'HERO').length;
        if (heroCount > 2) {
            addActivity('파티에는 영웅을 최대 2명까지만 포함할 수 없습니다. 파티를 저장할 수 없습니다.');
            return;
        }
        const nonHeroUnits = newParty.filter(member => member && member.unitType !== 'HERO');
        const uniqueClasses = new Set(nonHeroUnits.map(u => u.unitClass));
        if (uniqueClasses.size !== nonHeroUnits.length) {
            addActivity('파티에는 동일한 병과의 일반 유닛을 2개 이상 포함할 수 없습니다. 파티를 저장할 수 없습니다.');
            return;
        }

        setSelectedParty(newParty);
        addActivity('파티가 성공적으로 구성되었습니다!');

        await sendPartyToBackend(newParty);
    };

    // 파티 해체 핸들러 (모달에서 호출됨)
    const handleDisbandParty = async () => {
        if (!userId) {
            addActivity('오류: 사용자 ID를 찾을 수 없습니다.');
            return;
        }
        if (window.confirm('정말로 이 파티를 해체하시겠습니까? 유닛이 반환됩니다.')) {
            try {
                await axios.post(`/api/barracks/${userId}/party/disband`, {}, AuthService.getAuthHeader());
                addActivity('파티가 해체되고 유닛이 반환되었습니다.');
                setSelectedParty(Array(4).fill(null)); // UI 초기화
                fetchBarracksInfo(); // 부모 컴포넌트 정보 새로고침
            } catch (error) {
                console.error('PartyConfigSection: 파티 해체 실패:', error);
                const errorMessage = error.response?.data?.message || '파티 해체 중 오류가 발생했습니다.';
                addActivity(`파티 해체 실패: ${errorMessage}`);
            }
        }
    };

    // 백엔드에 파티 저장 요청을 보내는 함수 (내부 유틸리티)
    const sendPartyToBackend = async (partyToSave) => {
        if (!userId) {
            addActivity('오류: 사용자 ID를 찾을 수 없습니다.');
            return;
        }
        const partyMembersToSave = partyToSave.filter(member => member !== null);
        try {
            const unitIdsInParty = partyMembersToSave.map(member => member.id);
            console.log("PartyConfigSection: Sending party to backend. Unit IDs:", unitIdsInParty);
            await axios.post(`/api/barracks/${userId}/party`, unitIdsInParty, AuthService.getAuthHeader());
            addActivity('파티가 서버에 성공적으로 저장되었습니다.');
            fetchBarracksInfo(); // 부모 컴포넌트 정보 새로고침
        } catch (error) {
            console.error('PartyConfigSection: 파티 저장 실패:', error);
            const errorMessage = error.response?.data?.message || '파티 저장 중 오류가 발생했습니다.';
            addActivity(`파티 저장 실패: ${errorMessage}`);
        }
    };

    // 파티 편집 모달을 여는 함수 (슬롯 클릭 또는 버튼 클릭 시)
    const handleOpenPartySelectionModal = () => {
        setIsPartySelectionModalOpen(true);
    };

    return (
        <>
            <div className="section current-party-section">
                <h2>파티 구성 (최대 4명, 영웅 2명)</h2>
                <div className="party-slots-container horizontal">
                    {Array.from({ length: 4 }).map((_, index) => (
                        <div
                            key={index}
                            className="party-slot"
                            onClick={handleOpenPartySelectionModal}
                        >
                            {selectedParty[index] ? (
                                <div className="party-member-display">
                                    <img
                                        src={selectedParty[index].illustrationUrl || 'https://placehold.co/80x90/6c757d/FFFFFF?text=Unit'}
                                        alt={selectedParty[index].name}
                                        className="party-unit-image"
                                    />
                                    <span className="party-unit-name">{selectedParty[index].name}</span>
                                </div>
                            ) : (
                                <div className="empty-slot-image-wrapper">
                                    <img
                                        src={'https://placehold.co/80x90/6c757d/FFFFFF?text=빈슬롯'}
                                        alt={`Empty Slot ${index + 1}`}
                                        className="empty-party-slot-image"
                                    />
                                    <p className="empty-slot-text">빈 슬롯</p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
                <div className="party-actions">
                    <button onClick={handleOpenPartySelectionModal} className="button edit-party-button">파티 편집</button>
                </div>
            </div>

            {/* 유닛 선택 모달 */}
            <UnitSelectionModal
                isOpen={isPartySelectionModalOpen}
                onClose={() => setIsPartySelectionModalOpen(false)}
                units={availableUnitsForParty}
                onConfirmSelection={handleConfirmUnitSelection}
                onDisbandPartyInModal={handleDisbandParty}
                initialSelectedPartyMembers={selectedParty} // 현재 파티 상태를 모달에 전달
                addActivity={addActivity}
                userId={userId}
                fetchBarracksInfo={fetchBarracksInfo}
            />
        </>
    );
};

export default PartyConfigSection;