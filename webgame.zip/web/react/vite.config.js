import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    // ⭐ 이 부분을 추가하거나 이미 있다면 확인해주세요. ⭐
    open: true, // 개발 서버 시작 시 자동으로 브라우저를 엽니다.

    proxy: {
      '/api': {
        target: 'http://localhost:7777/',
        changeOrigin: true,
        secure: false,
        ws: true,

      }

    }
  }
})
