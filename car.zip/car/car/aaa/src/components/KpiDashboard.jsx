// src/components/KpiDashboard.js
import React from 'react';

function KpiDashboard() {
    return (
        <header className="kpi-dashboard">
            <h2>서울시 주요 지표 현황</h2>
            <div className="kpi-container">
                <div className="kpi-item">
                    <h3>총 불법주정차 단속 건수 </h3>
                    <p>1,576,267 건</p>
                </div>
                <div className="kpi-item">
                    <h3>총 주차면수 (서울시)</h3>
                    <p>4,548,788 개</p>
                </div>
                <div className="kpi-item">
                    <h3>평균 이면도로 비율</h3>
                    <p>69.8%</p>
                </div>
                <div className="kpi-item">
                    <h3>총 교통단속 CCTV 수</h3>
                    <p>8648 개</p>
                </div>
                <div className="kpi-item">
                    <h3>월평균 신고 건수</h3>
                    <p>3184 건</p>
                </div>
            </div>
        </header>
    );
}

export default KpiDashboard;