// src/components/SeoulMap.js
import React, { useState } from 'react';
import districts from './DistrictData';

import seoulMapImage from '../assets/images/1.png'; // ⚠️ 이미지 경로를 정확히 지정했습니다.

// 각 구의 대략적인 위치 및 크기 데이터 (백분율)
// ⚠️ 이 값들은 사용하시는 'seoul_map.png' 이미지에 맞춰 수동으로 정교하게 조정해야 합니다.
// 브라우저 개발자 도구(F12)를 열고 .district-overlay 요소의 style을 조절하며 위치를 찾아보세요.
const districtPositions = {
    '강남구': { top: '73%', left: '60%', width: '8%', height: '7%' },
    '강동구': { top: '52%', left: '77%', width: '6%', height: '6%' },
    '강북구': { top: '20%', left: '53%', width: '7%', height: '6%' },
    '강서구': { top: '46%', left: '19%', width: '7%', height: '8%' },
    '관악구': { top: '81%', left: '41%', width: '7%', height: '7%' },
    '광진구': { top: '53%', left: '66%', width: '7%', height: '6%' },
    '구로구': { top: '70%', left: '25%', width: '6%', height: '7%' },
    '금천구': { top: '79%', left: '32%', width: '7%', height: '6%' },
    '노원구': { top: '17%', left: '65%', width: '6%', height: '6%' },
    '도봉구': { top: '11%', left: '57%', width: '6%', height: '6%' },
    '동대문구': { top: '41%', left: '60%', width: '7%', height: '6%' },
    '동작구': { top: '68%', left: '41%', width: '8%', height: '7%' },
    '마포구': { top: '49%', left: '35%', width: '7%', height: '6%' },
    '서대문구': { top: '41%', left: '39%', width: '8%', height: '7%' },
    '서초구': { top: '75%', left: '52%', width: '7%', height: '7%' },
    '성동구': { top: '52%', left: '58%', width: '7%', height: '6%' },
    '성북구': { top: '34%', left: '55%', width: '6%', height: '7%' },
    '송파구': { top: '67%', left: '69%', width: '8%', height: '6%' },
    '양천구': { top: '62%', left: '25%', width: '7%', height: '6%' },
    '영등포구': { top: '63%', left: '33%', width: '8%', height: '6%' },
    '용산구': { top: '57%', left: '48%', width: '6%', height: '6%' },
    '은평구': { top: '27%', left: '39%', width: '7%', height: '7%' },
    '종로구': { top: '40%', left: '48%', width: '6%', height: '6%' },
    '중구': { top: '49%', left: '50%', width: '6%', height: '5%' },
    '중랑구': { top: '35%', left: '67%', width: '7%', height: '7%' },
};


function SeoulMap({ onDistrictSelect, selectedDistrict }) {
    const [hoverInfo, setHoverInfo] = useState({ visible: false, name: '', x: 0, y: 0 });

    const handleMouseEnter = (e) => {
        const districtName = e.target.getAttribute('data-district');
        if (districtName) {
            setHoverInfo({
                visible: true,
                name: districtName,
                x: e.clientX + 10,
                y: e.clientY + 10,
            });
        }
    };

    const handleMouseMove = (e) => {
        if (hoverInfo.visible) {
            setHoverInfo(prev => ({
                ...prev,
                x: e.clientX + 10,
                y: e.clientY + 10,
            }));
        }
    };

    const handleMouseLeave = () => {
        setHoverInfo({ visible: false, name: '', x: 0, y: 0 });
    };

    const handleClick = (e) => {
        const districtName = e.target.getAttribute('data-district');
        if (districtName) {
            // 구 선택 시 App.js로 이벤트 전달
            onDistrictSelect(districtName);
            // console.log(`${districtName} 클릭됨!`); // 디버깅용
        }
    };

    return (
        <main className="map-section">
            <h2>서울시 25개 자치구 현황</h2>
            <div
                className="seoul-map-container"
                onMouseMove={handleMouseMove}
                style={{
                    backgroundImage: `url(${seoulMapImage})`,
                    backgroundSize: 'contain',
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'center',
                }}
            >
                {districts.map((districtName) => (
                    <div
                        key={districtName}
                        className={`district-overlay ${selectedDistrict === districtName ? 'selected' : ''}`}
                        style={districtPositions[districtName]}
                        data-district={districtName}
                        onMouseEnter={handleMouseEnter}
                        onMouseLeave={handleMouseLeave}
                        onClick={handleClick}
                    >
                    </div>
                ))}

                {hoverInfo.visible && (
                    <div
                        className="hover-info"
                        style={{ left: hoverInfo.x, top: hoverInfo.y }}
                    >
                        {hoverInfo.name}
                    </div>
                )}
            </div>
        </main>
    );
}

export default SeoulMap;