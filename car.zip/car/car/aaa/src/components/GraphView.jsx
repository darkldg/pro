// src/components/GraphView.js
import React, { useState, useEffect } from 'react';
import districtDetails from './DistrictDetailData';

const graphModules = import.meta.glob('../assets/images/*.png');

function GraphView({ selectedDistrict, onClearDistrict }) {
    const [selectedCategory, setSelectedCategory] = useState(null);
    const [graphImageSrc, setGraphImageSrc] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        setSelectedCategory(null);
        setGraphImageSrc(null);
    }, [selectedDistrict]);

    useEffect(() => {
        if (!selectedCategory || !selectedDistrict) {
            setGraphImageSrc(null);
            return;
        }

        const loadImage = async () => {
            setIsLoading(true);
            try {
                let imagePath;
                if (selectedCategory === 'trafficIndex') {
                    // trafficIndex 카테고리일 경우, A.png, B.png, C.png 이미지를 불러옵니다.
                    imagePath = `../assets/images/${details.trafficIndex}.png`;
                } else {
                    // 다른 카테고리의 경우, 기존 로직대로 구 이름과 카테고리로 된 그래프 이미지를 불러옵니다.
                    imagePath = `../assets/images/${selectedDistrict}_${selectedCategory}_graph.png`;
                }

                const imageModule = graphModules[imagePath];

                if (imageModule) {
                    const module = await imageModule();
                    setGraphImageSrc(module.default);
                } else {
                    setGraphImageSrc(null);
                }
            } catch (e) {
                console.error(`Error loading image: ${e.message}`);
                setGraphImageSrc(null);
            } finally {
                setIsLoading(false);
            }
        };

        if (selectedCategory) {
            loadImage();
        }

    }, [selectedDistrict, selectedCategory]);

    const details = districtDetails[selectedDistrict];

    if (!details) {
        return (
            <div className="graph-view-container">
                <p>선택된 구의 데이터를 찾을 수 없습니다.</p>
                <button onClick={onClearDistrict} className="clear-district-button">구 선택 해제</button>
            </div>
        );
    }

    const renderCategoryContent = () => {
        if (!selectedCategory) {
            return (
                <div className="description-container">
                    <p>{details.description}</p>
                </div>
            );
        }

        return (
            <div className="category-detail">
                <h4>{selectedDistrict} {
                    selectedCategory === 'parking' ? '주차 현황' :
                        selectedCategory === 'cctv' ? '교통단속 CCTV 현황' :
                            selectedCategory === 'alleyRoad' ? '이면도로(폭 6m 미만) 비율' :
                                selectedCategory === 'facilities' ? '건물 분포도' :
                                    selectedCategory === 'trafficIndex' ? '교통 지수' : ''
                }</h4>
                {selectedCategory === 'parking' &&
                    <>
                        <p>공영 주차장: {details.parking.공영주차장}</p>
                        <p>민영 주차장: {details.parking.민영주차장}</p>
                        <p>부설 주차장: {details.parking.부설주차장}</p>
                    </>
                }
                {selectedCategory === 'cctv' &&
                    <p>CCTV 수: {details.cctvCount}개</p>
                }
                {selectedCategory === 'alleyRoad' &&
                    <p>폭 6m 미만 도로 수: {details.alleyRoadRatio}개</p>
                }
                {selectedCategory === 'facilities' &&
                    <>
                        <p>일반건축물: {details.facilities.일반건축물}</p>
                        <p>공동주택: {details.facilities.공동주택}</p>
                        <p>개인주택: {details.facilities.개인주택}</p>
                    </>
                }

                {/* 교통 지수 카테고리일 때만 등급, 이미지, 별첨을 순서대로 렌더링합니다. */}
                {selectedCategory === 'trafficIndex' &&
                    <>
                        <p>등급: <strong>{details.trafficIndex}</strong></p>
                        {isLoading && <p>이미지를 불러오는 중...</p>}
                        {!isLoading && graphImageSrc && (
                            <img src={graphImageSrc} alt={`Traffic Index ${details.trafficIndex}`} className="detail-graph" />
                        )}
                        {!isLoading && !graphImageSrc && selectedCategory && (
                            <p>이미지를 찾을 수 없습니다.</p>
                        )}
                        <p className="traffic-index-note">
                            <small>
                                * 주차면수, 단속 인프라(CCTV 등)를 기반으로 산정된 지수입니다.
                            </small>
                        </p>
                    </>
                }

                {/* trafficIndex 카테고리가 아닐 때만 이미지를 렌더링합니다. */}
                {selectedCategory !== 'trafficIndex' && selectedCategory &&
                    <>
                        {isLoading && <p>이미지를 불러오는 중...</p>}
                        {!isLoading && graphImageSrc && (
                            <img src={graphImageSrc} alt={`${selectedDistrict} ${selectedCategory} 그래프`} className="detail-graph" />
                        )}
                        {!isLoading && !graphImageSrc && selectedCategory && (
                            <p>이미지를 찾을 수 없습니다.</p>
                        )}
                    </>
                }
            </div>
        );
    };

    return (
        <div className="graph-view-container">
            <h3>{selectedDistrict} 상세 분석</h3>
            <div className="category-navigation">
                <button onClick={() => setSelectedCategory('parking')} className={selectedCategory === 'parking' ? 'active' : ''}>주차 현황</button>
                <button onClick={() => setSelectedCategory('cctv')} className={selectedCategory === 'cctv' ? 'active' : ''}>CCTV 현황</button>
                <button onClick={() => setSelectedCategory('alleyRoad')} className={selectedCategory === 'alleyRoad' ? 'active' : ''}>도로폭 비율</button>
                <button onClick={() => setSelectedCategory('facilities')} className={selectedCategory === 'facilities' ? 'active' : ''}>건물 분포</button>
                <button onClick={() => setSelectedCategory('trafficIndex')} className={selectedCategory === 'trafficIndex' ? 'active' : ''}>교통 지수</button>
            </div>

            <div className="category-content">
                {renderCategoryContent()}
            </div>

            <button onClick={onClearDistrict} className="clear-district-button">구 선택 해제</button>
        </div>
    );
}

export default GraphView;