// src/App.js
import React, { useState } from 'react';
import './App.css';
import KpiDashboard from './components/KpiDashboard';
import SeoulMap from './components/SeoulMap';
import GraphView from './components/GraphView';

function App() {
    // 선택된 구를 관리하는 상태. null이면 GraphView가 표시되지 않음
    const [selectedDistrict, setSelectedDistrict] = useState(null);

    const handleDistrictSelect = (districtName) => {
        setSelectedDistrict(districtName);
    };

    const handleClearDistrict = () => {
        setSelectedDistrict(null); // 구 선택 초기화
    };

    return (
        <div className="App">
            <KpiDashboard />
            <SeoulMap
                onDistrictSelect={handleDistrictSelect}
                selectedDistrict={selectedDistrict} // 선택된 구 표시를 위해 Map에 전달
            />
            {selectedDistrict && (
                // 구가 선택되면 GraphView를 지도 아래에 보여줌
                <GraphView
                    selectedDistrict={selectedDistrict}
                    onClearDistrict={handleClearDistrict}
                />
            )}
        </div>
    );
}

export default App;