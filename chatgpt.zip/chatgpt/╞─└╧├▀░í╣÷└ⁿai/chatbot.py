import customtkinter as ctk
import chatbot_core
import os
import threading
import time
import tkinter as tk
import sys
import re
import tkinter.font
import tkinter.filedialog # 파일 대화 상자를 위해 추가

# --- 0. 환경 변수 로드 ---
from dotenv import load_dotenv
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    print("오류: GOOGLE_API_KEY 환경 변수가 설정되지 않았습니다.")
    exit()

# --- 1. 챗봇 초기화 및 세션 상태 관리 ---
chatbot_manager = None

# --- CustomTkinter 앱 클래스 정의 ---
class HermesChatApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("🕊️ 헤르메스: 지식의 전령")
        self.geometry("1280x800")
        self.minsize(650, 550)
        # self.iconbitmap(self.resource_path("hermes_icon.ico")) # 윈도우 아이콘 (ICO 파일 필요, 주석 처리됨)

        # self.messages 대신 메시지 객체와 해당 위젯 참조를 함께 관리하는 리스트
        # 각 요소는 {"role": str, "content": str, "id": str(옵션), "widget_ref": CTkFrame(옵션)} 형태
        self.messages = []
        self.current_chat_row = 0 # 채팅 메시지가 추가될 다음 그리드 행 번호
        self.selected_file_paths = [] # 파일 업로드를 위해 추가: 선택된 파일 경로들을 저장

        # --- 커스텀 폰트 로드 및 설정 ---
        self.custom_font_name = "굴림채" 
        
        try:
            _font_obj = tkinter.font.Font(family=self.custom_font_name, size=10)
            actual_font_family = _font_obj.actual('family')
            print(f"폰트 '{self.custom_font_name}' 로드 시도 성공. 실제 로드된 폰트: '{actual_font_family}'")
            if actual_font_family != self.custom_font_name:
                print(f"경고: 요청된 폰트 이름 '{self.custom_font_name}'과 실제 로드된 폰트 '{actual_font_family}'이 다릅니다. 이는 시스템이 다른 유사한 폰트로 폴백(fallback)되었을 수 있습니다.")
        except Exception as e:
            print(f"폰트 '{self.custom_font_name}' 로드 중 오류 발생. 시스템에 해당 폰트가 없을 수 있습니다.")
            print(f"오류: {e}")
            self.custom_font_name = "나눔고딕"
            print(f"기본 폰트 '{self.custom_font_name}'으로 대체합니다.")


        # UI 레이아웃을 위한 그리드 설정
        self.grid_rowconfigure(0, weight=0) # 헤더
        self.grid_rowconfigure(1, weight=1) # 채팅 기록 영역
        self.grid_rowconfigure(2, weight=0) # 입력창 및 버튼
        self.grid_columnconfigure(0, weight=1)

        # --- 헤더 섹션 ---
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="ew")
        header_frame.grid_columnconfigure(0, weight=1)

        title_label = ctk.CTkLabel(header_frame, text="🕊️ 헤르메스: 지식의 전령 🕊️",
                                   font=ctk.CTkFont(family=self.custom_font_name, size=28, weight="bold"),
                                   text_color="#4a69bd")
        title_label.grid(row=0, column=0, pady=5)

        subtitle_label = ctk.CTkLabel(header_frame, text="신들의 지혜를 담아, 당신의 질문에 빠르고 정확하게 답합니다.",
                                           font=ctk.CTkFont(family=self.custom_font_name, size=14),
                                           text_color="#555555")
        subtitle_label.grid(row=1, column=0, pady=5)
        
        # 구분선
        separator = ctk.CTkFrame(self, height=1, fg_color="#cccccc")
        separator.grid(row=0, column=0, sticky="ew", padx=10, pady=(100,0))

        # --- 채팅 기록 표시 영역 ---
        self.chat_history_frame = ctk.CTkScrollableFrame(self, fg_color="#fcfcfc", corner_radius=12)
        self.chat_history_frame.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")
        self.chat_history_frame.grid_columnconfigure(0, weight=1)

        # --- 사용자 입력 섹션 (CTkTextbox) ---
        input_frame = ctk.CTkFrame(self, fg_color="transparent")
        input_frame.grid(row=2, column=0, padx=20, pady=(10, 20), sticky="ew")
        input_frame.grid_columnconfigure(0, weight=1)

        self.user_input_textbox = ctk.CTkTextbox(input_frame, 
                                                 font=ctk.CTkFont(family=self.custom_font_name, size=16), 
                                                 height=80, 
                                                 corner_radius=10, 
                                                 fg_color="#ffffff", border_color="#cccccc", border_width=1,
                                                 text_color="#333333", 
                                                 wrap="word")
        self.user_input_textbox.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        
        # CTkTextbox용 플레이스홀더 구현
        self.placeholder_text = "이곳에 질문을 입력하고 Enter를 누르세요..."
        self._add_placeholder()

        # 플레이스홀더 이벤트 바인딩
        self.user_input_textbox.bind("<FocusIn>", self._on_textbox_focus_in)
        self.user_input_textbox.bind("<FocusOut>", self._on_textbox_focus_out)
        self.user_input_textbox.bind("<Key>", self._on_textbox_key_press)

        # Enter 키 바인딩 조정
        self.user_input_textbox.bind("<Return>", self.send_message_event)
        self.user_input_textbox.bind("<Shift-Return>", lambda event: self.user_input_textbox.insert(tk.END, "\n"))


        self.send_button = ctk.CTkButton(input_frame, text="전송", command=self.send_message,
                                         font=ctk.CTkFont(family=self.custom_font_name, size=16, weight="bold"), height=40, corner_radius=20,
                                         fg_color="#4a69bd", hover_color="#5b7ec2", text_color="#ffffff")
        self.send_button.grid(row=0, column=1, sticky="e")

        # ⭐ 파일 업로드 버튼 추가 (command를 직접 self.upload_file로 연결)
        # 디버깅을 위해 self의 타입을 출력합니다.
        print(f"DEBUG: Type of self in __init__ before upload_file_button creation: {type(self)}")
        self.upload_file_button = ctk.CTkButton(input_frame, text="파일 추가", command=self.upload_file, # lambda 제거
                                                 font=ctk.CTkFont(family=self.custom_font_name, size=16),
                                                 height=40, corner_radius=20,
                                                 fg_color="#6c757d", hover_color="#808a93", text_color="#ffffff")
        self.upload_file_button.grid(row=0, column=2, sticky="e", padx=(10, 0))


        # --- 챗봇 초기화 (앱 시작 시 한 번) ---
        self.initialize_chatbot_manager()
        
        # --- 초기 메시지 표시 (Tkinter 이벤트 루프가 준비된 후 실행되도록 지연) ---
        self.after(0, self._add_message_to_ui, {"role": "assistant", "content": "안녕하세요! 헤르메스입니다. 무엇이든 물어보세요."})
        
        # 윈도우 크기 변경 이벤트 바인딩 (메시지 버블 너비 조정을 위해)
        self.bind("<Configure>", self._on_window_configure)

        # 창 크기 변경 시 디바운싱 타이머 ID 저장용
        self._resize_timer_id = None

        # 코드 블록 텍스트박스에 사용될 폰트 객체를 미리 생성
        self._code_font = ctk.CTkFont(family="Consolas", size=14)


    # --- 유틸리티 함수: PyInstaller 번들링 시 리소스 경로 처리 ---
    def resource_path(self, relative_path):
        """PyInstaller로 번들링할 때 리소스 파일 경로를 올바르게 반환합니다."""
        try:
            base_path = sys._MEIPASS
        except Exception:
            base_path = os.path.abspath(".")
        return os.path.join(base_path, relative_path)
    
    # --- 파일 업로드 메서드 추가 (누락된 부분) ---
    def upload_file(self):
        filetypes = [
            ("Python files", "*.py"),
            ("Java files", "*.java"),
            ("C/C++ files", "*.c *.cpp *.h"),
            ("JavaScript files", "*.js"),
            ("HTML files", "*.html *.htm"),
            ("CSS files", "*.css"),
            ("JSON files", "*.json"),
            ("XML files", "*.xml"),
            ("Markdown files", "*.md *.markdown"),
            ("Text files", "*.txt"),
            ("All code files", "*.py *.java *.c *.cpp *.h *.js *.html *.htm *.css *.json *.xml *.md *.markdown *.txt"),
            ("All files", "*.*")
        ]
        # 다중 파일 선택 허용
        selected_files = tkinter.filedialog.askopenfilenames(
            title="코드 파일 선택",
            filetypes=filetypes
        )
        
        if selected_files:
            # 최대 10개 파일 제한
            if len(selected_files) > 10:
                self.show_popup_message("최대 10개의 파일만 첨부할 수 있습니다.", "orange")
                self.selected_file_paths = list(selected_files[:10])
            else:
                self.selected_file_paths = list(selected_files)
            
            file_names = ", ".join([os.path.basename(p) for p in self.selected_file_paths])
            self.show_popup_message(f"파일 첨부됨: {file_names}", "blue")
        else:
            self.selected_file_paths = [] # 파일 선택 취소 시 초기화
            self.show_popup_message("파일 선택이 취소되었습니다.", "red")


    # --- 텍스트박스 높이 자동 조절 헬퍼 함수 ---
    def text_textbox_height(self, text_content, max_width_pixels):
        try:
            font_obj = ctk.CTkFont(family=self.custom_font_name, size=15)
        except AttributeError: # custom_font_name이 아직 설정되지 않았을 경우 대비
            font_obj = ctk.CTkFont(family="Arial", size=15)

        lines = text_content.split('\n')
        estimated_lines = 0
        
        line_height_px = font_obj.metrics("linespace")

        effective_max_width = max_width_pixels 
        
        for line in lines:
            if not line.strip():
                estimated_lines += 1
                continue
            
            line_pixel_width = font_obj.measure(line)
            
            if line_pixel_width > effective_max_width:
                estimated_lines += (line_pixel_width // effective_max_width) + (1 if line_pixel_width % effective_max_width > 0 else 0)
            else:
                estimated_lines += 1
                
        min_textbox_visual_height = max(1, estimated_lines) * line_height_px 

        calculated_height = max(min_textbox_visual_height, estimated_lines * line_height_px)
        
        # 계산된 높이에 더 넉넉한 버퍼를 추가하여 스크롤바가 생기는 것을 확실히 방지
        return calculated_height + 10 # 10 픽셀의 여유 공간 추가

    # --- 챗봇 코어 매니저 초기화 ---
    def initialize_chatbot_manager(self):
        global chatbot_manager
        print("[Desktop App] ChatbotCoreManager 초기화 중...")
        chatbot_manager = chatbot_core.ChatbotCoreManager()
        chatbot_manager.initialize_user_data()
        print("[Desktop App] ChatbotCoreManager 초기화 완료.")

    # --- CTkTextbox 플레이스홀더 관련 메서드 ---
    def _add_placeholder(self):
        # 입력창이 완전히 비어있을 때만 플레이스홀더 추가
        if not self.user_input_textbox.get("1.0", "end-1c").strip():
            self.user_input_textbox.delete("1.0", ctk.END)
            self.user_input_textbox.insert("1.0", self.placeholder_text)
            self.user_input_textbox.configure(text_color="#888888")
            self.has_placeholder = True
        else:
            self.has_placeholder = False

    def _remove_placeholder(self):
        # 현재 내용이 플레이스홀더 텍스트와 정확히 일치할 때만 제거
        current_content = self.user_input_textbox.get("1.0", "end-1c")
        if current_content == self.placeholder_text:
            self.user_input_textbox.delete("1.0", ctk.END)
            self.user_input_textbox.configure(text_color="#333333")
            self.has_placeholder = False
        elif self.has_placeholder: # 만약 has_placeholder가 True인데 내용이 플레이스홀더가 아니라면 상태를 정정
            self.has_placeholder = False

    def _on_textbox_focus_in(self, event):
        # 포커스가 들어올 때 플레이스홀더 제거 시도
        self._remove_placeholder()

    def _on_textbox_focus_out(self, event):
        # 포커스가 나갈 때 입력창이 비어있으면 플레이스홀더 다시 추가 시도
        self._add_placeholder()

    def _on_textbox_key_press(self, event):
        # 플레이스홀더가 활성화된 상태에서 문자를 입력하려고 할 때만 작동
        # `event.char`는 실제 입력되는 문자를 나타냅니다.
        # `event.keysym`은 키보드의 물리적인 키를 나타냅니다.
        # Shift, Ctrl, Alt 같은 기능 키나 Backspace, Enter 같은 특수 키는 제외
        if self.has_placeholder and event.char and event.char.isprintable() and event.keysym not in ['BackSpace', 'Delete', 'Return', 'Tab', 'Shift_L', 'Shift_R', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R', 'Meta_L', 'Meta_R']:
            self._remove_placeholder()
            # 중요한 변경: 여기서 `return "break"`를 제거하여 Tkinter의 기본 문자 삽입 동작을 막지 않습니다.
            # 또한, 문자를 수동으로 삽입하는 `self.user_input_textbox.insert(tk.INSERT, event.char)`도 제거합니다.
            # `_remove_placeholder()`가 이미 텍스트를 지웠으므로, Tkinter가 다음으로 처리하는
            # `event.char` 삽입이 정확히 발생할 것입니다.

    # --- 클립보드에 텍스트 복사 및 팝업 메시지 ---
    def copy_to_clipboard(self, text_to_copy):
        try:
            self.clipboard_clear()
            self.clipboard_append(text_to_copy)
            self.update_idletasks()
            self.show_popup_message("복사 완료!", "green")
        except Exception as e:
            self.show_popup_message(f"복사 실패: {e}", "red")

    def show_popup_message(self, message_text, color):
        if hasattr(self, '_current_popup'):
            self._current_popup.destroy()
        
        popup = ctk.CTkLabel(self, text=message_text, text_color="white",
                             fg_color=color, corner_radius=5, padx=10, pady=5,
                             font=ctk.CTkFont(family=self.custom_font_name, size=14, weight="bold"))
        
        popup.place(relx=0.5, rely=0.9, anchor=tk.CENTER)
        self._current_popup = popup

        popup.after(2000, popup.destroy)
        popup.after(2000, lambda: setattr(self, '_current_popup', None))

    # --- 윈도우 크기 변경 시 호출될 콜백 함수 ---
    def _on_window_configure(self, event):
        # 앱 자체의 크기 변경 이벤트일 때만 처리
        if event.widget == self:
            if self._resize_timer_id:
                self.after_cancel(self._resize_timer_id)
            # 300ms 후에 _resize_chat_bubbles 호출 예약
            self._resize_timer_id = self.after(300, self._resize_chat_bubbles)

    # --- 메시지 버블 크기 재조정 함수 (창 크기 변경 시) ---
    def _resize_chat_bubbles(self):
        # 현재 채팅 기록 프레임의 실제 너비 가져오기
        frame_width = self.chat_history_frame.winfo_width()
        if frame_width == 0: # 아직 너비가 확정되지 않았다면 최소 너비 기반으로 계산
            frame_width = self.winfo_width() - 40 # 대략적인 컨테이너 너비
            
        max_bubble_width = frame_width * 0.9 # 패딩 고려

        # 코드 블록 폰트 객체 미리 가져오기
        code_line_height_px = self._code_font.metrics("linespace")

        for msg_data in self.messages:
            if "widget_ref" in msg_data and msg_data["widget_ref"] is not None and msg_data["widget_ref"].winfo_exists():
                message_bubble_frame = msg_data["widget_ref"]
                
                # 메시지 버블 프레임 내의 각 구성 요소(텍스트박스, 코드박스)를 찾아 크기 재조정
                for child_widget in message_bubble_frame.winfo_children():
                    if isinstance(child_widget, ctk.CTkTextbox):
                        content = child_widget.get("1.0", "end-1c")
                        
                        # 텍스트박스의 경우 새로운 높이를 계산하여 적용
                        if child_widget.cget("fg_color") == "transparent": # 일반 텍스트 박스
                            new_height = self.text_textbox_height(content, max_bubble_width - 30)
                            child_widget.configure(height=new_height)
                        elif child_widget.cget("fg_color") == "#282c34": # 코드 블록 텍스트 박스
                            # `min` 함수 제거 및 실제 폰트 줄 간격 + 더 넉넉한 버퍼 사용
                            new_height = (content.count('\n') + 2) * code_line_height_px + 10 # 10 픽셀의 여유 공간 추가
                            child_widget.configure(height=new_height)
                        
                        # (선택 사항) 너비를 다시 설정해야 한다면 여기서 configure(width=...)
                        # CTkTextbox는 wrap="word"가 있고 그리드에 sticky="ew"로 설정되어 있으면
                        # 너비를 자동으로 채우므로, 일반적으로 명시적 width 설정은 불필요.


        self.chat_history_frame.update_idletasks() # UI 업데이트 강제
        self.chat_history_frame._parent_canvas.yview_moveto(1.0) # 맨 아래로 스크롤

    # --- 단일 메시지를 UI에 추가/업데이트하는 함수 (핵심 변경!) ---
    def _add_message_to_ui(self, msg_data, is_update=False):
        role = msg_data["role"]
        content = msg_data["content"]
        message_id = msg_data.get("id")

        bubble_color = "#e8f5fb" if role == "assistant" else "#f0f0f0"
        if role == "error": 
            bubble_color = "#ffe0e0"

        # 메시지 업데이트 로직
        if is_update and message_id:
            for i, msg in enumerate(self.messages):
                if "id" in msg and msg["id"] == message_id:
                    if "widget_ref" in msg and msg["widget_ref"] and msg["widget_ref"].winfo_exists():
                        # 기존 위젯을 찾아서 내용을 업데이트
                        message_bubble_frame = msg["widget_ref"]
                        
                        # 기존 내용을 모두 지우고 새 내용으로 다시 그림
                        for child in message_bubble_frame.winfo_children():
                            child.destroy()
                        
                        # 새 내용으로 렌더링 (아래 _render_content_in_bubble과 동일한 로직)
                        self._render_content_in_bubble(message_bubble_frame, content, role)
                        
                        # messages 리스트의 content 업데이트
                        self.messages[i]["content"] = content
                        self.messages[i]["role"] = role # 역할도 업데이트될 수 있으므로
                        
                        self.chat_history_frame.update_idletasks()
                        self.chat_history_frame._parent_canvas.yview_moveto(1.0)
                        return # 업데이트 완료
        
        # 새 메시지 추가 로직
        message_bubble_frame = ctk.CTkFrame(self.chat_history_frame, corner_radius=10, fg_color=bubble_color)
        
        # 그리드 배치
        if role == "assistant" or role == "error":
            message_bubble_frame.grid(row=self.current_chat_row, column=0, sticky="nwe", padx=(10, 10), pady=(1, 1)) 
        else: # user
            message_bubble_frame.grid(row=self.current_chat_row, column=0, sticky="ew", padx=(10, 10), pady=(1, 1)) 
        
        message_bubble_frame.grid_columnconfigure(0, weight=1)

        # 내용 렌더링 (별도 헬퍼 함수로 분리)
        self._render_content_in_bubble(message_bubble_frame, content, role)

        # messages 리스트에 위젯 참조와 함께 메시지 데이터 저장
        msg_data["widget_ref"] = message_bubble_frame
        # 🟢 변경: 새 메시지일 경우에만 messages 리스트에 추가합니다.
        #           send_message 함수에서 직접 추가하는 것을 제거하여 중복을 방지합니다.
        if not is_update: 
            self.messages.append(msg_data)

        self.current_chat_row += 1 # 다음 메시지가 추가될 행 번호 증가

        # 스크롤을 맨 아래로 이동
        self.chat_history_frame.update_idletasks() # 위젯이 완전히 그려지도록 업데이트
        self.chat_history_frame._parent_canvas.yview_moveto(1.0)
        
    # --- 메시지 버블 내부에 텍스트/코드 렌더링 함수 ---
    def _render_content_in_bubble(self, parent_frame, content, role):
        # 메시지 버블의 최대 너비 계산 (현재 프레임의 크기 기반)
        # 이 함수가 호출될 때 frame_width가 0일 수 있으므로 안전장치 필요
        frame_width = parent_frame.winfo_width()
        if frame_width == 0:
            # 아직 프레임 크기가 확정되지 않았다면, 부모 창의 크기 기반으로 대략 추정
            frame_width = self.winfo_width() - 40 # 전체 창 너비에서 사이드 패딩 제외
            
        max_bubble_width = frame_width * 0.9 # 채팅 프레임 너비의 90% 사용 (패딩 고려)

        code_block_pattern = r"```(?P<lang>[a-zA-Z0-9_-]*)\n(?P<code>.*?)\n```"
        segments = re.split(code_block_pattern, content, flags=re.DOTALL)

        current_inner_row = 0
        
        # 코드 블록 폰트 객체 미리 가져오기
        code_line_height_px = self._code_font.metrics("linespace")

        for i, segment in enumerate(segments):
            if i % 3 == 0: # 일반 텍스트 부분
                if segment:
                    processed_lines = []
                    for line in segment.split('\n'):
                        line = re.sub(r'\*\*(.*?)\*\*', r'\1', line)
                        line = re.sub(r'(^\s*)[\*-]\s*(?=[^\d]|\d[^\.])', r'\1• ', line)
                        processed_lines.append(line.rstrip())
                    processed_text = "\n".join(processed_lines)

                    text_textbox = ctk.CTkTextbox(parent_frame,
                                                  font=ctk.CTkFont(family=self.custom_font_name, size=15),
                                                  wrap="word",
                                                  fg_color="transparent",
                                                  text_color="#333333",
                                                  border_width=0,
                                                  height=self.text_textbox_height(processed_text, max_bubble_width - 30)) 
                    
                    text_textbox.grid(row=current_inner_row, column=0, padx=15, pady=(0, 0), sticky="ew") 
                    text_textbox.insert("0.0", processed_text)
                    text_textbox.configure(state="disabled")
                    current_inner_row += 1
            elif i % 3 == 2: # 코드 내용 부분
                code_content = segment.strip()
                if code_content:
                    code_textbox = ctk.CTkTextbox(parent_frame,
                                                  font=self._code_font, # 미리 생성된 폰트 객체 사용
                                                  wrap="word",
                                                  fg_color="#282c34",
                                                  text_color="#abb2bf",
                                                  border_width=0,
                                                  height=(code_content.count('\n') + 2) * code_line_height_px + 10, # 10 픽셀의 여유 공간 추가
                                                  corner_radius=7)
                    
                    code_textbox.grid(row=current_inner_row, column=0, padx=10, pady=(0,0), sticky="ew") 
                    code_textbox.insert("0.0", code_content)
                    code_textbox.configure(state="disabled")

                    current_inner_row += 1

                    copy_code_button = ctk.CTkButton(parent_frame, text="코드 복사",
                                                     font=ctk.CTkFont(family=self.custom_font_name, size=12, weight="bold"),
                                                     command=lambda code=code_content: self.copy_to_clipboard(code),
                                                     width=80, height=25, corner_radius=5,
                                                     fg_color="#4a69bd", hover_color="#5b7ec2")
                    copy_code_button.grid(row=current_inner_row, column=0, padx=10, pady=(0, 5), sticky="e")
                    current_inner_row += 1

    # --- 메시지 전송 이벤트 핸들러 ---
    def send_message_event(self, event=None):
        if event and (event.state & 0x1): # Shift + Enter의 경우 줄바꿈 허용
            return 
        
        self.send_message()

    def send_message(self):
        user_query = self.user_input_textbox.get("1.0", "end-1c").strip()
        # 파일이 첨부되었거나 사용자 쿼리가 있을 때만 메시지 전송
        if not user_query and not self.selected_file_paths: # 파일 경로 리스트 확인 추가
            if self.has_placeholder and user_query == self.placeholder_text:
                return
            return

        self._remove_placeholder() 
        self.user_input_textbox.delete("1.0", ctk.END)
        
        # 파일이 첨부된 경우, 파일 이름 목록을 먼저 UI에 표시
        if self.selected_file_paths:
            file_names = ", ".join([os.path.basename(p) for p in self.selected_file_paths])
            self._add_message_to_ui({"role": "user", "content": f"[파일 첨부: {file_names}]"})
        
        # 사용자 쿼리 표시
        self._add_message_to_ui({"role": "user", "content": user_query})

        # AI 응답을 기다리는 동안 입력 비활성화
        self.user_input_textbox.configure(state="disabled")
        self.send_button.configure(state="disabled", text="생각 중...")
        self.upload_file_button.configure(state="disabled") # 파일 추가 버튼 비활성화

        # 로딩 메시지 미리 표시 (차등 업데이트)
        loading_message_id = f"loading_{int(time.time() * 1000)}"
        loading_message_data = {"role": "assistant", "content": "헤르메스가 신속하게 정보를 전달 중...", "id": loading_message_id}
        self._add_message_to_ui(loading_message_data)

        # AI 응답을 별도의 스레드에서 실행 (선택된 파일 경로도 함께 전달)
        threading.Thread(target=self.get_ai_response, args=(user_query, loading_message_id)).start()

    # --- AI 응답 처리 (백그라운드 스레드에서 실행) ---
    def get_ai_response(self, user_query, loading_message_id):
        global chatbot_manager

        try:
            # 첨부된 파일의 내용을 읽어옵니다. (휘발성 처리)
            attached_file_contents = []
            for file_path in self.selected_file_paths:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        attached_file_contents.append(f"--- 파일 시작: {os.path.basename(file_path)} ---\n{f.read()}\n--- 파일 끝: {os.path.basename(file_path)} ---")
                except Exception as file_e:
                    print(f"파일 '{file_path}' 읽기 오류: {file_e}")
                    attached_file_contents.append(f"--- 파일 읽기 오류: {os.path.basename(file_path)} (오류: {file_e}) ---")
            
            # 파일 내용을 하나의 문자열로 합칩니다.
            attached_file_contents_str = "\n\n".join(attached_file_contents) if attached_file_contents else ""

            ai_response = chatbot_core.chat_with_rag_gemini(
                chatbot_manager,
                user_query,
                self.messages, # RAG 컨텍스트에 모든 메시지 전달
                attached_file_contents=attached_file_contents_str # 파일 내용 전달
            )
            
            # 로딩 메시지를 실제 AI 응답으로 업데이트 (UI도 업데이트)
            self.after(0, self._update_message_in_ui, loading_message_id, {"role": "assistant", "content": ai_response})

            # 지식 베이스에 대화 기록 추가
            current_time_id = int(time.time() * 1000)
            chatbot_manager.add_to_knowledge_base(user_query, f"user_conv_{current_time_id}_user", {"source": "user_conversation", "speaker": "user", "timestamp": current_time_id})
            chatbot_manager.add_to_knowledge_base(ai_response, f"ai_resp_{current_time_id}_ai", {"source": "ai_response", "speaker": "ai", "timestamp": current_time_id})

        except Exception as e:
            print(f"Gemini API 또는 처리 중 오류 발생: {e}")
            error_message = f"오류 발생: {e}\nAPI 키 또는 네트워크 연결을 확인해주세요."
            # 로딩 메시지 대신 오류 메시지 표시 (UI도 업데이트)
            self.after(0, self._update_message_in_ui, loading_message_id, {"role": "error", "content": error_message})
        finally:
            self.after(0, lambda: self.user_input_textbox.configure(state="normal"))
            self.after(0, lambda: self.send_button.configure(state="normal", text="전송"))
            self.after(0, lambda: self.upload_file_button.configure(state="normal")) # 파일 추가 버튼 다시 활성화
            self.after(0, self._add_placeholder)
            self.selected_file_paths = [] # 파일 전송 후 선택된 파일 목록 초기화

    # --- UI 메시지 업데이트 헬퍼 함수 (메인 스레드에서 실행) ---
    def _update_message_in_ui(self, message_id, new_msg_data):
        # messages 리스트에서 해당 ID를 가진 메시지 찾아서 업데이트
        for i, msg in enumerate(self.messages):
            if "id" in msg and msg["id"] == message_id:
                # 메시지 리스트의 내용은 먼저 업데이트
                self.messages[i]["content"] = new_msg_data["content"]
                self.messages[i]["role"] = new_msg_data["role"]
                # UI 위젯도 업데이트
                self._add_message_to_ui(self.messages[i], is_update=True) # is_update=True로 호출
                break


# --- 앱 실행 ---
if __name__ == "__main__":
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")

    app = HermesChatApp()
    app.mainloop()
