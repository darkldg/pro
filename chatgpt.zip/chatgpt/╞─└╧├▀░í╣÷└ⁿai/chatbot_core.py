import google.generativeai as genai
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import os
from chromadb import PersistentClient
import time
from dotenv import load_dotenv

import re

load_dotenv()

api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    raise ValueError("GOOGLE_API_KEY 환경 변수가 설정되지 않았습니다. .env 파일 또는 시스템 환경 변수를 확인해주세요.")
genai.configure(api_key=api_key)

GOOGLE_CSE_API_KEY = os.getenv("GOOGLE_CSE_API_KEY")
GOOGLE_CSE_CX = os.getenv("GOOGLE_CSE_CX")

def perform_web_search(query):
    if not GOOGLE_CSE_API_KEY or not GOOGLE_CSE_CX:
        print("Google Custom Search API 키 또는 CX가 설정되지 않아 웹 검색을 수행할 수 없습니다.")
        return []

    try:
        service = build("customsearch", "v1", developerKey=GOOGLE_CSE_API_KEY)
        # num 값을 10으로 변경하여 최대 허용 결과 수를 가져옵니다.
        res = service.cse().list(
            q=query,
            cx=GOOGLE_CSE_CX,
            num=5 # 상위 10개 결과 가져오기 시도 (이전 7에서 변경, 최대 10)
        ).execute()

        search_results = []
        if 'items' in res:
            for item in res['items']:
                search_results.append({
                    "title": item.get('title'),
                    "link": item.get('link'),
                    "snippet": item.get('snippet','')[:200]
                })
        return search_results
    except HttpError as e:
        print(f"웹 검색 중 HTTP 오류 발생: {e.resp.status} - {e}")
        return []
    except Exception as e:
        print(f"웹 검색 중 알 수 없는 오류 발생: {e}")
        return []

class ChatbotCoreManager:
    def __init__(self):
        self.CHROMA_DB_PATH = "./chroma_db"
        self.client = PersistentClient(path=self.CHROMA_DB_PATH)
        self.collection_name = "user_patterns_and_conversations"
        self.collection = self.client.get_or_create_collection(name=self.collection_name)

        # 메인 답변 생성을 위한 모델
        self.gemini_model = genai.GenerativeModel(
            'models/gemini-2.5-flash-lite-preview-06-17',
            generation_config={"temperature": 0.8} 
        )
        
        # --- 웹 검색 쿼리 생성용 경량 모델 ---
        # "Invalid operation" 오류가 지속되면 이 모델명을 'models/gemini-2.5-flash-preview-05-20'으로 변경해 보세요.
        self.query_gen_model = genai.GenerativeModel(
             'models/gemini-1.5-flash-latest', # ListModels로 확인한 정확한 모델명으로 교체 필요
            generation_config={"temperature": 0.3, "max_output_tokens": 250} # 50 -> 70으로 변경
        )
        # ------------------------------------
        self.embedding_model_name = "models/embedding-001" 

    def embed_text(self, text, task_type="RETRIEVAL_DOCUMENT"):
        try:
            result = genai.embed_content(
                model=self.embedding_model_name,
                content=text,
                task_type=task_type
            )
            return result['embedding']
        except Exception as e:
            print(f"임베딩 오류 발생: {e}")
            return None

    def add_to_knowledge_base(self, text, doc_id, metadata={}):
        embedding = self.embed_text(text, task_type="RETRIEVAL_DOCUMENT")
        if embedding:
            try:
                self.collection.add(
                    embeddings=[embedding],
                    documents=[text],
                    metadatas=[metadata],
                    ids=[doc_id]
                )
            except Exception as e:
                print(f"ChromaDB 추가 오류: {e}")
                print(f"오류 발생 문서 ID: {doc_id}, 텍스트: {text[:50]}...")

    def initialize_user_data(self):
        if self.collection.count() == 0:
            print("초기 사용자 패턴 데이터를 로드합니다...")
            initial_user_data = [
                {"text": "나는 정확한 정보를 중요시해.", "id": "user_pref_001", "type": "preference"},
                {"text": "확실한 답변을 원해.", "id": "user_pref_002", "type": "preference"},
                {"text": "모르는건 확실히 모른다고 한다.", "id": "user_pref_003", "type": "preference"},
                {"text": "코드를 문제점을 물어보면 무조건 그틀에 맞추어서 수정한다.", "id": "user_pref_004", "type": "preference"},
                {"text": "수정한뒤 언제나 전체 코드를 보여준다.", "id": "user_pref_005", "type": "preference"},
                {"text": "개발할 때는 주로 인텔리제이를 사용하지만 파이썬도 사용할줄 안다.", "id": "user_pref_006", "type": "preference"},
                {"text": "코드 작성시 스타일을 말하면 언제나 깔끔하고 심플한 것을 선호한다.", "id": "user_pref_007", "type": "preference"},
                {"text": "나의 의도와 정보가 틀린거 같으면 정확히 의도를 적어서 물어본다.", "id": "user_pref_008", "type": "preference"},
                {"text": "최적화 효율성을 우선시한다.", "id": "user_pref_009", "type": "preference"},
                {"text": "최대한 같은 대답이 나오는것을 피한다.", "id": "user_pref_010", "type": "preference"}
            ]
            for item in initial_user_data:
                self.add_to_knowledge_base(item["text"], item["id"], {"source": "initial_user_data", "type": item["type"]})
            print(f"초기 사용자 패턴 데이터 {len(initial_user_data)}개 로드 완료. 현재 DB 문서 수: {self.collection.count()}")
        else:
            print(f"ChromaDB에 이미 데이터가 존재합니다. 현재 DB 문서 수: {self.collection.count()}")

def chat_with_rag_gemini(manager_instance, user_query, conversation_history, attached_file_contents="", k=5):
    start_total_time = time.time()

    # 프롬프트 길이 최적화를 위한 상수 정의
    MAX_WEB_SNIPPET_LENGTH = 300   # 각 웹 검색 스니펫의 최대 길이
    MAX_RAG_DOC_SNIPPET_LENGTH = 200 # 각 RAG 문서 스니펫의 최대 길이
    MAX_ATTACHED_FILE_SNIPPET_LENGTH = 500 # 첨부 파일 내용의 최대 길이 (새로 추가)

    # --- 0. 웹 검색 쿼리 생성 (새로운 단계) ---
    start_query_gen_time = time.time()
    search_query = user_query # 기본값은 사용자 질문
    
    # 웹 검색이 필요한 질문이라고 판단되면, Gemini에게 최적의 검색어 요청
    search_keywords_for_gen = ["최신", "새로운", "트렌드", "뉴스", "오늘", "현재", "최근", "실시간", "정보",
                               "무엇인가요", "알려주세요", "찾아줘", "궁금", "필요", "방법", "어떻게",
                               "마비노기", "게임", "룬", "장비", "공략", "팁", "클래스", "스킬", "빌드", "패치"]

    if any(keyword in user_query.lower() for keyword in search_keywords_for_gen):
        try:
            search_query_instruction = (
                f"다음 사용자 질문에 대해 구글 웹 검색을 수행하기 위한 가장 핵심적인 검색어(키워드 조합) 1개를 생성해 주세요. " # 프롬프트 완화
                f"답변은 70자 이내로 간결하게 작성하세요.\n" # 50자 -> 70자로 변경
                f"질문: '{user_query}'\n"
                f"예시: '마비노기 모바일 대검 룬 추천 최신', '2025년 6월 날씨 예보'"
                f"생성된 검색어:"
            )
            # 검색어 생성을 위한 모델 호출 (가볍게)
            query_gen_response = manager_instance.query_gen_model.generate_content(search_query_instruction)
            
            # --- 추가된 부분: 응답 유효성 검사 및 로그 ---
            if query_gen_response.candidates:
                if query_gen_response.candidates[0].content and query_gen_response.candidates[0].content.parts:
                    generated_search_query = query_gen_response.text.strip()
                else:
                    print(f"경고: 검색어 생성 모델이 유효한 텍스트를 반환하지 못했습니다.")
                    if hasattr(query_gen_response.candidates[0], 'finish_reason'):
                        print(f" Finish Reason: {query_gen_response.candidates[0].finish_reason}")
                    if hasattr(query_gen_response.candidates[0], 'safety_ratings'):
                        print(f" Safety Ratings: {query_gen_response.candidates[0].safety_ratings}")
                    generated_search_query = user_query # 오류 시에는 원래 사용자 질문 사용
            else:
                print(f"경고: 검색어 생성 모델이 응답 후보를 반환하지 못했습니다.")
                generated_search_query = user_query # 오류 시에는 원래 사용자 질문 사용
            # ------------------------------------

            # 생성된 검색어가 너무 길거나 이상하면 사용자 질문으로 대체
            if 0 < len(generated_search_query) <= 70 and "\n" not in generated_search_query: # 50 -> 70으로 변경
                search_query = generated_search_query
            else:
                print(f"생성된 검색어 비정상적: '{generated_search_query}'. 원본 쿼리 사용.")

            print(f"[시간 측정] 웹 검색 쿼리 생성: {time.time() - start_query_gen_time:.2f}초. 최종 쿼리: '{search_query}'")
        except Exception as e:
            print(f"웹 검색 쿼리 생성 중 오류 발생: {e}. 원본 쿼리 사용.")
            search_query = user_query # 오류 시에는 원래 사용자 질문 사용
    else:
        print(f"[시간 측정] 웹 검색 쿼리 생성: {time.time() - start_query_gen_time:.2f}초. 웹 검색 필요성 감지 안 됨.")


    # --- 1. 웹 검색 수행 ---
    web_results_str = ""
    start_web_search_time = time.time() # 웹 검색 필요성 감지 안 될 때도 시간 측정을 위해 이리로 이동
    if search_query != user_query or any(keyword in user_query.lower() for keyword in search_keywords_for_gen):
        # search_query가 사용자 질문과 다르거나, 웹 검색 필요성 키워드가 감지되었을 때 웹 검색 수행
        web_results = perform_web_search(search_query) # 생성된 검색어로 웹 검색 수행
        
        if web_results:
            web_results_str = "\n\n--- 사용자의 질문에 대한 최신 웹 검색 결과입니다. 이 정보를 **최우선적으로 활용하여 상세하고 정확하게 답변해주세요.** 만약 이 웹 검색 결과만으로는 충분한 정보를 제공하기 어렵다면, **당신의 내부 지식과 사용자 관련 정보(RAG)를 총동원하여 최대한 풍부하고 다양한 관점에서 답변을 보충**하세요. ---\n"
            for i, result in enumerate(web_results):
                # 스니펫 길이 제한 적용
                snippet_content = result.get('snippet', 'N/A')
                truncated_snippet = (snippet_content[:MAX_WEB_SNIPPET_LENGTH] + "...") if len(snippet_content) > MAX_WEB_SNIPPET_LENGTH else snippet_content
                
                web_results_str += f"{i+1}. 제목: {result.get('title', 'N/A')}\n"
                web_results_str += f" 요약: {truncated_snippet}\n"
                # 링크는 모델에 직접적인 정보가 아니므로 제거 고려 (필요시 포함)
                # web_results_str += f"  링크: {result.get('link', 'N/A')}\n" 
            web_results_str += "--------------------------------------\n"
        else:
            web_results_str = "\n\n--- 웹 검색 결과 없음. 내부 지식 및 사용자 관련 정보를 활용하여 답변합니다. ---\n"
        print(f"[시간 측정] 웹 검색 수행: {time.time() - start_web_search_time:.2f}초")
    else:
        # 웹 검색을 건너뛰는 경우에도 start_web_search_time이 정의되도록 수정 (위에 정의)
        print(f"[시간 측정] 웹 검색 건너뛰기: {time.time() - start_web_search_time:.2f}초 (웹 검색 필요성 감지 안 됨).")


    # --- 2. 사용자 질문 임베딩 및 ChromaDB 검색 ---
    start_embedding_time = time.time()
    query_embedding = manager_instance.embed_text(user_query, task_type="RETRIEVAL_QUERY")
    if not query_embedding:
        return "죄송합니다, 질문을 처리하는 데 문제가 발생했습니다."
    print(f"[시간 측정] 임베딩 생성: {time.time() - start_embedding_time:.2f}초")

    start_chromadb_time = time.time()
    retrieved_docs = []
    try:
        results = manager_instance.collection.query(
            query_embeddings=[query_embedding],
            n_results=k, # k 값은 유지 (최적의 문서 개수)
            include=['documents', 'distances']
        )
        if results and results['documents']:
            print("--- ChromaDB에서 검색된 문서 ---")
            for doc, dist in zip(results['documents'][0], results['distances'][0]):
                print(f"  - 문서: '{doc[:50]}...' (거리: {dist:.4f})")
            retrieved_docs = results['documents'][0]
    except Exception as e:
        print(f"ChromaDB 검색 오류: {e}")
    print(f"[시간 측정] ChromaDB 검색: {time.time() - start_chromadb_time:.2f}초")

    # --- 3. 프롬프트 구성 ---
    start_prompt_time = time.time()
    conversation_context = []
    # 과거 대화 기록을 최신 6개 메시지로 제한하여 프롬프트 길이 최적화
    for msg in conversation_history[-6:]: 
        if msg["role"] == "user":
            conversation_context.append(f"사용자: {msg['content']}")
        elif msg["role"] == "assistant":
            conversation_context.append(f"AI: {msg['content']}")
    
    system_instruction_parts = [
    "당신은 사용자의 다재다능하고 전문적인 지식 파트너이자 친절한 AI 어시스턴트입니다.",
    "항상 **정확하고 확실한 정보만을 제공**해야 하며, 모르는 것이 있다면 **모른다고 명확히** 말하고 불확실한 답변은 피해야 합니다.",
    "**가장 중요한 지침:** 제공된 **웹 검색 결과**와 **지식 베이스 문서**를 **최우선으로 활용**하여 답변을 구성하세요.",
    "**제공된 정보 내에서 답변할 수 없는 내용은 절대 추측하거나 지어내지 마세요.** 정보가 부족하다면 '죄송합니다, 해당 정보는 제가 가지고 있는 자료에 없습니다.'와 같이 명확히 답변하세요.",

    # --- 기존 지침을 '더 깊게' 만들기 위한 강조 및 추가 ---

    "**핵심 지침: 사용자의 질문이 간결하더라도, 관련 정보(웹 검색, 지식 베이스, 과거 대화)를 종합하여 최대한 상세하고, 실용적이며, 예측 가능한 추가 정보를 포함하여 답변을 확장하세요.** 단순한 요약을 넘어선 깊이 있는 통찰을 제공해야 합니다.", # ★ 핵심 추가/강조
    "**단순히 정보를 나열하는 것을 넘어, 종합적인 시각과 통찰력을 더해 답변을 구성하고, 자연스러운 한국어로 대화하듯 친근하게 응답해 주세요.**",

    "**코딩 및 기술 관련 문제:** 전문적인 지식을 활용하여 문제에 맞는 수정 방안을 제시하고, 필요하다면 언제나 **깔끔하고 심플한 스타일의 전체 코드**를 보여주세요. 코드를 보여주기 전에는 충분히 설명한 뒤 나에게 물어보고 작성해 주세요.",
    "**사용자 관련 정보(RAG) 및 과거 대화:** 이 정보들을 면밀히 분석하여 답변을 **개인화**하고, 특히 진행 중인 프로젝트(예: 웹 게임 개발)에 대한 맞춤형 조언을 제공할 때 이를 최우선으로 활용하세요. **사용자의 이전 질문이나 프로젝트 진행 상황을 바탕으로 선제적으로 도움이 될 만한 정보를 예측하여 제공하세요.**", # ★ 추가 강조
    "**질문 이면에 숨겨진 의도 파악:** 사용자의 잠재적 요구사항을 예측하여, 필요한 경우 선제적으로 관련 정보나 더 나은 해결책을 제안함으로써 대화의 깊이와 효율성을 극대화하세요.",
    "**정보의 신뢰도:** 가능하다면 주요 내용에 대한 근거나 출처(예: '관련 웹 정보에 따르면', '지식 베이스 문서에서 확인된 바에 따르면')를 간략하게 언급하여 신뢰도를 높여주세요.",
    "**답변 구성 원칙:** 모든 설명은 핵심 개념(What)과 실제 적용 방식(How it fits)에 초점을 맞춰, 사용자가 정보를 빠르고 명확하게 이해하고 실용적으로 활용할 수 있도록 구조화하세요. **복잡한 개념은 예시나 비유를 들어 쉽게 설명하고, 관련 지식을 유기적으로 연결하여 답변을 풍성하게 만드세요.**", # ★ 추가 강조
    "**효율성 및 다양성:** 최적화 효율성을 항상 우선시하고, 최대한 같은 답변이 반복되는 것을 피해서 다양하고 새로운 관점으로 대화에 임해 주세요.",
    "**아이디어 및 창의적 제안:** 사용자가 특정 주제나 문제에 대해 아이디어를 요청할 경우, 단순한 정보 나열을 넘어 **다양한 관점과 실현 가능한 구체적인 아이디어를 제시**해야 합니다. 필요하다면 **브레인스토밍 형식으로 여러 대안을 제공**하고, 각 아이디어의 **장점과 더불어 명확한 단점을 분석**해야 합니다. **제시된 단점에 대해서는 이를 극복하거나 완화할 수 있는 구체적이고 실현 가능한 해결 방안 또는 대안을 반드시 함께 제시하여, 사용자가 의사결정을 내리고 실행 계획을 세울 수 있도록 실질적인 도움을 제공해야 합니다.** 창의성과 실용성을 겸비한 제안을 우선시합니다."
    "대화 컨텍스트 유지: 항상 이전 대화의 흐름과 핵심 내용을 적극적으로 파악하고 기억하여 답변에 반영해야 합니다. 사용자의 질문이 간결하더라도, 바로 직전 대화의 핵심 주제나 키워드가 생략되었다면 이를 유추하여 연결성을 확보하고 답변을 구성하세요."
    "사용자의 요청이 코드 생성이나 간단한 정보 요청일 경우, 가장 일반적이고 합리적인 가정을 기반으로 먼저 응답을 시도해 주세요. 만약 응답 후에도 추가 정보가 필요하거나 사용자의 의도가 매우 불분명할 때만 구체적으로 질문을 던져서 의도를 파악하세요.",
    ]
    # RAG로 검색된 문서 추가 (웹 검색 결과가 위에 있기 때문에 여기에 추가)
    rag_content_str = ""
    if retrieved_docs:
        rag_content_str = "\n\n--- 사용자 관련 정보 (RAG 검색 결과) ---\n"
        for i, doc in enumerate(retrieved_docs):
            # RAG 문서 스니펫 길이 제한 적용
            truncated_doc = (doc[:MAX_RAG_DOC_SNIPPET_LENGTH] + "...") if len(doc) > MAX_RAG_DOC_SNIPPET_LENGTH else doc
            rag_content_str += f"- {truncated_doc}\n"
        rag_content_str += "--------------------------------------\n"
    else:
        rag_content_str = "\n\n--- 사용자 관련 정보를 찾을 수 없음. 일반적인 답변 시도. ---\n"

    # 첨부 파일 내용 추가 (새로 추가된 부분)
    attached_files_context = ""
    if attached_file_contents:
        truncated_file_contents = (attached_file_contents[:MAX_ATTACHED_FILE_SNIPPET_LENGTH] + "\n...") if len(attached_file_contents) > MAX_ATTACHED_FILE_SNIPPET_LENGTH else attached_file_contents
        attached_files_context = f"\n\n--- 첨부된 파일 내용 (이 내용을 최우선적으로 분석하고 해석하여 답변에 활용하세요) ---\n{truncated_file_contents}\n--------------------------------------\n"


    # 최종 답변 생성을 위한 프롬프트 구성
    final_prompt_content = f"""
# 당신의 일반적인 행동 지침:
{"\n".join(system_instruction_parts)}

# 웹 검색 결과:
{web_results_str}

# 지식 베이스 문서:
{rag_content_str}

# 첨부된 파일 내용:
{attached_files_context}

# 과거 대화 기록:
{"\n".join(conversation_context)}

# 사용자 질문:
{user_query}

# 답변:
"""
         # --- 추가 코드 시작 ---
    print(f"[디버그] 최종 입력 프롬프트 길이 (글자 수): {len(final_prompt_content)}자")
        # --- 추가 코드 끝 ---
    print(f"[디버그] RAG 문서 문자 수: {len(rag_content_str)}자") # <-- 이 줄 추가
    print(f"[디버그] 과거 대화 기록 문자 수: {len(''.join(conversation_context))}자") # <-- 이 줄 추가
    print(f"[디버그] 시스템 지침 문자 수: {len(''.join(system_instruction_parts))}자") #

    print(f"[시간 측정] 프롬프트 구성: {time.time() - start_prompt_time:.2f}초")

    # --- 4. Gemini 모델 호출 ---
    start_gemini_time = time.time()
    try:
        response = manager_instance.gemini_model.generate_content(final_prompt_content)
        ai_response_text = response.text.strip()
        
        prefixes_to_remove = [
            r"^\*?\*?답변:\*?\*?\s*", r"^\*?\*?AI의 답변:\*?\*?\s*", r"^\*?\*?AI:\*?\*?\s*",
            r"^\s*AI:\s*",
            r"^(?:AI|챗봇|나는|저의 답변은|제 대답은|다음은|여기 답변입니다|이에 대한 답변입니다|답변드리겠습니다|이 질문에 대한 답변은|네, 답변드리겠습니다|네, 말씀드리겠습니다|말씀드리겠습니다|답변해드리겠습니다|네, 다음과 같습니다|네, 다음과 같은 정보를 드릴 수 있습니다)\s*[:.]?\s*",
            r"^\s*\(?[\d.]+\)?\s*",
            r"^\s*-\s*",
            r"^\s*\*?\*?\s*",
            r"^\s*`{3}python\n", r"^\s*```"
        ]
        for prefix_pattern in prefixes_to_remove:
            match = re.match(prefix_pattern, ai_response_text)
            if match:
                ai_response_text = ai_response_text[match.end():].strip()
                break

        print(f"[시간 측정] Gemini 모델 응답 생성: {time.time() - start_gemini_time:.2f}초")
        print(f"[시간 측정] 총 응답 시간: {time.time() - start_total_time:.2f}초")
        return ai_response_text
    except Exception as e:
        print(f"[시간 측정] Gemini 오류 발생까지: {time.time() - start_gemini_time:.2f}초")
        print(f"Gemini API 호출 오류: {e}")
        if hasattr(e, 'text') and e.text:
            print(f"Gemini API 오류 상세: {e.text}")
        print(f"[시간 측정] 총 응답 시간: {time.time() - start_total_time:.2f}초")
        return "죄송합니다, AI가 응답하는 데 문제가 발생했습니다. (API 오류)"

if __name__ == "__main__":
    print("------------------------------------------")
    print("      개인 채팅 AI에 오신 것을 환영합니다!      ")
    print("      (종료하려면 'exit' 또는 '종료'를 입력하세요) ")
    print("------------------------------------------")

    core_manager = ChatbotCoreManager()
    core_manager.initialize_user_data()

    terminal_conversation_history = [] 

    while True:
        user_input = input("\n당신: ")
        user_input_lower = user_input.lower().strip()

        if user_input_lower in ('exit', '종료', 'quit'):
            print("AI: 대화를 종료합니다. 다음에 또 만나요!")
            break

        terminal_conversation_history.append({"role": "user", "content": user_input})

             # --- 이 부분의 코드가 적용되었는지 확인 (혹은 직접 추가) ---
        max_history_turns = 5 # 5개 턴 유지 (원하는 대로 조정 가능)
        if len(terminal_conversation_history) > max_history_turns * 2:
            terminal_conversation_history = terminal_conversation_history[-(max_history_turns * 2):]
        # --------------------------------------------------------

        ai_response = chat_with_rag_gemini(core_manager, user_input, terminal_conversation_history)
        print("AI:", ai_response)

        terminal_conversation_history.append({"role": "assistant", "content": ai_response})

        current_time_id = int(time.time() * 1000)
        user_doc_id = f"user_conv_{current_time_id}"
        ai_doc_id = f"ai_resp_{current_time_id}_ai"

        core_manager.add_to_knowledge_base(user_input, user_doc_id, {"source": "user_conversation", "speaker": "user", "timestamp": current_time_id})
        core_manager.add_to_knowledge_base(ai_response, ai_doc_id, {"source": "ai_response", "speaker": "ai", "timestamp": current_time_id})
